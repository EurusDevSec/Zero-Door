#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONUTF8=1
scratch/zer12/production-nemesis/Scripts/python.exe -B scratch/zer11/rt1-20261021-4d39d9f7/diagnose.py > scratch/zer11/rt1-20261021-4d39d9f7/diagnostic.log 2>&1
code=$?
cat scratch/zer11/rt1-20261021-4d39d9f7/diagnostic.log
exit "$code"
