#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s get deploy -n target-app -o json > scratch/zer11/rt1-20261021-4d39d9f7/targets-after.json
kubectl --context k3d-zero-door --request-timeout=10s get deploy -n zero-door -o json > scratch/zer11/rt1-20261021-4d39d9f7/agents-after.json
kubectl --context k3d-zero-door --request-timeout=10s get hpa -A -o json > scratch/zer11/rt1-20261021-4d39d9f7/hpas-after.json
kubectl --context k3d-zero-door --request-timeout=10s get namespaces -o json > scratch/zer11/rt1-20261021-4d39d9f7/namespaces-after.json
kubectl --context k3d-zero-door --request-timeout=10s get configmaps -n zero-door -o json > scratch/zer11/rt1-20261021-4d39d9f7/configmaps-after.json
