#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s get events -n target-app -o json > scratch/zer11/rt1-20261021-4d39d9f7/hpa-live-events.json
kubectl --context k3d-zero-door --request-timeout=10s get resourcequota -n target-app -o json > scratch/zer11/rt1-20261021-4d39d9f7/hpa-live-quota.json
kubectl --context k3d-zero-door --request-timeout=10s get deployment,pod,hpa -n target-app -o json > scratch/zer11/rt1-20261021-4d39d9f7/hpa-live-workloads.json
