#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s get pods -n zd-zer11-5bb9b26c -o wide
kubectl --context k3d-zero-door --request-timeout=10s get deployments -n zero-door gaia hephaestus
kubectl --context k3d-zero-door --request-timeout=10s get deployments -n target-app frontend cartservice
kubectl --context k3d-zero-door --request-timeout=10s get hpa -n target-app
