#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s create --dry-run=client -f infrastructure/manifests/r1-baselines.yaml -o json > scratch/zer11/rt1-20261021-4d39d9f7/profile-dryrun.jsons
