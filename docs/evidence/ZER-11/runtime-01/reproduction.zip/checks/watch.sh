#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s get pods -n zd-zer11-62702b22 -o wide
kubectl --context k3d-zero-door --request-timeout=10s get deployments -n zero-door gaia hephaestus
kubectl --context k3d-zero-door --request-timeout=10s get deployments -n target-app frontend cartservice
