#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-nemesis/Scripts/python.exe -B tests/test_dashboard_baseline_runtime.py Controller.test_controller_and_hpa_recovery_end_to_end_then_score_register_and_serve > scratch/zer11/rt1-20261021-4d39d9f7/scale-before.log 2>&1
code=$?
tail -n 12 scratch/zer11/rt1-20261021-4d39d9f7/scale-before.log
[ "$code" -eq 1 ]
