#!/usr/bin/env bash
set -uo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONUNBUFFERED=1
export PYTHONUTF8=1
scratch/zer12/production-nemesis/Scripts/python.exe -B scratch/zer11/rt1-20261021-4d39d9f7/run-bounded.py > scratch/zer11/rt1-20261021-4d39d9f7/console-attempt03.log 2>&1
code=$?
cat scratch/zer11/rt1-20261021-4d39d9f7/console-attempt03.log
printf 'RT1_EXIT=%s
' "$code"
exit "$code"
