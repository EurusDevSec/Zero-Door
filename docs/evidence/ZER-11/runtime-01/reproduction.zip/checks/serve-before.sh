#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-nemesis/Scripts/python.exe -B tests/test_dashboard_measurement.py ResultsServer.test_ctrl_c_still_records_root_integrity_and_reports_changes > scratch/zer11/rt1-20261021-4d39d9f7/serve-before.log 2>&1
code=$?
tail -n 7 scratch/zer11/rt1-20261021-4d39d9f7/serve-before.log
printf 'FAIL_BEFORE_EXIT=%s\n' "$code"
[ "$code" -ne 0 ]
