#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-nemesis/Scripts/python.exe -B tests/test_dashboard_baseline_runtime.py Boundaries.test_preflight_ignores_untagged_node_images_but_still_requires_the_image > scratch/zer11/rt1-20261021-4d39d9f7/null-before.log 2>&1
code=$?
tail -n 8 scratch/zer11/rt1-20261021-4d39d9f7/null-before.log
[ "$code" -eq 1 ]
