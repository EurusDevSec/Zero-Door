#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
MSYS_NO_PATHCONV=1 kubectl --context k3d-zero-door --request-timeout=10s -n zd-zer11-5bb9b26c exec zd-rt1-agent -- python -B /app/rt1/r1_baseline_runtime.py call '{"action":"status"}' > scratch/zer11/rt1-20261021-4d39d9f7/status04.json
