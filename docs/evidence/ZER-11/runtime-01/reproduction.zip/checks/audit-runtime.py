import hashlib,json
from pathlib import Path
root=Path('C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-attempt04')
local=Path('scratch/zer11/rt1-20261021-4d39d9f7')
receipt=json.loads((root/'receipt.json').read_text())
assert receipt['verdict']=='COMPLETED' and receipt['cleanup']=='CLEAN'
assert receipt['final_diff']=={'deployments':{},'hpas_left':[],'profiles_left':[],'namespace_left':False}
assert receipt['pod_deletes']['frontend_pod']==1
restored=[]
for before,after in (('targets-before.json','targets-after.json'),('agents-before.json','agents-after.json')):
    b=json.loads((local/before).read_text())['items'];a={d['metadata']['name']:d for d in json.loads((local/after).read_text())['items']}
    for d in b:
        q=a[d['metadata']['name']]
        assert d['metadata']['uid']==q['metadata']['uid']
        assert d['spec']==q['spec']
        assert q['status'].get('readyReplicas',0)>=q['spec'].get('replicas',1)
        restored.append(d['metadata']['name'])
assert not json.loads((local/'hpas-after.json').read_text())['items']
assert not any(n['metadata']['name'] in {receipt['namespace'],'zd-zer11-03292ba3','zd-zer11-62702b22','zd-zer11-2d82abe8'} for n in json.loads((local/'namespaces-after.json').read_text())['items'])
assert not any(c['metadata']['name']=='zd-r1-baseline-profiles' for c in json.loads((local/'configmaps-after.json').read_text())['items'])
counts={}; hashes=0; types={}
for plane in ('H','O'):
    records=[json.loads(line) for line in (root/'raw'/('export-'+plane)/(plane+'.jsonl')).read_text().splitlines()]
    assert len({r['envelope']['event_id'] for r in records})==len(records)
    for record in records:
        env=record['envelope']
        digest=hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
        assert record['envelope_sha256']==digest
        assert env['plane']==plane
        if plane=='O': assert env['event_type'] in ('RUN_CONTEXT','TRIAL_CONTEXT')
        hashes+=1
    counts[plane]=len(records)
    types[plane]=sorted({r['envelope']['event_type'] for r in records})
score=json.loads((root/'results'/receipt['p8']['directory']/'score.json').read_text())['runs'][0]
assert score['metrics']['kpi']['counts']['N']==1
assert score['metrics']['kpi']['counts']['CONFIRMED_NO_EFFECT']==1
ctrl=next(i for i in score['incidents'] if i['label']=='RECOVERED_UNDETECTED')
assert (ctrl['milestones']['t_rec']['t_ms']-ctrl['milestones']['t_eff']['t_ms'])/1000==ctrl['total']==39.997
assert ctrl['mttd']==ctrl['mttr']=='N/A'
assert receipt['p8']['verdicts']['B0-HPA']['claim']=='NO_EFFECT'
for trial in receipt['trials'].values():
    assert trial['summary']['audit_coverage']['complete'] and trial['summary']['audit_coverage']['o_actions']==0
    assert trial['summary']['probe']['undelivered']==0
assert receipt['p8']['positive_control_score']['quarantined_mode_violations']==1
summary={'verdict':'PASS_SCOPED_RT1','restored_deployments':restored,'raw_records':counts,'envelope_hashes_verified':hashes,'event_types':types,'controller_total_recovery_s':ctrl['total'],'hpa_label':'CONFIRMED_NO_EFFECT','limits':['HPA extra pods blocked by existing CPU quota; no HPA recovery claim','one unresolved cart cleanup CONNECTION_RESET during controller outage','not formal KPI acceptance; BM/RT2 not run']}
(local/'independent-audit.json').write_text(json.dumps(summary,indent=1),encoding='utf-8')
print(json.dumps(summary))
