#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
for pin in nemesis hephaestus; do
scratch/zer12/production-$pin/Scripts/python.exe -B tests/test_dashboard_baseline_runtime.py Controller.test_controller_and_hpa_recovery_end_to_end_then_score_register_and_serve Boundaries.test_preflight_ignores_untagged_node_images_but_still_requires_the_image Findings.test_rt1_02_ownership_reads_ask_for_managed_fields_and_a_wrong_manager_still_fails Findings.test_controller_claim_requires_trial_time_window_before_recovery Findings.test_rt1_05_controller_and_hpa_claims_need_this_trials_objects > scratch/zer11/rt1-20261021-4d39d9f7/scale-after-$pin.log 2>&1
tail -n 4 scratch/zer11/rt1-20261021-4d39d9f7/scale-after-$pin.log
done
