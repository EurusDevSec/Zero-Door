import copy
import importlib.util
import sys
from datetime import datetime, timezone
from pathlib import Path
root = Path.cwd()
script = root/'infrastructure/scripts/verify-dashboard-baselines.py'
spec = importlib.util.spec_from_file_location('rt1_bounded_entry', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
remaining = int((datetime.fromisoformat('2026-10-21T16:47:47.837+00:00') - datetime.now(timezone.utc)).total_seconds())
module.RT1 = copy.deepcopy(module.RT1)
module.RT1['caps']['total_s'] = min(module.RT1['caps']['total_s'], remaining)
print('Total remaining cap (including cleanup):', remaining, flush=True)
sys.exit(module.main(['rt1','--execute','--runtime-approval','Hoang-call_84d20afcbd014088a379b9fc172d89da-approved-RT1-shared-deadline','--context','k3d-zero-door','--out', 'C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-attempt04']))
