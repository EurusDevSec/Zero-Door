#!/usr/bin/env bash
set -uo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
status=0
for pin in nemesis hephaestus; do
scratch/zer12/production-$pin/Scripts/python.exe -B tests/test_dashboard_measurement.py ResultsServer > scratch/zer11/rt1-20261021-4d39d9f7/results-server-$pin.log 2>&1
code=$?
tail -n 5 scratch/zer11/rt1-20261021-4d39d9f7/results-server-$pin.log
[ "$code" -eq 0 ] || status=1
done
scratch/zer12/test-venv/Scripts/python.exe -m bandit -q infrastructure/scripts/r1_baseline_runtime.py infrastructure/scripts/verify-dashboard-baselines.py > scratch/zer11/rt1-20261021-4d39d9f7/bandit-final.log 2>&1
code=$?
cat scratch/zer11/rt1-20261021-4d39d9f7/bandit-final.log
[ "$code" -eq 0 ] || status=1
git diff --check
code=$?
[ "$code" -eq 0 ] || status=1
printf 'FINAL_OFFLINE=%s\n' "$status"
exit "$status"
