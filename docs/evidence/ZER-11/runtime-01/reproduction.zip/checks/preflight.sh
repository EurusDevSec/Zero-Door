#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
out='scratch/zer11/rt1-20261021-4d39d9f7'
command -v kubectl
kubectl --context k3d-zero-door --request-timeout=10s get nodes -o wide > "$out/nodes.txt"
kubectl --context k3d-zero-door --request-timeout=10s get deploy -n target-app -o json > "$out/targets-before.json"
kubectl --context k3d-zero-door --request-timeout=10s get deploy -n zero-door -o json > "$out/agents-before.json"
kubectl --context k3d-zero-door --request-timeout=10s get hpa -A -o json > "$out/hpas-before.json"
cat "$out/nodes.txt"
printf 'READ_ONLY_PREFLIGHT=OK
'
