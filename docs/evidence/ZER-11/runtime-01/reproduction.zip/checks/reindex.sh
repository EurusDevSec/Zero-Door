#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
node .gitnexus/run.cjs analyze --pdg --index-only > scratch/zer11/rt1-20261021-4d39d9f7/gitnexus-final.log 2>&1
tail -n 8 scratch/zer11/rt1-20261021-4d39d9f7/gitnexus-final.log
