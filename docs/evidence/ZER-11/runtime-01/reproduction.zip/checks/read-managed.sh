#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
kubectl --context k3d-zero-door --request-timeout=10s get deployment frontend -n target-app -o json --show-managed-fields=true > scratch/zer11/rt1-20261021-4d39d9f7/frontend-managed.json
kubectl --context k3d-zero-door --request-timeout=10s get deployment gaia -n zero-door -o json --show-managed-fields=true > scratch/zer11/rt1-20261021-4d39d9f7/gaia-managed.json
