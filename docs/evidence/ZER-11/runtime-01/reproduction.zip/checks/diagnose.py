import copy
import importlib.util
import json
import sys
from pathlib import Path
from datetime import datetime, timezone
root = Path.cwd()
sys.path.insert(0,str(root/'infrastructure/scripts'))
import r1_baseline_runtime as rt
spec = importlib.util.spec_from_file_location('v',root/'infrastructure/scripts/verify-dashboard-baselines.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
plan=copy.deepcopy(v.RT1)
plan['caps']['total_s']=min(300,int((datetime.fromisoformat('2026-10-21T16:47:47.837+00:00')-datetime.now(timezone.utc)).total_seconds()))
plan['phases_s']['P7']=120
out=Path('C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-diagnostic')
class Capture(rt.Kube):
    def json(self,args,*a,**kw):
        obj=super().json(args,*a,**kw)
        if args[:3]==['get','deploy',rt.CANARY]:
            with (out/'canary-managed.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(obj)+'\n')
        return obj
class Diagnostic(rt.Orchestrator):
    def trial(self,name):
        raise rt.Abort('DIAGNOSTIC_ONLY_NO_TARGET_FAULT')
result=Diagnostic(plan,Capture(rt.CONTEXT),out,'Hoang RT1 approved; diagnostic canary only, no target fault').run()
print(json.dumps({k:result.get(k) for k in ('abort','cleanup','final_diff','pod_deletes','errors')},default=str))
