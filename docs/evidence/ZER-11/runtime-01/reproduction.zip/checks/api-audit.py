import hashlib,json,urllib.request
from pathlib import Path
root=Path('C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-attempt04/results')
key=json.loads(Path('C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-results-reader.json').read_text())['secret']
registry=json.loads((root/'registry.json').read_text())
entry=registry['runs'][0]
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
base='http://127.0.0.1:8712/api/results/runs/'+entry['run_id']
def get(url):
    with opener.open(urllib.request.Request(url,headers={'Authorization':'Bearer '+key}),timeout=10) as response:
        assert response.status==200
        return response.read()
view=json.loads(get(base))
assert view['run_id']==entry['run_id']
assert view['provenance']['sha256']==entry['sha256']
for name,digest in entry['sha256'].items():
    body=get(base+'/files/'+name)
    assert body==(root/entry['dir']/name).read_bytes(),name
    assert hashlib.sha256(body).hexdigest()==digest,name
Path('scratch/zer11/rt1-20261021-4d39d9f7/api-view.json').write_text(json.dumps(view,indent=1),encoding='utf-8')
print('API vs scorer/export: run_id + provenance + 3 byte-identical files PASS')
