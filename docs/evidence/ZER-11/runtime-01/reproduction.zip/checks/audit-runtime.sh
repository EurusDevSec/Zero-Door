#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-nemesis/Scripts/python.exe -B scratch/zer11/rt1-20261021-4d39d9f7/audit-runtime.py > scratch/zer11/rt1-20261021-4d39d9f7/independent-audit.log 2>&1
cat scratch/zer11/rt1-20261021-4d39d9f7/independent-audit.log
