#!/usr/bin/env bash
set -uo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
export ZD_PYTHON=scratch/zer12/production-nemesis/Scripts/python.exe
export PYTHONUNBUFFERED=1
export PYTHONUTF8=1
bash infrastructure/scripts/verify-dashboard-baselines.sh rt1 --execute --runtime-approval 'Hoang-call_84d20afcbd014088a379b9fc172d89da-approved-RT1-3600s' --context k3d-zero-door --out 'C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-attempt02' > 'scratch/zer11/rt1-20261021-4d39d9f7/console-attempt02.log' 2>&1
code=$?
cat 'scratch/zer11/rt1-20261021-4d39d9f7/console-attempt02.log'
printf 'RT1_EXIT=%s
' "$code"
exit "$code"
