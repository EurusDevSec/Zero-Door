#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONUTF8=1
export RT1_KEEP="$PWD/scratch/zer11/rt1-20261021-4d39d9f7/regression-kept"
scratch/zer12/production-nemesis/Scripts/python.exe -B tests/test_dashboard_baseline_runtime.py > scratch/zer11/rt1-20261021-4d39d9f7/runtime-regression.log 2>&1
code=$?
tail -n 15 scratch/zer11/rt1-20261021-4d39d9f7/runtime-regression.log
printf 'RUNTIME_REGRESSION_EXIT=%s\n' "$code"
exit "$code"
