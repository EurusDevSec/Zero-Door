#!/usr/bin/env bash
set -eu
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONUTF8=1
exec scratch/zer12/production-nemesis/Scripts/python.exe -B infrastructure/scripts/verify-dashboard-baselines.py serve-results --root 'C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-attempt04/results' --reader-key-file 'C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-results-reader.json' --port 8712 --receipt 'C:/Users/ACER/AppData/Local/Packages/sandbox.{8d72322d-6d76-4dc7-a37f-4d339db38a0f}/AC/Temp/zero-door-rt1-20261021-4d39d9f7-serve-receipt.json'
