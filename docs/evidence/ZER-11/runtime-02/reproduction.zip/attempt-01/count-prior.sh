#!/usr/bin/env bash
set -euo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-hephaestus/Scripts/python.exe -B scratch/zer11/rt2-runtime-f8f94738/count-prior.py
