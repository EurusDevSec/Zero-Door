set -euo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1
scratch/zer12/production-hephaestus/Scripts/python.exe -B scratch/zer11/rt2-runtime-f8f94738/attempt-03/independent-audit.py
scratch/zer12/production-nemesis/Scripts/python.exe -B -m unittest discover -s tests -p test_dashboard_mode_runtime.py -v > scratch/zer11/rt2-runtime-f8f94738/nemesis-final4.log 2>&1
scratch/zer12/test-venv/Scripts/python.exe -B -m bandit -q infrastructure/scripts/r1_mode_runtime.py tests/test_dashboard_mode_runtime.py > scratch/zer11/rt2-runtime-f8f94738/bandit-final4.log 2>&1
bash -n infrastructure/scripts/verify-dashboard-modes.sh
git diff --check
git status --short > scratch/zer11/rt2-runtime-f8f94738/git-status.txt
