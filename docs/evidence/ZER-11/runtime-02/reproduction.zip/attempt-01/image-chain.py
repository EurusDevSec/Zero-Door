import hashlib,io,json,pathlib,subprocess,tarfile
out=pathlib.Path(__file__).resolve().parent
image=json.loads((out/'bundle/config.json').read_text())['image']
inspect=json.loads((out/'image-inspect.json').read_text())
node=json.loads((out/'node-image.json').read_text())
result=subprocess.run(['docker','--context','desktop-linux','image','save',image],capture_output=True,timeout=90,check=True)
with tarfile.open(fileobj=io.BytesIO(result.stdout)) as tar:
    archive=json.load(tar.extractfile('manifest.json'))
    matches=[r for r in archive if any(t.endswith(image) for t in r.get('RepoTags',[]))]
    assert len(matches)==1,archive
    config_path=matches[0]['Config']
    config=tar.extractfile(config_path).read()
    config_id='sha256:'+hashlib.sha256(config).hexdigest()
    config_obj=json.loads(config)
    assert config_id==node['status']['id'],(config_id,node['status']['id'])
    assert config_obj['rootfs']['diff_ids']==inspect['RootFS']['Layers']
    assert config_obj['config']==node['info']['imageSpec']['config']
    chain={'image':image,'docker_index_id':inspect['Id'],'docker_descriptor':inspect.get('Descriptor'),
           'saved_manifest':matches[0],'config_id':config_id,'rootfs_match':True,'config_match':True,'node_config_id':node['status']['id']}
    index_path='blobs/sha256/'+inspect['Id'].split(':')[1]
    try:
        index_data=tar.extractfile(index_path).read()
        assert 'sha256:'+hashlib.sha256(index_data).hexdigest()==inspect['Id']
        index=json.loads(index_data)
        manifests=[m for m in index['manifests'] if m.get('platform',{}).get('architecture')=='amd64' and m.get('platform',{}).get('os')=='linux']
        assert len(manifests)==1,index
        md=manifests[0]['digest']
        raw=tar.extractfile('blobs/sha256/'+md.split(':')[1]).read()
        assert 'sha256:'+hashlib.sha256(raw).hexdigest()==md
        manifest=json.loads(raw)
        assert manifest['config']['digest']==config_id
        chain.update(oci_index_hash_verified=True,platform_manifest_id=md,platform_manifest_hash_verified=True)
    except KeyError:
        chain['oci_index_hash_verified']=False
(out/'image-chain.json').write_text(json.dumps(chain,indent=2)+'\n')
print(json.dumps(chain))
