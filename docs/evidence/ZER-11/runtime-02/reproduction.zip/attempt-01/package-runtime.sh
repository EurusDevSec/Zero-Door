set -euo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
scratch/zer12/production-hephaestus/Scripts/python.exe -B scratch/zer11/rt2-runtime-f8f94738/package-runtime.py
gitnexus analyze --pdg --index-only > scratch/zer11/rt2-runtime-f8f94738/gitnexus-final.log 2>&1
tail -n 8 scratch/zer11/rt2-runtime-f8f94738/gitnexus-final.log
