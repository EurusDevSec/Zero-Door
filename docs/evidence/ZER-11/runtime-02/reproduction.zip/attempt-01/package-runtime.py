import hashlib,json,zipfile,datetime,re
from pathlib import Path
R=Path.cwd(); P=R/'scratch/zer11/rt2-runtime-f8f94738'; A=P/'attempt-03'; O=R/'docs/evidence/ZER-11/runtime-02'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
# Only credentials from the throwaway Secret are used as deny-list needles, never exported.
needles=set()
def leaves(value):
    if isinstance(value,dict):
        for v in value.values():yield from leaves(v)
    elif isinstance(value,list):
        for v in value:yield from leaves(v)
    elif isinstance(value,str) and len(value)>=24:yield value
for folder in (P,P/'attempt-02',A):
    for obj in load(folder/'bundle/private-resources.json')['items']:
        if obj['kind']=='Secret':
            for name,text in obj['stringData'].items():
                if name.startswith('policy-'):continue
                try: values=list(leaves(json.loads(text)))
                except ValueError:values=[text]
                needles.update(v.encode() for v in values)
files={}
def take(path,rel):
    data=path.read_bytes()
    if any(n in data for n in needles): raise RuntimeError('PRIVATE_CREDENTIAL_IN_EXPORT:'+rel)
    if 'private-resources' in rel or '/keys/' in rel:raise RuntimeError('PRIVATE_PATH:'+rel)
    files[rel]=data
# Full host argv/result and cleanup history; no private bundle resources.
for folder,label in ((P,'attempt-01'),(P/'attempt-02','attempt-02'),(A,'attempt-03')):
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in ('.json','.jsonl','.log','.py','.sh','.txt') and path.name not in ('git-status.txt',):take(path,label+'/'+path.name)
    for rel in ('bundle/config.json','bundle/source-manifest.json','bundle/plan.json'):
        path=folder/rel
        if path.is_file():take(path,label+'/'+rel)
    raw=folder/'raw'
    if raw.exists():
        for path in sorted(raw.rglob('*')):
            if path.is_file():take(path,label+'/'+path.relative_to(folder).as_posix())
# Source snapshots bind the helper used in the last run to the final package.
for rel in ('infrastructure/scripts/r1_mode_runtime.py','infrastructure/scripts/verify-dashboard-modes.sh','tests/test_dashboard_mode_runtime.py','.github/workflows/ci.yml','docs/runbooks/dashboard-and-baselines.md'):
    take(R/rel,'source/'+rel)
archive=O/'reproduction.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for rel,data in files.items():z.writestr(rel,data)
# Keep main evidence readily inspectable; full history stays in one archive.
for name in ('receipt.json','assessment.json','independent-audit.json','independent-audit.py','boundary-network.json','manual.json','summary.json','warmup.json','logs.json'):
    (O/name).write_bytes(files['attempt-03/'+name])
for group in ('BM','B1','B2','B3'):
    dest=O/'raw'/group;dest.mkdir(parents=True)
    for name in ('O.jsonl','manifest.json'):(dest/name).write_bytes(files['attempt-03/raw/work/exports/'+group+'/'+name])
protected=load(R/'scratch/zer11/rt2-preparation/intake.json')['protected']
mutable={'docs/runbooks/dashboard-and-baselines.md','docs/delivery/NOW.md','docs/delivery/milestones/R1-measurement/dashboard-and-baselines.md','.github/workflows/ci.yml'}
protected_result={p:sha((R/p).read_bytes())==h for p,h in protected.items() if p not in mutable}
assert all(protected_result.values()),protected_result
record={'verdict':'PASS_SCOPED_RT2','head':'169413303340fc01eea8597c121ce39455892af0','approval':'call_ceeb7a350665410ab2df1b2bf7a3471b','archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_files':len(files),'credential_scan':'PASS: exact throwaway Secret values absent; private resource manifests excluded','protected_source_unchanged':protected_result,'offline_final':{'nemesis':'4/4','hephaestus':'4/4','bandit':'0 findings; annotation parser warnings retained','bash_syntax':'PASS','diff_check':'PASS'},'source_hashes':{p:sha((R/p).read_bytes()) for p in ('infrastructure/scripts/r1_mode_runtime.py','infrastructure/scripts/verify-dashboard-modes.sh','tests/test_dashboard_mode_runtime.py','.github/workflows/ci.yml','docs/runbooks/dashboard-and-baselines.md')},'archive_entries':{p:sha(b) for p,b in files.items()}}
(O/'verification.json').write_text(json.dumps(record,indent=2)+chr(10),encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k!='archive_entries'},indent=2))
