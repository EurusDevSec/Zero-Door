import json,pathlib,subprocess,math
out=pathlib.Path(__file__).resolve().parent
a=out/'attempt-02'
r=json.loads((a/'receipt.json').read_text())
pod=next(x for x in r['created'] if x['kind']=='Pod' and x['name']=='rt2-driver')
base=['docker','--context','desktop-linux','exec','k3d-zero-door-server-0','crictl']
allc=json.loads(subprocess.run(base+['ps','-a','-o','json'],capture_output=True,timeout=20,check=True).stdout)
found=[c for c in allc['containers'] if c.get('labels',{}).get('io.kubernetes.pod.uid')==pod['uid']]
assert len(found)==1,found
status=json.loads(subprocess.run(base+['inspect',found[0]['id']],capture_output=True,timeout=20,check=True).stdout)['status']
observations=json.loads((a/'raw/work/observations.json').read_text())
assert status['finishedAt']>0
start=observations[0]['at']
end=status['finishedAt']/1e9
upper=min(360,math.ceil((end-start)/0.5)+2)
record={'pod_uid':pod['uid'],'container_id':status['id'],'started_at_ns':status['startedAt'],'finished_at_ns':status['finishedAt'],
'observed_samples_before_tar':len(observations),'first_sample_wall':start,'interval_lower_bound_s':0.5,'conservative_prior_get_upper_bound':upper,
'remaining_get_budget':360-upper,'method':'same Linux host wallclock first sample to container termination; ceil(delta/0.5)+2, includes in-flight request; no hidden retry/redirect in HTTP helper'}
(out/'request-budget.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
