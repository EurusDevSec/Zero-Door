"""Supervised, single-use RT2 host actions under call_ceeb7a350665410ab2df1b2bf7a3471b.
Deadline is anchored in authorization.json, never reset by a restart.
"""
import datetime as dt
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
AUTH = json.loads((OUT / 'authorization.json').read_text())
END = dt.datetime.fromisoformat(AUTH['deadline_utc'].replace('Z', '+00:00')).timestamp()
MAIN = END - 300
NS = AUTH['namespace']
LABEL = 'zero-door.io/run'
CONTEXT = 'k3d-zero-door'
os.environ['MSYS_NO_PATHCONV'] = '1'
spec = importlib.util.spec_from_file_location('rt2', ROOT / 'infrastructure/scripts/r1_mode_runtime.py')
rt2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt2)
created, scaled, calls, errors, cleanup = [], [], [], [], []
baseline, cfg, driver_up, target_deletes = {}, None, False, 0
receipt = {'authorization': AUTH, 'verdict': 'RUNNING', 'created': created, 'scaled': scaled, 'errors': errors,
           'cleanup': cleanup, 'frontend_pod_deletes': 0}
cleaning = False


def save(name, data):
    rt2.save(OUT / name, data)


def progress(message):
    print(dt.datetime.now(dt.timezone.utc).isoformat(), message, flush=True)


def command(argv, stdin=None, timeout=20, check=True, private=False, binary=False):
    deadline = END if cleaning else MAIN
    remaining = deadline - time.time()
    if remaining <= 0:
        raise RuntimeError('TOTAL_DEADLINE')
    began = time.time()
    try:
        result = subprocess.run(argv, input=stdin, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=max(.1, min(timeout, remaining)), check=False)
        record = {'argv': argv, 'started': began, 'ended': time.time(), 'exit': result.returncode,
                  'stderr': result.stderr.decode(errors='replace')[-6000:]}
        record['stdout'] = ('PRIVATE_REDACTED' if private else
                            {'bytes': len(result.stdout), 'sha256': rt2.digest(result.stdout)} if binary else
                            result.stdout.decode(errors='replace'))
        calls.append(record)
        with (OUT / 'calls.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(record) + '\n')
        if check and result.returncode:
            raise RuntimeError('COMMAND_FAILED: ' + str(argv[:7]) + ': ' + record['stderr'][-500:])
        return result
    except subprocess.TimeoutExpired:
        calls.append({'argv': argv, 'started': began, 'ended': time.time(), 'error': 'TIMEOUT'})
        raise RuntimeError('COMMAND_TIMEOUT: ' + str(argv[:7])) from None


def kube(args, **kwargs):
    return command(['kubectl', '--context', CONTEXT, '--request-timeout=20s'] + args, **kwargs)


def get(kind, name=None, namespace=None):
    args = ['get', kind] + ([name] if name else []) + (['-n', namespace] if namespace else []) + ['-o', 'json', '--show-managed-fields=true']
    return json.loads(kube(args, private=(kind == 'secret')).stdout)


def absent(kind, name, namespace=None):
    answer = kube(['get', kind, name] + (['-n', namespace] if namespace else []), check=False)
    if not answer.returncode:
        return False
    if b'NotFound' in answer.stderr:
        return True
    raise RuntimeError('ABSENCE_UNVERIFIED: '+kind+'/'+name)


def healthy():
    node = get('node', 'k3d-zero-door-server-0')
    if not any(c.get('type') == 'Ready' and c.get('status') == 'True' for c in node['status']['conditions']):
        raise RuntimeError('NODE_NOT_READY')


def poll(label, fn, seconds=90):
    until = min(time.time() + seconds, END if cleaning else MAIN)
    last = None
    while time.time() < until:
        last = fn()
        if last:
            return last
        time.sleep(1)
    raise RuntimeError('WAIT_TIMEOUT: ' + label + ': ' + repr(last))


def pod_ready(name):
    p = get('pod', name, NS)
    if p['status'].get('phase') == 'Failed':
        raise RuntimeError('POD_FAILED: ' + name + ' ' + str(p['status']))
    return p if p['status'].get('phase') == 'Running' and all(c.get('ready') for c in p['status'].get('containerStatuses', [])) and p['status'].get('containerStatuses') else None


def create(obj):
    m, kind = obj['metadata'], obj['kind']
    if m.get('labels', {}).get(LABEL) != NS or (kind != 'Namespace' and m.get('namespace') != NS):
        raise RuntimeError('CREATE_OUTSIDE_RUN')
    record = {'kind': kind, 'name': m['name'], 'namespace': m.get('namespace'), 'uid': None}
    created.append(record)
    save('created.json', created)  # intent first; reconcile lost reply by name + run label in finally
    made = json.loads(kube(['create', '-f', '-', '-o', 'json'], stdin=rt2.encoded(obj), private=(kind == 'Secret')).stdout)
    record['uid'] = made['metadata']['uid']
    save('created.json', created)


def delete_uid(kind, name, namespace, uid):
    resources = {'Namespace': 'namespaces', 'Pod': 'pods'}
    path = '/api/v1/' + (('namespaces/' + namespace + '/') if namespace else '') + resources[kind] + '/' + name
    answer = kube(['delete', '--raw', path, '-f', '-'], stdin=rt2.encoded({'apiVersion': 'v1', 'kind': 'DeleteOptions',
                 'preconditions': {'uid': uid}, 'propagationPolicy': 'Background'}), check=False)
    if answer.returncode and b'NotFound' not in answer.stderr:
        raise RuntimeError('UID_DELETE_FAILED: ' + name)


def source_spec(obj, omit_replicas=False):
    value = json.loads(json.dumps(obj['spec']))
    if omit_replicas:
        value.pop('replicas', None)
    return rt2.digest(rt2.encoded(value))


def scale_agent(name, replicas):
    if name not in ('gaia', 'hephaestus'):
        raise RuntimeError('SCALE_OUTSIDE_AGENTS')
    before = baseline['zero-door'][name]
    live = get('deployment', name, 'zero-door')
    if live['metadata']['uid'] != before['metadata']['uid'] or source_spec(live, True) != source_spec(before, True):
        raise RuntimeError('SCALE_REFUSED_UID_OR_SPEC_CHANGED: ' + name)
    if name not in scaled:
        scaled.append(name)
        save('scaled.json', scaled)
    kube(['scale', 'deployment/' + name, '-n', 'zero-door', '--current-replicas=' + str(live['spec']['replicas']),
          '--replicas=' + str(replicas), '--resource-version=' + live['metadata']['resourceVersion']])


def exec_pod(name, args, timeout=30, check=True, binary=False):
    return kube(['exec', '-n', NS, name, '--'] + args, timeout=timeout, check=check, binary=binary)


def driver(action):
    return json.loads(exec_pod('rt2-driver', ['/usr/bin/python3', '-B', '/rt2/r1_mode_runtime.py', 'call', action]).stdout)


def health(name):
    code = "import json,urllib.request; print(json.dumps(json.load(urllib.request.urlopen('http://127.0.0.1:8000/healthz',timeout=2))))"
    answer = exec_pod(name, ['/usr/bin/python3', '-c', code], check=False)
    if answer.returncode:
        return None
    value = json.loads(answer.stdout)
    return value if value.get('transport') == 'r1-o-gateway' and value.get('execution') == 'DISABLED_PENDING_GUARD' else None


def agent_pods():
    found = []
    for name in ('gaia', 'hephaestus'):
        select = baseline['zero-door'][name]['spec']['selector']['matchLabels']
        result = json.loads(kube(['get', 'pods', '-n', 'zero-door', '-l', ','.join(k+'='+v for k,v in select.items()), '-o', 'json']).stdout)
        found.extend(p for p in result['items'] if p['status'].get('phase') in ('Pending', 'Running'))
    return found


def extract_safe(data):
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for member in archive.getmembers():
            target = OUT / 'raw' / member.name
            if Path(member.name).is_absolute() or '..' in Path(member.name).parts or not (member.isfile() or member.isdir()):
                raise RuntimeError('UNSAFE_TAR')
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(member).read())


def run():
    global baseline, cfg, driver_up, target_deletes
    if os.environ.get('DOCKER_HOST'):
        raise RuntimeError('DOCKER_HOST_SET')
    if command(['docker', 'context', 'show']).stdout.decode().strip() != 'desktop-linux':
        raise RuntimeError('WRONG_DOCKER_CONTEXT')
    if kube(['config', 'get-contexts', CONTEXT, '-o', 'name']).stdout.decode().strip() != CONTEXT:
        raise RuntimeError('WRONG_CONTEXT')
    healthy()
    for ns in ('target-app', 'zero-door'):
        baseline[ns] = {d['metadata']['name']: d for d in get('deployments', namespace=ns)['items']}
    for ns, deps in baseline.items():
        for name, dep in deps.items():
            if dep['status'].get('availableReplicas', 0) < dep['spec'].get('replicas', 1):
                raise RuntimeError('BASELINE_UNREADY: ' + ns + '/' + name)
    save('baseline.json', baseline)
    save('quota-before.json', get('resourcequota', namespace='target-app'))
    hpas = json.loads(kube(['get', 'hpa', '-A', '-o', 'json']).stdout)
    save('hpas-before.json', hpas)
    if any(p['metadata']['namespace'] == 'target-app' and p['spec']['scaleTargetRef']['name'] == 'frontend' for p in hpas['items']):
        raise RuntimeError('FOREIGN_FRONTEND_HPA')
    save('policies-before.json', get('networkpolicy', namespace='target-app'))
    namespaces = get('namespaces')['items']
    if any(n['metadata']['name'] == NS for n in namespaces):
        raise RuntimeError('NAMESPACE_EXISTS')
    progress('Preflight complete; preparing exact source bundle')
    rt2.prepare(OUT / 'bundle', NS)
    cfg = json.loads((OUT / 'bundle/config.json').read_text())
    cfg['interval_s']=AUTH['observer_interval_s']
    cfg['max_gets']=AUTH['observer_max_gets']
    if AUTH['prior_request_upper_bound']+AUTH['warmup_max_gets']+cfg['max_gets']>360:
        raise RuntimeError('GLOBAL_GET_BUDGET')
    rt2.save(OUT/'bundle/config.json',cfg)
    resources=json.loads((OUT/'bundle/private-resources.json').read_text())
    for obj in resources['items']:
        if obj['kind']=='ConfigMap' and obj['metadata']['name']=='rt2-code':
            obj['data']['config.json']=json.dumps(cfg)
    rt2.save(OUT/'bundle/private-resources.json',resources)
    required = json.loads((ROOT / 'docs/evidence/ZER-11/rt2-preparation/verification.json').read_text())['source_hashes']
    required.update(AUTH['source_delta'])
    for rel, expected in required.items():
        if rt2.digest((ROOT / rel).read_bytes()) != expected:
            raise RuntimeError('REVIEWED_SOURCE_DRIFT: ' + rel)
    image = cfg['image']
    docker = ['docker', '--context', 'desktop-linux']
    progress('Reusing the one built/imported image; verify OCI index -> amd64 manifest -> config chain')
    chain=json.loads(Path(AUTH['image_chain']).read_text())
    inspect=json.loads(command(docker+['image','inspect',image]).stdout)[0]
    save('image-inspect.json',inspect)
    if not chain['oci_index_hash_verified'] or not chain['platform_manifest_hash_verified'] or inspect['Id']!=chain['docker_index_id'] or chain['image']!=image:
        raise RuntimeError('IMAGE_INDEX_CHAIN_MISMATCH')
    node_image=json.loads(command(docker+['exec','k3d-zero-door-server-0','crictl','inspecti',image]).stdout)
    save('node-image.json',node_image)
    if node_image['status']['id']!=chain['config_id'] or node_image['info']['imageSpec']['rootfs']['diff_ids']!=inspect['RootFS']['Layers'] or node_image['info']['imageSpec']['config']['Entrypoint']!=inspect['Config']['Entrypoint']:
        raise RuntimeError('NODE_IMAGE_CONFIG_MISMATCH')
    # Build/import may transiently stress the lab. Do not begin the observation until all original workloads are Ready again.
    def original_ready():
        for ns, deps in baseline.items():
            current = {d['metadata']['name']:d for d in get('deployments', namespace=ns)['items']}
            if any(current[n]['metadata']['uid'] != b['metadata']['uid'] or source_spec(current[n]) != source_spec(b)
                   for n,b in deps.items()):
                raise RuntimeError('BASELINE_DRIFT_AFTER_BUILD')
            if any(current[n]['status'].get('availableReplicas',0) < b['spec']['replicas'] for n,b in deps.items()):
                return False
        return True
    poll('original workloads after build', original_ready, 120)
    docs = json.loads((OUT / 'bundle/private-resources.json').read_text())['items']
    order = {'Namespace': 0, 'Secret': 1, 'ConfigMap': 2, 'Service': 3, 'NetworkPolicy': 4, 'Pod': 5}
    for obj in sorted(docs, key=lambda o: order[o['kind']]):
        create(obj)
    progress('Created temporary namespace and six restricted pods')
    poll('driver Running', lambda: pod_ready('rt2-driver'), 120)
    poll('driver control ready', lambda: driver('status'), 60)
    driver_up = True
    for name in ('gaia', 'hephaestus'):
        scale_agent(name, 0)
    poll('original agent pods absent', lambda: not agent_pods(), 90)
    for name in ['rt2-driver','rt2-console'] + ['rt2-'+g.lower() for g in rt2.GROUPS]:
        p = poll(name+' Running', lambda name=name:pod_ready(name), 120)
        save(name+'-pod.json', p)
        if p['status']['containerStatuses'][0]['imageID'] not in {inspect['Id'], node_image['status']['id'], chain['platform_manifest_id'], 'docker://'+inspect['Id']} | set(node_image['status'].get('repoDigests', [])):
            raise RuntimeError('POD_IMAGE_DIGEST_MISMATCH: '+name+' '+p['status']['containerStatuses'][0]['imageID'])
        att = json.loads(exec_pod(name, ['/usr/bin/python3','-B','/rt2/r1_mode_runtime.py','attest','--config','/rt2/config.json']).stdout)
        save(name+'-attest.json', att)
        if att['errors']:
            raise RuntimeError('POD_SOURCE_MISMATCH: '+name)
    for group in rt2.GROUPS:
        save('health-before-'+group+'.json', poll(group+' HTTP health', lambda group=group:health('rt2-'+group.lower()), 60))
    # Credential separation is a real filesystem check from the O-only console pod.
    separated = exec_pod('rt2-console', ['/usr/bin/python3','-c',"import pathlib; assert not pathlib.Path('/keys/gateway.json').exists(); assert not pathlib.Path('/keys/rules.json').exists(); print('O_ONLY_KEYS')"])
    save('console-separation.json', {'output':separated.stdout.decode()})
    progress('Image/source/wiring verified; warming the connection BEFORE the BM observation window')
    warm_code="import sys,json,time; sys.path.insert(0,'/rt2'); import r1_mode_runtime as r; rows=[]; good=0;\nfor i in range(20):\n try: code,_=r.http(r.TARGET,timeout=1); row={'status':code,'ok':code==200}\n except OSError as e: row={'status':None,'ok':False,'error':type(e).__name__}\n rows.append(row); good=good+1 if row['ok'] else 0\n if good>=10: break\n time.sleep(.5)\nr.save('/work/warmup.json',rows); print(json.dumps({'samples':rows,'healthy_streak':good})); sys.exit(0 if good>=10 else 1)"
    warm=json.loads(exec_pod('rt2-driver',['/usr/bin/python3','-c',warm_code],timeout=40).stdout)
    save('warmup.json',warm)
    if len(warm['samples'])>AUTH['warmup_max_gets'] or warm['healthy_streak']<10:
        raise RuntimeError('WARMUP_FAILED')
    progress('Warm-up complete and retained separately; beginning the full 180-second BM window at a slower bounded rate')
    driver('monitor')
    def initial_samples():
        s = driver('status')
        if s['failure']:
            raise RuntimeError('MONITOR_FAILED')
        return s if len(s['samples']) >= 10 and all(x['ok'] for x in s['samples']) else None
    save('healthy-baseline.json', poll('ten healthy BM samples', initial_samples, 30))
    healthy()
    if agent_pods():
        raise RuntimeError('ORIGINAL_AGENT_POD_IN_WINDOW')
    frontend = baseline['target-app']['frontend']
    live = get('deployment','frontend','target-app')
    if live['metadata']['uid'] != frontend['metadata']['uid'] or source_spec(live) != source_spec(frontend):
        raise RuntimeError('FRONTEND_SPEC_CHANGED')
    pods = json.loads(kube(['get','pods','-n','target-app','-l','app=frontend','-o','json']).stdout)['items']
    owned = [p for p in pods if p['status'].get('phase')=='Running' and not p['metadata'].get('deletionTimestamp')]
    if len(owned) != 1:
        raise RuntimeError('FRONTEND_POD_AMBIGUOUS')
    target = owned[0]
    owner = [o for o in target['metadata'].get('ownerReferences',[]) if o.get('controller') and o['kind']=='ReplicaSet']
    if len(owner)!=1:
        raise RuntimeError('FRONTEND_OWNER_AMBIGUOUS')
    rs = get('replicaset',owner[0]['name'],'target-app')
    if rs['metadata']['uid']!=owner[0]['uid'] or not any(o['uid']==frontend['metadata']['uid'] for o in rs['metadata'].get('ownerReferences',[])):
        raise RuntimeError('FRONTEND_REPLICASET_MISMATCH')
    save('fault-before.json', {'pod':target,'replicaset':rs,'at':time.time()})
    if target_deletes:
        raise RuntimeError('FRONTEND_DELETE_CAP')
    target_deletes += 1
    receipt['frontend_pod_deletes']=target_deletes
    save('receipt.json', receipt)  # count before request: an ambiguous outcome is never repeated
    delete_uid('Pod',target['metadata']['name'],'target-app',target['metadata']['uid'])
    progress('One frontend pod deletion sent with UID precondition; no second deletion allowed')
    manual = None
    while True:
        healthy()
        if agent_pods():
            raise RuntimeError('ORIGINAL_AGENT_POD_IN_WINDOW')
        summary = driver('status')
        save('latest-summary.json',summary)
        if summary['failure']:
            raise RuntimeError('MONITOR_FAILED: '+summary['failure'])
        for g, events in summary['events'].items():
            if any(e['event_type'] in rt2.FORBIDDEN for e in events):
                raise RuntimeError('ACTION_OR_LLM_IN_WINDOW')
        bm_decisions=[e for e in summary['events']['BM'] if e['event_type']=='DECISION']
        if manual is None and bm_decisions:
            raise RuntimeError('BM_AUTOMATIC_DECISION')
        detected=[e for e in summary['events']['BM'] if e['event_type']=='DETECTED']
        if detected and manual is None:
            ip=get('pod','rt2-bm',NS)['status']['podIP']
            wrong="import urllib.request,urllib.error; r=urllib.request.Request('http://"+ip+":8000/heal/trigger',data=b'{\"decision_id\":\"bad\"}',headers={'Content-Type':'application/json','Authorization':'Bearer wrong'});\ntry: urllib.request.urlopen(r,timeout=3); print(200)\nexcept urllib.error.HTTPError as e: print(e.code)"
            negative=exec_pod('rt2-console',['/usr/bin/python3','-c',wrong]).stdout.decode().strip()
            save('wrong-token.json',{'status':negative})
            if negative!='401':
                raise RuntimeError('WRONG_TOKEN_NOT_REFUSED')
            answer=exec_pod('rt2-console',['/usr/bin/python3','-B','/rt2/r1_mode_runtime.py','operator','--config','/rt2/config.json',
                '--keys','/keys/operator.json','--token','/keys/heal-operator.json','--url','http://rt2-o:9141','--heal-url','http://'+ip+':8000','--output','/work/manual.json'])
            manual=json.loads(answer.stdout)
            save('manual.json',manual)
            if (manual['status'],manual['body'])!=(409,{'detail':'R1_EXECUTOR_DISABLED'}):
                raise RuntimeError('MANUAL_EXECUTOR_NOT_DISABLED')
            progress('Live HTTP failure observed; scripted MANUAL proposal refused at the real disabled executor')
            driver('controls')
        if not summary['monitor_alive']:
            break
        time.sleep(2)
    if manual is None:
        raise RuntimeError('NO_LIVE_FAILURE_INCONCLUSIVE_NO_SECOND_DELETE')
    logs={}
    for group in rt2.GROUPS:
        name='rt2-'+group.lower()
        save('health-after-'+group+'.json',health(name))
        logs[group]=kube(['logs','-n',NS,name]).stdout.decode()
        save('last-pod-'+group+'.json',get('pod',name,NS))
    save('logs.json',logs)
    # Stop actors before seal: no late writer can change the exported set after validation.
    for record in created:
        if record['kind']=='Pod' and record['name'] in ['rt2-'+g.lower() for g in rt2.GROUPS]:
            delete_uid('Pod',record['name'],NS,record['uid'])
    poll('actor pods absent before seal', lambda:all(absent('pod','rt2-'+g.lower(),NS) for g in rt2.GROUPS),60)
    final=driver('finish')
    save('summary.json',final)
    result=rt2.assess(final,logs,manual)
    save('assessment.json',result)
    if result['errors']:
        raise RuntimeError('BOUNDARY_ASSESSMENT_FAILED: '+str(result['errors']))
    # /work has O raw and diagnostics only; its Secret is mounted under /keys and never tarred.
    tarcode="import io,sys,tarfile; t=tarfile.open(fileobj=sys.stdout.buffer,mode='w|'); t.add('/work',arcname='work'); t.close()"
    extract_safe(exec_pod('rt2-driver',['/usr/bin/python3','-c',tarcode],timeout=60,binary=True).stdout)
    receipt['verdict']='PASS_BOUNDARY_PENDING_CLEANUP'
    progress('RT2 boundary passed; exporting O and restoring original lab')


def cleanup_run():
    global cleaning
    cleaning=True
    # Every step is isolated: failure pulling evidence must not stop restoration of the original agents.
    if driver_up and not (OUT/'raw').exists():
        try:
            state=driver('status')
            save('abort-summary.json',state)
            tarcode="import sys,tarfile; t=tarfile.open(fileobj=sys.stdout.buffer,mode='w|'); t.add('/work',arcname='work'); t.close()"
            extract_safe(exec_pod('rt2-driver',['/usr/bin/python3','-c',tarcode],timeout=30,binary=True).stdout)
            cleanup.append({'step':'salvage','result':'RAW_PULLED_NOT_SEALED'})
        except Exception as error:
            cleanup.append({'step':'salvage','error':str(error)})
    try:
        record=next((x for x in created if x['kind']=='Namespace'),None)
        if record:
            found=kube(['get','namespace',NS,'-o','json'],check=False)
            if found.returncode==0:
                live=json.loads(found.stdout)
                if live['metadata'].get('labels',{}).get(LABEL)!=NS or (record['uid'] and live['metadata']['uid']!=record['uid']):
                    raise RuntimeError('NAMESPACE_OWNER_CHANGED')
                record['uid']=live['metadata']['uid']
                delete_uid('Namespace',NS,None,record['uid'])
                poll('namespace absent',lambda:absent('namespace',NS),120)
            elif b'NotFound' not in found.stderr:
                raise RuntimeError('NAMESPACE_ABSENCE_UNVERIFIED')
            cleanup.append({'step':'namespace','result':'ABSENT'})
    except Exception as error:
        cleanup.append({'step':'namespace','error':str(error)})
    for name in list(scaled):
        try:
            scale_agent(name,baseline['zero-door'][name]['spec']['replicas'])
            poll('restored '+name,lambda name=name:get('deployment',name,'zero-door')['status'].get('availableReplicas',0)>=baseline['zero-door'][name]['spec']['replicas'],90)
            cleanup.append({'step':'restore '+name,'result':'RESTORED'})
        except Exception as error:
            cleanup.append({'step':'restore '+name,'error':str(error)})
    try:
        post={}
        differences=[]
        for ns,deps in baseline.items():
            post[ns]={d['metadata']['name']:d for d in get('deployments',namespace=ns)['items']}
            for name,before in deps.items():
                live=post[ns].get(name)
                if not live or live['metadata']['uid']!=before['metadata']['uid'] or source_spec(live)!=source_spec(before) or live['status'].get('availableReplicas',0)<before['spec']['replicas']:
                    differences.append(ns+'/'+name)
        save('postflight.json',{'deployments':post,'differences':differences})
        cleanup.append({'step':'postflight','result':'UNCHANGED_READY' if not differences else 'DIFFERENT','differences':differences})
    except Exception as error:
        cleanup.append({'step':'postflight','error':str(error)})


if __name__=='__main__':
    if (OUT/'started.json').exists():
        raise SystemExit('SINGLE_USE_ONLY; reconcile existing receipt before any further action')
    save('started.json',{'at':time.time(),'deadline':END})
    try:
        run()
    except BaseException as error:
        errors.append({'type':type(error).__name__,'message':str(error),'trace':traceback.format_exc()})
        receipt['verdict']='INCOMPLETE'
        progress('Stopping: '+str(error))
    finally:
        cleanup_run()
        receipt['ended_at']=dt.datetime.now(dt.timezone.utc).isoformat()
        receipt['elapsed_s']=time.time()-dt.datetime.fromisoformat(AUTH['started_at'].replace('Z','+00:00')).timestamp()
        clean=bool(baseline) and all('error' not in step and step.get('result')!='DIFFERENT' for step in cleanup)
        receipt['cleanup_verdict']='CLEAN' if clean else 'INCOMPLETE'
        if receipt['verdict']=='PASS_BOUNDARY_PENDING_CLEANUP' and clean:
            receipt['verdict']='PASS_SCOPED_RT2'
        elif not clean:
            receipt['verdict']='INCOMPLETE'
        save('receipt.json',receipt)
        progress(json.dumps({'verdict':receipt['verdict'],'cleanup':receipt['cleanup_verdict'],'target_deletes':target_deletes,'elapsed_s':receipt['elapsed_s']}))
    raise SystemExit(0 if receipt['verdict']=='PASS_SCOPED_RT2' else 1)
