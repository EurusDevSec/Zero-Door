#!/usr/bin/env bash
set -euo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1 MSYS_NO_PATHCONV=1
scratch/zer12/production-hephaestus/Scripts/python.exe -B scratch/zer11/rt2-runtime-f8f94738/attempt-03/host.py > scratch/zer11/rt2-runtime-f8f94738/attempt-03/host.log 2>&1
