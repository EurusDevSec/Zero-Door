import json,pathlib,subprocess
out=pathlib.Path(__file__).resolve().parent
code="import json,socket,sys; sys.path.insert(0,'/rt2'); import r1_mode_runtime as r; status,_=r.http('http://rt2-o:9141/events?run_id=run_448f91cf7fca4e89ba40a4b957f86a96'); blocked=False;\ntry: s=socket.create_connection(('10.42.1.167',9140),timeout=2); s.close()\nexcept OSError: blocked=True\nprint(json.dumps({'unauthenticated_o_status':status,'control_port_unreachable_from_console':blocked})); assert status==401 and blocked"
argv=['kubectl','--context','k3d-zero-door','--request-timeout=15s','exec','-n','zd-zer11-rt2-8320ed75','rt2-console','--','/usr/bin/python3','-c',code]
r=subprocess.run(argv,capture_output=True,timeout=20,check=True)
(out/'boundary-network.json').write_bytes(r.stdout)
print(r.stdout.decode())
