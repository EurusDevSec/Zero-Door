#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1
scratch/zer12/production-nemesis/Scripts/python.exe -B tests/test_dashboard_mode_runtime.py > scratch/zer11/rt2-preparation/nemesis.log 2>&1
rc=$?
cat scratch/zer11/rt2-preparation/nemesis.log
exit "$rc"
