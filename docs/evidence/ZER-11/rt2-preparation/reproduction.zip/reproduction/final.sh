#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1
status=0
for pin in nemesis hephaestus; do
  RT2_KEEP=scratch/zer11/rt2-preparation/evidence-$pin scratch/zer12/production-$pin/Scripts/python.exe -B tests/test_dashboard_mode_runtime.py > scratch/zer11/rt2-preparation/$pin-complete.log 2>&1 || status=1
  cat scratch/zer11/rt2-preparation/$pin-complete.log
done
scratch/zer12/test-venv/Scripts/python.exe -m bandit -q infrastructure/scripts/r1_mode_runtime.py > scratch/zer11/rt2-preparation/bandit-final.log 2>&1 || status=1
cat scratch/zer11/rt2-preparation/bandit-final.log
bash -n infrastructure/scripts/verify-dashboard-modes.sh || status=1
ZD_PYTHON=scratch/zer12/production-hephaestus/Scripts/python.exe bash infrastructure/scripts/verify-dashboard-modes.sh --help > scratch/zer11/rt2-preparation/help.txt || status=1
ZD_PYTHON=scratch/zer12/production-hephaestus/Scripts/python.exe bash infrastructure/scripts/verify-dashboard-modes.sh plan > scratch/zer11/rt2-preparation/plan-final.json || status=1
git diff --check || status=1
printf 'OVERALL=%s\n' "$status"
exit "$status"
