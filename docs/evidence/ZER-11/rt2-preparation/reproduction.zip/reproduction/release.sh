#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1
status=0
for pin in nemesis hephaestus; do
  RT2_KEEP=scratch/zer11/rt2-preparation/release-$pin scratch/zer12/production-$pin/Scripts/python.exe -B tests/test_dashboard_mode_runtime.py > scratch/zer11/rt2-preparation/$pin-release.log 2>&1 || status=1
  cat scratch/zer11/rt2-preparation/$pin-release.log
done
scratch/zer12/test-venv/Scripts/python.exe -m bandit -q infrastructure/scripts/r1_mode_runtime.py > scratch/zer11/rt2-preparation/bandit-release.log 2>&1 || status=1
cat scratch/zer11/rt2-preparation/bandit-release.log
bash -n infrastructure/scripts/verify-dashboard-modes.sh || status=1
git diff --check || status=1
printf 'OVERALL=%s\n' "$status"
exit "$status"
