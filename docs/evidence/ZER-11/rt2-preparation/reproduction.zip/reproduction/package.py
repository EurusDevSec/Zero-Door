import difflib, hashlib, json, pathlib, zipfile
root=pathlib.Path.cwd()
work=root/'scratch/zer11/rt2-preparation'
out=root/'docs/evidence/ZER-11/rt2-preparation'
intake=json.loads((work/'intake.json').read_text())
changed=['infrastructure/scripts/r1_mode_runtime.py','infrastructure/scripts/verify-dashboard-modes.sh','tests/test_dashboard_mode_runtime.py','.github/workflows/ci.yml','docs/runbooks/dashboard-and-baselines.md']
patch=[]
for rel in changed:
    old=work/'before'/rel
    before=old.read_text(encoding='utf-8').splitlines(keepends=True) if old.exists() else []
    after=(root/rel).read_text(encoding='utf-8').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(before,after,fromfile='before/'+rel,tofile='after/'+rel))
(out/'source.diff').write_text(''.join(patch),encoding='utf-8')
for rel,kind in [('docs/delivery/NOW.md','prepend'),('docs/delivery/milestones/R1-measurement/dashboard-and-baselines.md','append')]:
    before=(work/'before'/rel).read_bytes()
    after=(root/rel).read_bytes()
    assert after.endswith(before) if kind=='prepend' else after.startswith(before),rel
with zipfile.ZipFile(out/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(work.rglob('*')):
        if path.is_file() and path.suffix in {'.py','.sh','.json','.log','.md','.txt','.yml'}:
            archive.write(path,'reproduction/'+str(path.relative_to(work)).replace('\\','/'))
    for rel in changed:
        archive.write(root/rel,'current/'+rel)
record={'zip_sha256':hashlib.sha256((out/'reproduction.zip').read_bytes()).hexdigest(), 'zip_bytes':(out/'reproduction.zip').stat().st_size}
(out/'archive.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
