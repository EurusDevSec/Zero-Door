#!/usr/bin/env bash
set -euo pipefail
cd /r/_Projects/Eurus_Workspace/zero_door
gitnexus analyze --pdg --index-only > scratch/zer11/rt2-preparation/gitnexus.log 2>&1
tail -n 12 scratch/zer11/rt2-preparation/gitnexus.log
