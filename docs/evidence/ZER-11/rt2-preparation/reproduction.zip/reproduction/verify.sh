#!/usr/bin/env bash
set -u
cd /r/_Projects/Eurus_Workspace/zero_door
export PYTHONDONTWRITEBYTECODE=1
status=0
for pin in nemesis hephaestus; do
  scratch/zer12/production-$pin/Scripts/python.exe -B tests/test_dashboard_mode_runtime.py > scratch/zer11/rt2-preparation/$pin-final.log 2>&1 || status=1
  cat scratch/zer11/rt2-preparation/$pin-final.log
done
scratch/zer12/production-hephaestus/Scripts/python.exe -B tests/test_dashboard_modes.py > scratch/zer11/rt2-preparation/modes-regression.log 2>&1 || status=1
cat scratch/zer11/rt2-preparation/modes-regression.log
scratch/zer12/test-venv/Scripts/python.exe -m bandit -q infrastructure/scripts/r1_mode_runtime.py > scratch/zer11/rt2-preparation/bandit.log 2>&1 || status=1
cat scratch/zer11/rt2-preparation/bandit.log
bash -n infrastructure/scripts/verify-dashboard-modes.sh || status=1
ZD_PYTHON=scratch/zer12/production-hephaestus/Scripts/python.exe bash infrastructure/scripts/verify-dashboard-modes.sh plan > scratch/zer11/rt2-preparation/plan.json || status=1
git diff --check || status=1
printf 'OVERALL=%s\n' "$status"
exit "$status"
