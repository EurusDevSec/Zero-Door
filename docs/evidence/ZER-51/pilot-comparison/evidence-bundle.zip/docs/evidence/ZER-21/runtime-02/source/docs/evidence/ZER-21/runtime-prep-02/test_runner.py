"""Offline native boundaries; all provider/Kafka/Kubernetes operations are fake."""
import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import run
import lab
import render


def inputs():
    ctx={'run_id':lab.new_id('run'),'trial_id':lab.new_id('trl'),'incident_id':lab.new_id('inc'),
        'group':'B2','method_version':'zer21-functional/1','config_ref':'sha256:'+'4'*64}
    command={'commandId':'55555555-5555-4555-8555-555555555555','context':{k:ctx[k] for k in ('run_id','trial_id','group')}}
    stamp=lambda n:datetime.fromtimestamp(n,timezone.utc).isoformat()
    send={'seq':1,'startedAt':stamp(100),'observedAt':stamp(102),'requestId':command['commandId']+'/1',
        'responseId':'a'*32,'status':200,'rows':2,'restrictedRows':1}
    result={'commandId':command['commandId'],'status':'SUCCESS','details':{'sqli':{'sends':[send]}}}
    receipt={'records':[{'event':'DISPATCH_INTENT','command':command},{'event':'EXECUTOR_RESULT','raw':result}]}
    raw={'request_id':'a'*32,'correlation_id':send['requestId'],'ts':101,'method':'GET',
        'path':'/fixture/catalog/search','status':200,'rows':2,'restricted_rows':1,
        'client_ip':'10.42.0.11','tcp_peer':'10.42.0.12','source_method':'XFF_AFTER_TRUSTED','source_confidence':'PROXY_CHAIN'}
    kw={'fixture_uid':'fixture-uid','pod_uid':'fixture-uid','source_ip':raw['client_ip'],
        'proxy_ip':raw['tcp_peer'],'begin':99,'end':103,'at':104,'ref':'worker-native-join.json'}
    return ctx,receipt,raw,kw


class Native(unittest.TestCase):
    def setUp(self):
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'))
        self.net.start();self.addCleanup(self.net.stop)
        self.native=patch.object(subprocess,'run',side_effect=AssertionError('NO_NATIVE_OPERATION'))
        self.native.start();self.addCleanup(self.native.stop)

    def test_raw_worker_join_keeps_rule_and_benign_value(self):
        ctx,receipt,raw,kw=inputs()
        got=lab.project_worker(ctx,receipt,raw,**kw)
        self.assertEqual(1,got['detection']['payload']['value'])
        self.assertEqual(got['detection']['event_id'],got['access']['detection_event_id'])
        self.assertNotIn('expected',json.dumps(got))
        raw['restricted_rows']=0;receipt['records'][1]['raw']['details']['sqli']['sends'][0]['restrictedRows']=0
        self.assertEqual(0,lab.project_worker(ctx,receipt,raw,**kw)['detection']['payload']['value'])

    def test_raw_join_rejects_id_uid_context_source_time_count_and_failed_delivery(self):
        for field,value in [('request_id','f'*32),('correlation_id','foreign'),('client_ip','10.42.0.99'),
                ('tcp_peer','10.42.0.99'),('source_confidence','UNKNOWN'),('source_method','DIRECT'),
                ('ts',98),('status',403),('rows',3),('restricted_rows',0),('delivered',False)]:
            ctx,receipt,raw,kw=inputs();raw[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)
        for key,value in [('pod_uid','foreign'),('at',170)]:
            ctx,receipt,raw,kw=inputs();kw[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)
        ctx,receipt,raw,kw=inputs();receipt['records'][0]['command']['context']=dict(ctx,group='B1')
        with self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)

    def test_cardinality_and_worker_failure_and_timezone_are_not_success(self):
        for mutate in [lambda r:r['records'].append(deepcopy(r['records'][0])),
                lambda r:r['records'][1]['raw'].update(status='FAILED'),
                lambda r:r['records'][1]['raw']['details']['sqli']['sends'][0].update(startedAt='1970-01-01T00:01:40'),
                lambda r:r['records'][1]['raw']['details']['sqli']['sends'][0].update(rows=True)]:
            ctx,receipt,raw,kw=inputs();mutate(receipt)
            with self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)

    def test_actual_kube_forwards_bounded_topic_commands_and_claims(self):
     native=lab.make_lab(); native.broker_uid='broker-owned'; calls=[]
     def command(args,timeout=15,allowed=(0,)):
      calls.append((args,timeout,allowed))
      self.assertEqual(['kubectl','--context','k3d-zero-door','--request-timeout=12s'],args[:4])
      if args[4:]==['-n','zero-door','get','pod','kafka-controller-0','-o','json']:
       return subprocess.CompletedProcess(args,0,b'{"metadata":{"uid":"broker-owned"}}')
      self.assertEqual(10,timeout);self.assertIn('/opt/bitnami/kafka/bin/kafka-topics.sh',args)
      if '--create' in args:
       self.assertEqual((0,1),allowed)
       self.assertEqual('UNKNOWN',native.topic_state[native.topics[0]])
      return subprocess.CompletedProcess(args,0,(native.topics[0]+'\n').encode() if '--list' in args else b'')
     with patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY')),patch.object(subprocess,'Popen',side_effect=AssertionError('NO_NATIVE_OPERATION')),patch.object(native,'command',side_effect=command),patch.object(native,'checkpoint'):
      native.topic('create',native.topics[0]);self.assertEqual('OWNED',native.topic_state[native.topics[0]])
      self.assertEqual([native.topics[0]],native.topic('list',native.topics[0]))
      native.topic('delete',native.topics[0])
      with self.assertRaisesRegex(ValueError,'TOPIC_ALREADY_ATTEMPTED'):native.topic('create',native.topics[0])
     topic_calls=[c for c in calls if '/opt/bitnami/kafka/bin/kafka-topics.sh' in c[0]]
     self.assertEqual(3,len(topic_calls))

    def test_actual_provenance_and_manifest_are_pinned(self):
        provenance=lab.worker_build_provenance()
        self.assertEqual(3,len(provenance['source_paths']))
        self.assertIs(False,provenance['full_build_context_attested'])
        self.assertGreater(len(run.verify_sources()['sha256']),50)
        with patch.object(lab.supervisor,'sha',return_value='0'*64):
            with self.assertRaisesRegex(ValueError,'CACHED_WORKER_SOURCE_DRIFT'):lab.worker_build_provenance()

    def test_renderer_stays_private_and_limits_one_send(self):
        ctx,_,_,_=inputs()
        docs=render.render('zer46-123456abcdef',ctx['run_id'],ctx['trial_id'],'10.42.0.12')
        self.assertEqual(4,len([d for d in docs if d['kind'] in {'Deployment','Pod'}]))
        self.assertNotIn('Ingress',{d['kind'] for d in docs})
        alias=next(d for d in docs if d['kind']=='Service' and d['metadata']['name']=='zer41-private-ingress')
        self.assertEqual('ClusterIP',alias['spec'].get('type','ClusterIP'))
        extra,containers,volumes,policy=render.worker_documents(ctx,'zer46-123456abcdef','10.43.0.11')
        self.assertTrue(policy['enabled']);self.assertEqual({k:ctx[k] for k in ('run_id','trial_id','group')},policy['context'])
        for k in ['maxDurationSec','maxConcurrency','rps']:self.assertEqual(1,policy[k])
        self.assertEqual(1,policy['sqli']['maxSends']);self.assertEqual(1,policy['sqli']['maxCommandSec'])
        self.assertTrue(all(c['imagePullPolicy']=='Never' for c in containers))
        self.assertNotIn('OPENAI_API_KEY',[e['name'] for c in containers for e in c['env']])
        from event_pipeline.llm import Adapter, RunBudget, Limits
        adapter=Adapter(object(),RunBudget(ctx['run_id'],max_calls=3,max_reserved_tokens=30000,max_estimated_usd=.015,duration_s=300),limits=Limits(attempts=1,max_output_tokens=256))
        session=lab.Session(purpose=lab.PURPOSE,guard=lab.CommandGuard(policy),adapter=adapter,observe=None,execute=None,context=ctx,limits=lab.SessionLimits(max_rounds=1,command_s=1,allowed_templates=('disclose-restricted',)))
        self.assertEqual(ctx,session.context)
        network=next(d for d in extra if d['kind']=='NetworkPolicy')
        self.assertEqual([{'protocol':'TCP','port':9092}],network['spec']['egress'][0]['ports'])
        for address in ['8.8.8.8','127.0.0.1','0.0.0.0','169.254.1.1','240.0.0.1','224.0.0.1','::1']:
            with self.subTest(address=address),self.assertRaises(ValueError):render.worker_documents(ctx,'zer46-123456abcdef',address)

    def test_default_and_unapproved_attempt_never_start_child(self):
        with patch.object(sys,'argv',['run.py']),patch.object(run,'execute',side_effect=AssertionError('NO_WORK')):
            self.assertEqual(0,run.main())
        with patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
            with self.assertRaisesRegex(ValueError,'FRESH_EXACT_OWNER_APPROVAL_REQUIRED'):
                run.execute(run.PREP/'approval-template.json')

    def test_wrong_expiry_and_manifest_or_proposal_pin_stop_before_child(self):
        import time
        auth=json.loads((run.PREP/'approval-template.json').read_bytes());auth.update(approved=True,expires_epoch=time.time()+60)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'auth.json'
            for change in [{'expires_epoch':time.time()-1},{'proposal_sha256':'0'*64},
                    {'source_manifest_sha256':'0'*64},{'issue':'ZER-50'}]:
                path.write_text(json.dumps(dict(auth,**change)))
                with patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
                    with self.assertRaises(ValueError):run.execute(path)

    def test_consumed_attempt_and_direct_child_cannot_replay(self):
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)
            with patch.object(run,'OUT',out),patch.object(run,'admit',return_value={}),patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
                with self.assertRaises(FileExistsError):run.execute('fake')
            with patch.object(lab.fixture,'OUT',out):
                with self.assertRaises(FileNotFoundError):lab.claim_work()
                (out/'started.json').write_text(json.dumps({'head':run.HEAD}))
                with patch.object(run,'admit',return_value={}):
                    lab.claim_work()
                    with self.assertRaises(FileExistsError):lab.claim_work()

    def test_source_uid_and_http_bound_stop_before_dispatch(self):
        native=lab.make_lab();native.fixture_http=8
        with patch.object(native,'command',side_effect=AssertionError('NO_LAB')):
            with self.assertRaisesRegex(ValueError,'ZER21_HTTP_BUDGET'):native.http('a')
        native.source_uids={'a':'owned'}
        with patch.object(native,'pod',return_value={'metadata':{'uid':'foreign'}}):
            with self.assertRaisesRegex(ValueError,'SOURCE_POD_UID_DRIFT'):native.check_sources()

    def test_api_single_attempt_and_topic_unknown_ownership(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        class API:
            writes=0;api_client=None
            def replace_namespaced_config_map(self,*a,**kw):self.writes+=1;return {'accepted':True}
        api=API()
        with patch.object(base,'native_api',return_value=(api,None)),patch.object(native,'check_sources'),patch.object(native,'pod'):
            single,_=native.native_api();single.replace_namespaced_config_map()
            with self.assertRaisesRegex(ValueError,'SINGLE_API_WRITE_BOUND'):single.replace_namespaced_config_map()
        native.topic_state={'owned.commands':'UNKNOWN'};calls=[]
        def topic(operation,name):
            calls.append(operation);return [name]
        with patch.object(base,'cleanup_owned',return_value={'namespace_absent':True,'verdict':'CLEAN'}),patch.object(native,'topic',side_effect=topic),patch.object(native,'save'):
            result=native.cleanup_owned()
        self.assertEqual('INCOMPLETE',result['verdict']);self.assertEqual(['list'],calls)
        native.topic_state={'owned.commands':'OWNED'};calls=[]
        def owned_topic(operation,name):
            calls.append(operation);return [name] if calls==['list'] else []
        with patch.object(base,'cleanup_owned',return_value={'namespace_absent':True,'verdict':'CLEAN'}),patch.object(native,'topic',side_effect=owned_topic),patch.object(native,'save'):
            self.assertEqual('CLEAN',native.cleanup_owned()['verdict'])
        self.assertEqual(['list','delete','list'],calls)

    def test_identity_drift_at_action_boundary_stops_api_write(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        class API:
            writes=0;api_client=None
            def replace_namespaced_config_map(self,*a,**kw):raise AssertionError('NO_NATIVE_WRITE')
        for method in ('check_sources','pod'):
            with self.subTest(method=method),patch.object(base,'native_api',return_value=(API(),None)),patch.object(native,'check_sources'),patch.object(native,'pod'):
                with patch.object(native,method,side_effect=ValueError('IDENTITY_DRIFT')):
                    api,_=native.native_api()
                    with self.assertRaisesRegex(ValueError,'IDENTITY_DRIFT'):api.replace_namespaced_config_map()
                    self.assertEqual(0,api.writes)

    def test_foreign_namespace_or_broker_never_deletes_topics(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        native.topic_state={native.topics[0]:'OWNED'}
        with patch.object(base,'cleanup_owned',return_value={'namespace_absent':False,'verdict':'INCOMPLETE'}),patch.object(native,'topic',side_effect=AssertionError('NO_TOPIC_DELETE')):
            self.assertEqual('INCOMPLETE',native.cleanup_owned()['verdict'])
        native.broker_uid='owned'
        with patch.object(native,'kube',return_value=subprocess.CompletedProcess([],0,b'{"metadata":{"uid":"foreign"}}')):
            with self.assertRaisesRegex(ValueError,'BROKER_UID_DRIFT'):native.topic('delete',native.topics[0])

    def test_source_manifest_rejects_path_escape_or_drift(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);prep=root/'prep';prep.mkdir()
            for path in ['../outside','missing']:
                (prep/'source-manifest.json').write_text(json.dumps({'sha256':{path:'0'*64}}))
                with self.assertRaises((ValueError,FileNotFoundError)):run.verify_sources(root,prep)


class NativeAsync(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'))
        self.net.start();self.addCleanup(self.net.stop)

    async def test_cancellation_drains_one_reserved_worker_execution_without_retry(self):
        import threading
        native=lab.make_lab();native.fixture_http=1
        entered=threading.Event();release=threading.Event();calls=[]
        def execute(*a,**kw):
            calls.append(a);entered.set();release.wait(timeout=2)
            return subprocess.CompletedProcess([],0,b'{"status":"SUCCESS"}')
        with patch.object(native,'check_sources'),patch.object(native,'save'),patch.object(native,'checkpoint'),patch.object(native,'input_command',side_effect=execute):
            task=asyncio.create_task(native.execute_worker({'commandId':'fake'}))
            await asyncio.to_thread(entered.wait,1)
            self.assertTrue(entered.is_set());task.cancel();await asyncio.sleep(.01)
            self.assertFalse(task.done());release.set()
            with self.assertRaises(asyncio.CancelledError):await task
            with self.assertRaisesRegex(ValueError,'EXECUTOR_REPLAY'):await native.execute_worker({})
        self.assertEqual(1,len(calls));self.assertEqual(2,native.fixture_http)


if __name__=='__main__':unittest.main(verbosity=2)
