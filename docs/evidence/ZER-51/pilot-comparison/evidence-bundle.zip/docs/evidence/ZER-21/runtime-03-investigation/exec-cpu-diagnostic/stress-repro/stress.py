"""ZER-21 stress repro: how often does a benign `kubectl exec` into a Source-B-identical
container (50m CPU) get an anomalous CPU charge, and is it user or system time?

Bounds: namespace zd-diag-cpu2 only; Source B pod spec (image zer46-fixture, 50m/48Mi);
groups A (warm pod, idle) 150 execs, B (fresh pod, first exec) 20 pods, C (warm pod while a
churn pod is created/deleted every ~8 s) 100 execs; 40 s cap per exec; 25 min wall cap;
memory guard before each group; namespace deleted and verified at the end.
Exec payload prints only (no socket connect). No model, fixture, HTTP, SQLi or Kafka.
"""
import json, subprocess, sys, threading, time
from pathlib import Path

OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
NS, NODE = "zd-diag-cpu2", "k3d-zero-door-agent-0"
K = ["kubectl", "--context", "k3d-zero-door", "--request-timeout=12s"]
D = ["docker", "--context", "desktop-linux", "exec", NODE]
END = time.monotonic() + 25 * 60
PAYLOAD = "import socket,json\nprint(json.dumps({'ok':1}))"
log_file = open(OUT / "run.log", "a", encoding="utf-8")
samples = open(OUT / "samples.jsonl", "a", encoding="utf-8")


def log(*parts):
    line = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + " " + " ".join(map(str, parts))
    print(line, flush=True); log_file.write(line + "\n"); log_file.flush()


def run(args, timeout=20, stdin=None):
    return subprocess.run(args, input=stdin, capture_output=True, timeout=timeout)


def guard():
    mem = int(next(l.split()[1] for l in run(D + ["cat", "/proc/meminfo"]).stdout.decode().splitlines()
                   if l.startswith("MemAvailable")))
    log("guard MemAvailableKiB", mem)
    if mem < 1048576 or time.monotonic() > END:
        raise RuntimeError("GUARD_STOP")


def pod_doc(name, labels="stress"):
    return {"apiVersion": "v1", "kind": "Pod", "metadata": {"name": name, "namespace": NS,
        "labels": {"zero-door.io/run": "zer21-diag-cpu2", "role": labels}},
        "spec": {"automountServiceAccountToken": False, "restartPolicy": "Never", "activeDeadlineSeconds": 1800,
            "securityContext": {"runAsNonRoot": True, "runAsUser": 65532, "runAsGroup": 65532,
                                "seccompProfile": {"type": "RuntimeDefault"}},
            "nodeSelector": {"kubernetes.io/hostname": NODE},
            "containers": [{"name": "source", "image": "zer46-fixture:24662046a33f", "imagePullPolicy": "Never",
                "command": ["/usr/bin/python3", "-c", "import time; time.sleep(1800)"],
                "securityContext": {"allowPrivilegeEscalation": False, "readOnlyRootFilesystem": True,
                                    "capabilities": {"drop": ["ALL"]}},
                "resources": {"requests": {"cpu": "5m", "memory": "16Mi"}, "limits": {"cpu": "50m", "memory": "48Mi"}}}]}}


def create(name, role="stress", wait=True):
    run(K + ["apply", "-f", "-"], stdin=json.dumps(pod_doc(name, role)).encode())
    if wait:
        r = run(K + ["-n", NS, "wait", "--for=condition=Ready", "pod/" + name, "--timeout=90s"], timeout=100)
        if r.returncode:
            raise RuntimeError("NOT_READY " + name)
        pod = json.loads(run(K + ["-n", NS, "get", "pod", name, "-o", "json"]).stdout)
        uid = pod["metadata"]["uid"]; cid = pod["status"]["containerStatuses"][0]["containerID"].split("://")[-1]
        cg = run(D + ["sh", "-c", "ls -d /sys/fs/cgroup/kubepods/*/pod%s/%s" % (uid, cid)]).stdout.decode().strip()
        if not cg:
            raise RuntimeError("CGROUP_NOT_FOUND " + name)
        return cg


def stat(cg):
    text = run(D + ["sh", "-c", "cat %s/cpu.stat; echo @@; cat /proc/pressure/cpu /proc/loadavg" % cg]).stdout.decode()
    head, tail = text.split("@@\n")
    return {k: int(v) for k, v in (l.split() for l in head.splitlines() if l.strip())}, tail.strip().replace("\n", " | ")


def one(group, i, pod, cg):
    before, _ = stat(cg)
    t0 = time.monotonic()
    try:
        r = run(K + ["-n", NS, "exec", pod, "--", "/usr/bin/python3", "-c", PAYLOAD], timeout=40)
        rc, out = r.returncode, (r.stdout + r.stderr).decode(errors="replace")[:200]
    except subprocess.TimeoutExpired:
        rc, out = "TIMEOUT", ""
    wall = time.monotonic() - t0
    after, vm = stat(cg)
    later = None
    usage = after["usage_usec"] - before["usage_usec"]
    if usage > 300_000 or wall > 5 or rc != 0:
        time.sleep(3); later, _ = stat(cg)  # Debt shows as flat usage with rising nr_throttled.
    row = {"group": group, "i": i, "pod": pod, "rc": rc, "wall": round(wall, 3), "out": out,
           "before": before, "after": after, "later": later, "vm": vm, "at": time.time()}
    samples.write(json.dumps(row) + "\n"); samples.flush()
    flag = " ANOMALY" if later is not None else ""
    log(group, i, "rc", rc, "wall %.2f cpu_ms %.0f user_ms %.0f sys_ms %.0f" % (wall, usage / 1000,
        (after["user_usec"] - before["user_usec"]) / 1000, (after["system_usec"] - before["system_usec"]) / 1000) + flag)


def churn(stop):
    n = 0
    while not stop.is_set() and time.monotonic() < END:
        name = "churn-%d" % n; n += 1
        run(K + ["apply", "-f", "-"], stdin=json.dumps(pod_doc(name, "churn")).encode())
        stop.wait(8)
        run(K + ["-n", NS, "delete", "pod", name, "--wait=false", "--grace-period=1"])


try:
    guard()
    if run(K + ["create", "namespace", NS]).returncode:
        raise RuntimeError("NAMESPACE_CREATE")
    log("group A: warm pod, idle")
    cg = create("warm")
    for i in range(1, 151):
        if time.monotonic() > END: raise RuntimeError("WALL_CAP")
        one("A", i, "warm", cg)
    guard(); log("group B: fresh pod, first exec")
    for i in range(1, 21):
        if time.monotonic() > END: raise RuntimeError("WALL_CAP")
        name = "fresh-%d" % i
        fcg = create(name); time.sleep(5)
        one("B", i, name, fcg)
        run(K + ["-n", NS, "delete", "pod", name, "--wait=false", "--grace-period=1"])
    guard(); log("group C: warm pod during pod churn")
    stop = threading.Event(); worker = threading.Thread(target=churn, args=(stop,), daemon=True); worker.start()
    try:
        for i in range(1, 101):
            if time.monotonic() > END: raise RuntimeError("WALL_CAP")
            one("C", i, "warm", cg)
    finally:
        stop.set(); worker.join(timeout=30)
    log("done")
except Exception as error:
    log("STOP", type(error).__name__, error)
finally:
    log("cleanup")
    run(K + ["delete", "namespace", NS, "--wait=true", "--timeout=180s"], timeout=200)
    gone = run(K + ["get", "namespace", NS]).returncode != 0
    log("namespace absent" if gone else "NAMESPACE_STILL_PRESENT")
