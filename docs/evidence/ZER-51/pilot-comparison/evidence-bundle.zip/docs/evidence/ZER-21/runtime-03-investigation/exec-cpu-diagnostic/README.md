# ZER-21 runtime-03 — Source B exec: CPU debt diagnostic (Claude, 30/10/2026)

Complements `../README.md`. All times are UTC. Hoàng asked to find the remaining cause; this adds a reanalysis of the existing Prometheus history plus one bounded diagnostic exec run. No model, fixture, HTTP, SQLi, Kafka or runtime replay. Existing runtime-03 evidence and ledgers were not changed.

## Conclusion

**Confirmed mechanism:** the Source B container was charged with a CPU *debt* of about 1 s. Under the `50m` limit (5 ms per 100 ms period) the kernel then gave it 0 CPU for about 200 consecutive periods (~20 s) to repay it, so the exec could not finish before the 15 s client timeout. A normal exec costs ~80 ms CPU and finishes in ~2 s at `50m`; the failure needs an anomalous ~1.2 s charge, about 13x normal.

**Still UNKNOWN:** what produced the extra ~1.2 s of charged CPU (runc init, Python, or kernel work in the task's context). It did not reproduce in 15 identical execs at `50m`.

## Evidence

1. **Debt signature in runtime-03** (`../source-resource-history.json`; container `9b1728d88265…`):

   | Interval end | CFS periods | Throttled | CPU used |
   | --- | --- | --- | --- |
   | 03:58:35.9 | 71 | 69 | 1.272 s (the quota allows at most 71 × 5 ms = 0.355 s) |
   | 03:58:52.0 | 161 | 161 | **0** |
   | 03:59:03.0 | 44 | 42 | 0.0035 s |

   A cgroup that is throttled every period while using no CPU is repaying negative runtime: about (161 + 42) × 5 ms ≈ 1.0 s, which matches the overrun of about 0.92 s. The extra process disappeared at 03:59:03, when the debt was cleared. After that it needed only 3.5 ms more, so the large charge came at exec setup/startup, not from the script's socket work.

2. **Normal cost of the same exec** (`samples.jsonl`, `diag.sh`, `run.log`):
   - Pod identical to Source B (image `zer46-fixture:24662046a33f`, securityContext, requests, node `agent-0`), at limits `50m` and `500m`.
   - 15 sequential execs of `python3 -c` (import socket,json; print). No connection to anything.
   - `cpu.stat` was read from the node's cgroup v2 before and after each exec, so the reads are not charged to the container.

   | Limit | Result | CPU per exec | Wall time | Throttled per exec |
   | --- | --- | --- | --- | --- |
   | `50m` | 15/15 rc 0 | 76–98 ms | 1.63–2.10 s | 6–19 periods (0.3–1.3 s) |
   | `500m` | 15/15 rc 0 | 66–77 ms | 0.30–0.39 s | 0–1 period |

   Neither limit showed an overrun. Runtime-03 Source A (0.077 s CPU, 1.5 s) and runtime-02 (0.076 s, 1.52 s) fit this normal profile.

3. **Host or VM contention ruled out during the exec** (`prometheus/r_*.json`, 30 s step over 01:20–04:30):
   - At 03:58:30 the VM had 3.35 of 4 CPUs idle, run-queue wait 1.03 s/s, steal 0.
   - The VM-wide wait spike (6.14 s/s) came at 03:59:00–03:59:30, after the timeout, during cleanup.
   - Bigger saturation episodes (03:15:30 wait 96 s/s, idle 0.45) throttled many pods but not Source B.
   - The VM kernel ring buffer (`/dev/kmsg`, read with a 3 s cap) has no lockup, stall or clocksource messages around 03:58; only veth up/down. Kernel `6.18.33.2-microsoft-standard-WSL2`, cgroup2, `sched_cfs_bandwidth_slice_us=5000`, runc 1.2.4, containerd 1.7.23-k3s2.

4. **Memory:** failcnt 0 and peak working set 11.7 MiB of 48 MiB, as already recorded.

## Stress repro, 04:51–05:02 (`stress-repro/`)

Hoàng asked to run the repro. It used the same Source B spec at `50m`, 270 benign execs (print only), namespace `zd-diag-cpu2`, a 25 min wall cap, and a memory guard before each group. The namespace was deleted and its absence verified at 05:02:48.

| Group | Condition | n | CPU per exec (median / max) | Wall (median / max) | Max over quota |
| --- | --- | --- | --- | --- | --- |
| A | warm pod, idle | 150 | 80 / 100 ms | 1.64 / 2.14 s | 5 ms |
| B | fresh pod, first exec 5 s after Ready | 20 | 79 / 88 ms | 1.60 / 1.88 s | 9 ms |
| C | warm pod while a pod is created/deleted every ~8 s | 100 | 80 / 97 ms | 1.62 / 1.92 s | 6 ms |

All 270 returned rc 0, with **0 anomalies** (CPU > 300 ms or wall > 5 s). This held while the VM's CPU PSI `some avg10` ranged from 5.5 to 56.8. Memory was comparable to the incident (WSL available ~2.4 GiB here vs ~2.1 GiB at 03:58, memory PSI ≈ 0).

Across 285 execs at `50m` (these plus the 15 earlier), the anomalous charge did not recur. By the rule of three, its rate under these conditions is below ~1.05% (95%).

The runtime-03 trigger is therefore a rare transient that is **not** reproduced by idle, fresh-pod, pod-churn or high-CPU-PSI conditions. Its origin stays UNKNOWN. The decision is to mitigate it, not to keep searching: if it recurs, the `cpu.stat` snapshot on timeout records it.

## Applied offline (30/10, no runtime yet)

All in `runtime-prep-03/`, repinned in `source-manifest.json`; `authorization.json` is unchanged and still consumed. A new runtime needs separate approval.

1. **CPU limit** (`render.py`): the `source` container on Source A/B goes to `500m` (request unchanged). Evidence: `../../offline/source-cpu-fix*`.
2. **Timeout snapshot** (`lab.py`): on a `COMMAND_TIMEOUT` exec into a source pod, the runner saves `<pod>-<container>-timeout-cpu.json` (`cpu.max` plus two `cpu.stat` reads 2 s apart), then re-raises the timeout unchanged.
3. **Warm-up gate** (`lab.py`):
   - Before the two TCP-denial probes, and so before any HTTP or model call, the runner does one `print('warm')` exec per source container and reads `cpu.stat` before and after.
   - The run stops as `ValueError:SOURCE_CPU_DEBT` if CPU exceeds 300 ms (3× the largest of the 285 measured execs), wall time exceeds 5 s, or the output is wrong.
   - The result is saved in `source-cpu-gate.json`. An unreadable cgroup or an exec timeout is also a stop, never a PASS. Cleanup still runs via the separate `--cleanup` process.
   - Evidence: `../../offline/source-cpu-gate*`. Before: 4 failures and 2 errors on `0cda5244`. After: 3/3 pass. The full runner (28) and cycle (15) suites pass.
   - Limit: the gate only checks the container at run start. An anomaly in a later exec is absorbed by the 500m limit (≈2.5 s repayment) and recorded by item 2.

## Implication for the fix (as analysed before it was applied)

- At `50m`, any one-off extra charge above ~0.7 s pushes the exec past 15 s.
- At `500m`, the same 1.27 s charge would be repaid in ~2.5 s. The measured normal exec there takes 0.3 s.
- Minimal evidence-based change: raise only the ZER-21 Source A/B `source` container CPU limit in the ZER-21 renderer (e.g. `500m`, request unchanged). Keep the 15 s timeout and isolation semantics (no output stays UNKNOWN, never PASS).
- Also make the runner snapshot that container's `cpu.stat` on `COMMAND_TIMEOUT` before cleanup, so a recurrence records the debt and its user/system split.
- This removes the 50m sensitivity. It does not explain the origin of the anomalous charge.

## Bounds and cleanup of the diagnostic

- Memory guard before start: MemAvailable 2,280,404 KiB.
- Namespace `zd-diag-cpu`, 2 pods with `activeDeadlineSeconds` 600, 30 execs, 40 s cap per exec.
- Run 04:35:20–04:37:36; the namespace was deleted and its absence verified (`run.log`).

`attempt1-invalid/` is a first run at 04:32–04:34 in which Git Bash rewrote the absolute Linux paths. All 30 execs failed immediately at exec start and no `cpu.stat` was read. It is kept only for transparency, has no measurement value, and was cleaned up the same way.

A separate stray: a `docker run --privileged` helper container started to read `/dev/kmsg` blocked on the stream. It was stopped and removed (`4c4abdd5d36f`) within about a minute and did nothing else.
