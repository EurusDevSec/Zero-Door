"""One cycle through actual agent classes, fake model/executor/API/probes only."""
import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT / "agent-orchestrator"))
from event_pipeline.contract import Producer, new_id
from cycle import FunctionalCycle
from event_pipeline.llm import Adapter, Limits, MODEL, RunBudget
from gaia.diagnosis import Diagnoser
from hephaestus.recovery import Healer, Journal
from nemesis.command_guard import CommandGuard
from nemesis.session import Session, SessionLimits, PURPOSE
from test_hephaestus_recovery import API
from test_sqli_action_state import PINS, POD, probes

CLOCK = {"clock_id": "offline", "clock_source": "UNKNOWN", "resolution_ms": None}


class Model:
    def __init__(self, positive, *, failure=None, over_heal=False, stop=None):
        self.positive, self.failure, self.over_heal, self.stop = positive, failure, over_heal, stop
        self.requests = []

    async def send(self, payload, timeout):
        self.requests.append(deepcopy(payload))
        observation = json.loads(payload["input"])
        if "access" in observation:
            action = "BLOCK_IP" if self.positive or self.over_heal else "NO_ACTION"
            value = {"action": action, "reason": "SQLI_DISCLOSURE" if action == "BLOCK_IP" else "BENIGN",
                     "evidence_ids": [observation["detection"]["event_id"]]}
        elif "detection" in observation:
            value = {"classification": "SUSPICIOUS_ACTIVITY" if self.positive else "NORMAL",
                "summary": "Offline observed access", "confidence": .8,
                "evidence_ids": [observation["detection"]["event_id"]]}
            if self.failure == "429":
                return {"status": 429, "body": {"error": {"code": "rate_limit_exceeded"}}}
            if self.failure == "TIMEOUT":
                raise asyncio.TimeoutError
            if self.failure == "REFERENCE":
                value["evidence_ids"] = [new_id("evt")]
            if self.failure == "UNKNOWN":
                value["classification"] = "UNKNOWN"
        elif self.stop:
            value = {"template": "STOP", "evidence_ids": ["ev-health-01"], "stop_reason": self.stop}
        else:
            value = {"template": "disclose-restricted" if self.positive else "benign-apparel",
                     "evidence_ids": ["ev-health-01"], "stop_reason": "NONE"}
        body = {"id": "resp_offline", "model": MODEL, "status": "completed", "output": [{
            "type": "message", "role": "assistant", "status": "completed",
            "content": [{"type": "output_text", "text": json.dumps(value)}]}],
            "usage": {"input_tokens": 100, "output_tokens": 40, "total_tokens": 140}}
        if "detection" in observation and "access" not in observation and self.failure == "USAGE":
            body.pop("usage")
        return {"status": 200, "body": body, "request_id": "req_offline"}


class Cycles(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        # Patch after the Windows event loop has initialized its local socket pair.
        self.net = patch.object(socket.socket, "connect", side_effect=AssertionError("OFFLINE_ONLY"))
        self.net.start(); self.addCleanup(self.net.stop)
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)

    def build(self, *, positive=True, failure=None, over_heal=False, mutate=None, executor_failed=False, stop=None):
        self.pins = dict(PINS, run_id=new_id("run"), trial_id=new_id("trl"))
        self.ctx = {"run_id": self.pins["run_id"], "trial_id": self.pins["trial_id"],
            "incident_id": new_id("inc"), "group": "B2", "method_version": "zer21-offline/1",
            "config_ref": "sha256:" + "1" * 64}
        self.model = Model(positive, failure=failure, over_heal=over_heal, stop=stop)
        self.budget = RunBudget(self.ctx["run_id"], max_calls=3, max_reserved_tokens=30000,
                               max_estimated_usd=.01, duration_s=180)
        self.adapter = Adapter(self.model, self.budget, limits=Limits(attempts=1,
            timeout_s=1, deadline_s=2, retry_delay_s=0, max_output_tokens=256))
        policy = json.loads((ROOT / "tests/fixtures/zer12/command-guards.json").read_bytes())["policy"]
        policy["context"] = {k: self.ctx[k] for k in ("run_id", "trial_id", "group")}
        policy["sqli"] = {"enabled": True,
            "endpoint": "http://zer41-private-ingress.zd-sqli-lab.svc.cluster.local:8000/fixture/catalog/search",
            "maxSends": 1, "maxCommandSec": 1}
        self.sent, self.records, self.diagnoses = [], [], []
        self.observer_calls = self.probe_calls = 0
        self.wall = 1001
        self.detected = Producer("detector", "offline", CLOCK).event(self.ctx, "DETECTED", {
            "rule_id": "SUSPICIOUS_LOG", "rule_version": "1", "signature": "SQLI/fixture",
            "metric": "log_pattern_match", "value": int(positive), "threshold": 0,
            "severity": "WARNING", "description": "Offline observed access"}, "o.alert",
            target={"namespace": "zd-sqli-lab", "service": "sqli-fixture", "flow": None}, alert_id=new_id("alt"))
        self.access = {"ref": "offline/access", "request_id": "4" * 32, "ts": 1000,
            "client_ip": self.pins["attacker_ip"], "tcp_peer": "10.42.0.12",
            "source_method": "XFF_AFTER_TRUSTED", "source_confidence": "PROXY_CHAIN",
            "method": "GET", "path": "/fixture/catalog/search", "status": 200, "rows": 3,
            "restricted_rows": int(positive), "delivered": True, "run_id": self.ctx["run_id"],
            "trial_id": self.ctx["trial_id"], "fixture_uid": POD, "detection_event_id": self.detected["event_id"]}
        self.evidence = {"metric": {"name": "log_pattern_match", "value": int(positive), "threshold": 0},
                         "log": {"message": "Offline observed access", "observed_at": None}}

        async def observe():
            return {"observed_at": datetime.now(timezone.utc).isoformat(),
                    "evidence": [{"id": "ev-health-01", "health": "HEALTHY"}]}

        async def execute(command):
            self.sent.append(deepcopy(command))
            return {"commandId": command["commandId"], "source": "chaos-worker", "attackType": "SQLI",
                "duration": 100, "status": "FAILED" if executor_failed else "SUCCESS",
                "details": {"sqli": {"templateId": command["parameters"]["customParams"]["template"],
                    "sends": [{"seq": 1, "requestId": command["commandId"] + "/1", "responseId": "4" * 32,
                        "status": 200, "rows": 3, "restrictedRows": int(positive)}]}}}

        async def observed(receipt):
            self.observer_calls += 1
            value = deepcopy({"detection": self.detected, "evidence": self.evidence, "access": self.access})
            if mutate:
                mutate(value)
            return value

        async def probe(api):
            self.probe_calls += 1
            rows = probes(); rows[0]["access"]["action_ids"] = [api["rule"]["action_id"]]
            self.wall = 1010
            return {"attacker": rows[0], "benign": rows[1:], "fixture": {"uid": POD, "ready": True}}

        self.nemesis = Session(purpose=PURPOSE, guard=CommandGuard(policy), adapter=self.adapter,
            observe=observe, execute=execute, context=self.ctx,
            limits=SessionLimits(max_rounds=1, command_s=1, required_rounds=1,
                allowed_templates=("disclose-restricted",) if positive else ("benign-apparel",)))
        self.gaia = Diagnoser(self.adapter, self.ctx, self.diagnoses.append)
        self.journal = Journal(self.tmp.name, self.ctx); self.addCleanup(self.journal.close)
        self.api = API(self.pins)
        self.healer = Healer(self.adapter, self.ctx, api=self.api, pins=self.pins, fixture_uid=POD,
            journal=self.journal, probe=probe, wall_clock=lambda: self.wall)
        return FunctionalCycle(self.nemesis, self.gaia, self.healer,
                               observe_result=observed, sink=self.records.append)

    async def test_actual_three_agents_share_budget_context_and_joined_native_port(self):
        receipt = await self.build().run()
        self.assertEqual("COMPLETED_PENDING_NATIVE_REVIEW", receipt["status"])
        self.assertEqual((3, 1, 1, 1), (len(self.model.requests), len(self.sent), self.api.writes, self.probe_calls))
        self.assertEqual(3, receipt["budget"]["attempts_dispatched"])
        self.assertEqual(300, receipt["budget"]["known_input_tokens"])
        self.assertEqual({"nemesis", "gaia", "healer"}, set(receipt["stages"]))
        self.assertEqual(self.detected["event_id"], receipt["stages"]["gaia"]["detection_event_id"])
        self.assertEqual(self.detected["event_id"], receipt["stages"]["healer"]["detection_event_id"])
        self.assertEqual("SUCCESS", receipt["stages"]["healer"]["action_state"]["terminal"]["status"])
        self.assertFalse(receipt["runtime_ac_verified"])
        self.assertFalse(receipt["recovery_verified"])
        self.assertFalse(receipt["benchmark_eligible"])
        self.assertEqual(["CYCLE_STARTED", "NEMESIS_RESULT", "OBSERVER_JOIN", "GAIA_RESULT", "HEALER_RESULT", "CYCLE_RECEIPT"],
                         [r["kind"] for r in self.records])
        self.assertTrue(all(r["tools"] == [] for r in self.model.requests))

    async def test_benign_cycle_does_not_dispatch_healer(self):
        receipt = await self.build(positive=False).run()
        self.assertEqual("COMPLETED_PENDING_NATIVE_REVIEW", receipt["status"])
        self.assertEqual("NO_ACTION", receipt["stages"]["healer"]["status"])
        self.assertEqual((0, 0, 0), (self.api.reads, self.api.writes, self.probe_calls))

    async def test_wrong_native_join_stops_before_gaia_and_healer(self):
        for key, value in (("request_id", "f" * 32), ("restricted_rows", 0),
                           ("fixture_uid", "99999999-9999-4999-8999-999999999999"),
                           ("run_id", new_id("run")), ("ts", 800), ("delivered", False)):
            with self.subTest(key=key):
                receipt = await self.build(mutate=lambda v: v["access"].update({key: value})).run()
                self.assertEqual("NOT_MET", receipt["status"])
                self.assertEqual(1, len(self.model.requests))
                self.assertEqual(0, self.api.writes)

    async def test_h_plane_in_observation_is_rejected_before_gaia(self):
        receipt = await self.build(mutate=lambda v: v["evidence"].update(expected_action="BLOCK_IP")).run()
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertEqual(1, len(self.model.requests))

    async def test_gaia_failure_stops_pipeline_preserving_attempts_and_prior_result(self):
        for failure in ("429", "TIMEOUT", "REFERENCE", "UNKNOWN", "USAGE"):
            with self.subTest(failure=failure):
                receipt = await self.build(failure=failure).run()
                self.assertEqual("NOT_MET", receipt["status"])
                self.assertEqual((2, 0, 0), (len(self.model.requests), self.api.writes, self.probe_calls))
                self.assertEqual({"nemesis", "gaia"}, set(receipt["stages"]))
                if failure == "USAGE":
                    self.assertFalse(receipt["budget"]["cost_estimate_complete"])
                else:
                    self.assertNotEqual("OK", receipt["stages"]["gaia"]["status"])

    async def test_erroneous_healer_model_cannot_bypass_benign_guard(self):
        receipt = await self.build(positive=False, over_heal=True).run()
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertEqual("GUARD_REJECTED", receipt["stages"]["healer"]["status"])
        self.assertEqual((0, 0), (self.api.writes, self.probe_calls))

    async def test_failed_executor_preserved_without_observation_or_later_calls(self):
        receipt = await self.build(executor_failed=True).run()
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertEqual((1, 0, 0), (len(self.model.requests), self.observer_calls, self.api.writes))
        self.assertEqual("EXECUTOR_FAILED", receipt["stages"]["nemesis"]["stop_reason"])

    async def test_model_stop_is_not_met_without_later_stages_or_replay(self):
        for reason in ("ROUNDS_COMPLETE", "NO_SUITABLE_TEMPLATE", "UNSPECIFIED"):
            with self.subTest(reason=reason):
                cycle = self.build(stop=reason)
                receipt = await cycle.run()
                self.assertEqual(("NOT_MET", "NEMESIS_NOT_COMPLETED"), (receipt["status"], receipt["reason"]))
                nemesis = receipt["stages"]["nemesis"]
                self.assertEqual(("MODEL_STOP", 0), (nemesis["stop_reason"], nemesis["completed_rounds"]))
                self.assertEqual(reason, next(r["plan"]["stop_reason"] for r in nemesis["records"] if r["event"] == "PLAN"))
                self.assertEqual({"nemesis"}, set(receipt["stages"]))
                self.assertEqual((1, 0, 0, 0, 0, 0), (len(self.model.requests), len(self.sent), self.observer_calls,
                                                      self.api.reads, self.api.writes, self.probe_calls))
                self.assertEqual({"purpose": PURPOSE, "required_rounds": 1, "completed_rounds": 0},
                                 json.loads(self.model.requests[0]["input"])["task"])
                with self.assertRaisesRegex(ValueError, "CYCLE_ALREADY_STARTED"):
                    await cycle.run()
                self.assertEqual(1, len(self.model.requests))

    async def test_no_same_cycle_replay_even_after_failure(self):
        cycle = self.build(executor_failed=True)
        await cycle.run()
        with self.assertRaisesRegex(ValueError, "CYCLE_ALREADY_STARTED"):
            await cycle.run()
        self.assertEqual(1, len(self.model.requests))

    async def test_mismatched_context_or_budget_refused_before_first_call(self):
        self.build()
        self.gaia.context["incident_id"] = new_id("inc")
        with self.assertRaisesRegex(ValueError, "CYCLE_CONTEXT"):
            FunctionalCycle(self.nemesis, self.gaia, self.healer, observe_result=lambda _: None, sink=lambda _: None)
        self.assertEqual([], self.model.requests)

    async def test_cancel_observer_does_not_run_later_agents_or_replay_executor(self):
        cycle = self.build()
        entered = asyncio.Event()
        async def waiting(receipt):
            entered.set()
            await asyncio.Future()
        cycle.observe_result = waiting
        task = asyncio.create_task(cycle.run())
        await asyncio.wait_for(entered.wait(), 5)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertEqual((1, 1, 0), (len(self.model.requests), len(self.sent), self.api.writes))
        self.assertEqual("NOT_MET", self.records[-1]["receipt"]["status"])
        self.assertIn("RECONCILIATION", self.records[-1]["receipt"]["reason"])

    async def test_sink_failure_stops_before_provider(self):
        cycle = self.build()
        def broken(item):
            raise OSError("offline durable writer failed")
        cycle.sink = broken
        with self.assertRaises(OSError):
            await cycle.run()
        self.assertEqual([], self.model.requests)

    async def test_cancel_during_nemesis_executor_propagates_with_reconciliation(self):
        cycle = self.build()
        entered = asyncio.Event()
        async def pending(command):
            self.sent.append(deepcopy(command))
            entered.set()
            await asyncio.Future()
        self.nemesis.execute = pending
        task = asyncio.create_task(cycle.run())
        await asyncio.wait_for(entered.wait(), 5)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        receipt = self.records[-1]["receipt"]
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertEqual("CANCELLED", receipt["stages"]["nemesis"]["stop_reason"])
        self.assertIn("RECONCILIATION", receipt["reason"])
        self.assertEqual((1, 1, 0), (len(self.sent), len(self.model.requests), self.api.writes))
        self.assertFalse(receipt["healer_progress"]["started"])

    async def test_journal_failure_after_api_preserves_action_unknown_progress(self):
        cycle = self.build()
        original = Journal.__call__
        def failing(journal, item):
            if item["kind"] in {"API_ACCEPTED", "HEAL_RECEIPT"}:
                raise OSError("offline post-dispatch writer failure")
            return original(journal, item)
        with patch.object(Journal, "__call__", failing):
            receipt = await cycle.run()
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertNotIn("healer", receipt["stages"])
        progress = receipt["healer_progress"]
        self.assertTrue(progress["started"] and progress["dispatched"] and progress["action_may_remain"])
        self.assertFalse(progress["receipt_available"])
        self.assertEqual("API_ACCEPTED", progress["api_result"]["status"])
        self.assertIn("DISPATCH_INTENT", Path(progress["journal_ref"]).read_text())
        self.assertIn("HEALER_ACTION_RECONCILIATION_REQUIRED", receipt["reason"])
        self.assertEqual((3, 1), (len(self.model.requests), self.api.writes))

    async def test_cancel_after_api_keeps_action_reconciliation_progress(self):
        cycle = self.build()
        entered = asyncio.Event()
        async def pending(api):
            entered.set()
            await asyncio.Future()
        self.healer.probe = pending
        task = asyncio.create_task(cycle.run())
        await asyncio.wait_for(entered.wait(), 5)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        receipt = self.records[-1]["receipt"]
        self.assertEqual("NOT_MET", receipt["status"])
        self.assertTrue(receipt["healer_progress"]["action_may_remain"])
        self.assertEqual("API_ACCEPTED", receipt["healer_progress"]["api_result"]["status"])
        self.assertFalse(receipt["healer_progress"]["receipt_available"])
        self.assertEqual((3, 1), (len(self.model.requests), self.api.writes))


if __name__ == "__main__":
    unittest.main()
