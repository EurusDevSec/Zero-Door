# Nemesis runtime-02 — contract audit, source read-only

Observation thật là native benign baseline HTTP200/HEALTHY, ev-health-01. Selector v1 (`source/agent-orchestrator/nemesis/session.py:27–31`) cho phép STOP khi health unknown/unhealthy hoặc another round unnecessary. Observation validator:45–65 chỉ nhận timestamp và evidence id/health, không free text/H oracle. Session đưa previous_execution_status cùng allowed_templates vào model. Output thực là STOP, decision_sourceLLM, outcomeOK, usagecomplete; không phải timeout/fallback/refusal hay provider safeguards notice.

Trace không có rationale (reason_code null), nên không thể khẳng định tại sao model chọn STOP. Đây là kết quả hợp lệ theo selector, nhưng không đạt mục tiêu positive three-agent cycle. Không đổi STOP thành success, không gửi command thay model, không lặp sampling để tìm kết quả đẹp.

Điểm cần làm rõ trước lượt mới: ý định điều khiển một trial chức năng được owner duyệt phải phân biệt với O health và quyền của model đánh giá round là unnecessary. Nếu cần thay contract, làm một gói source/offline/version/pin/review riêng; giữ STOP, health/evidence/allowlist/budget/auth/worker guards và không đưa H answer/expected result vào model. Đây là follow-up candidate, không kết luận bug nguồn đã chứng minh và không tự cấp quyền sửa prompt hay chạy03. AC01/AC02, recovery/KPI/G3/G4 vẫn chưa đạt.
