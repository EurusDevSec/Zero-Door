#!/usr/bin/env bash
# ZER-21 diagnostic: CPU charged to a Source-B-identical container per `kubectl exec`.
# Bounds: one namespace zd-diag-cpu, two pods (50m / 500m limit, else Source B spec),
# 15 sequential benign execs each (print only, no socket connect), 40s cap per exec,
# pod activeDeadlineSeconds 600, memory guard before start, namespace deleted at end.
# No model, no fixture/HTTP/SQLi, no change outside the namespace.
set -u
export MSYS_NO_PATHCONV=1  # Git Bash must not rewrite Linux absolute paths
OUT="$(dirname "$0")/diag"; mkdir -p "$OUT"
K="kubectl --context k3d-zero-door --request-timeout=12s"
D="docker --context desktop-linux exec k3d-zero-door-agent-0"
NS=zd-diag-cpu
log(){ echo "$(date -u +%FT%T.%3NZ) $*" | tee -a "$OUT/run.log"; }

mem=$($D cat /proc/meminfo | awk '/MemAvailable/{print $2}')
log "guard MemAvailableKiB=$mem"
[ "$mem" -gt 1048576 ] || { log "MEMORY_STOP"; exit 2; }

cleanup(){ log "cleanup"; $K delete namespace $NS --wait=true --timeout=120s >>"$OUT/run.log" 2>&1;
  $K get namespace $NS >>"$OUT/run.log" 2>&1 && log "NAMESPACE_STILL_PRESENT" || log "namespace absent"; }
trap cleanup EXIT

$K create namespace $NS >>"$OUT/run.log" 2>&1 || exit 3
for lim in 50m 500m; do
cat <<EOF | $K apply -f - >>"$OUT/run.log" 2>&1
apiVersion: v1
kind: Pod
metadata: {name: diag-$lim, namespace: $NS, labels: {zero-door.io/run: zer21-diag-cpu}}
spec:
  automountServiceAccountToken: false
  restartPolicy: Never
  activeDeadlineSeconds: 600
  securityContext: {runAsNonRoot: true, runAsUser: 65532, runAsGroup: 65532, seccompProfile: {type: RuntimeDefault}}
  nodeSelector: {kubernetes.io/hostname: k3d-zero-door-agent-0}
  containers:
  - name: source
    image: zer46-fixture:24662046a33f
    imagePullPolicy: Never
    command: [/usr/bin/python3, -c, "import time; time.sleep(900)"]
    securityContext: {allowPrivilegeEscalation: false, readOnlyRootFilesystem: true, capabilities: {drop: [ALL]}}
    resources: {requests: {cpu: 5m, memory: 16Mi}, limits: {cpu: $lim, memory: 48Mi}}
EOF
done
$K -n $NS wait --for=condition=Ready pod --all --timeout=90s >>"$OUT/run.log" 2>&1 || { log "NOT_READY"; exit 4; }

for lim in 50m 500m; do
  pod=diag-$lim
  cid=$($K -n $NS get pod $pod -o jsonpath='{.status.containerStatuses[0].containerID}' | sed 's#.*://##')
  cg=$($D sh -c "find /sys/fs/cgroup/kubepods* -maxdepth 4 -type d -name '*$cid*' | head -1")
  log "$pod cid=${cid:0:12} cgroup=$cg cpu.max=$($D cat $cg/cpu.max)"
  for i in $(seq 1 15); do
    b=$($D cat $cg/cpu.stat | tr '\n' ' ')
    t0=$(date +%s.%N)
    out=$(timeout 40 $K -n $NS exec $pod -- /usr/bin/python3 -c "import socket,json
print(json.dumps({'ok':1}))" 2>&1); rc=$?
    t1=$(date +%s.%N)
    sleep 1
    a=$($D cat $cg/cpu.stat | tr '\n' ' ')
    echo "{\"pod\":\"$pod\",\"i\":$i,\"rc\":$rc,\"wall\":$(awk "BEGIN{print $t1-$t0}"),\"out\":\"$(echo $out | tr -d '"')\",\"before\":\"$b\",\"after\":\"$a\"}" >> "$OUT/samples.jsonl"
    log "$pod #$i rc=$rc wall=$(awk "BEGIN{print $t1-$t0}")"
  done
done
