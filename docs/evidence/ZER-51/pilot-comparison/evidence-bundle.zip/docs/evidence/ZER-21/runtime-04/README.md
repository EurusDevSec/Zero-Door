# ZER-21 runtime-04 — NOT_MET, cleanup CLEAN

One owner-approved attempt consumed proposal eccba4a33396 /manifest9aa21e063e39.
Total 244.204s; no retry. Both owned process trees closed/reaped.

CPU mitigation passed this run: Source A/B warm-up0.219/0.203s, CPU26.676/28.935ms,
no throttled period; both containers cpu.max50000/100000. TCP isolation denied on
both sources in ~0.312s. Four cgroup reads, no timeout snapshot. This clears the
observed gate in this run; it does not explain runtime03's rare CPU spike.

Nemesis v2 made one real gpt-6-luna call, outcomeOK,370input+31output tokens,
estimatedUSD0.0000525; chose disclose-restricted/stop_reasonNONE and guard accepted.
The transport exited1 before reading/signing/sending the command:
`ModuleNotFoundError: No module named 'kafka'` in remote.py -> session_cli.py:17.
Exact stdout/stderr and timing: worker-transport-command.json.

Source cause: render.py sets transport PYTHONPATH only to /current, replacing the
image dependency path /usr/local/lib/python3.11/site-packages. The earlier ZER19
reference manifest retained that directory. Requirements include kafka-python;
this receipt proves failed import, not that the cached image has no package.
The missing dependency path was missed in the offline review. Restore it in a
new source package and make critical imports fail at container startup before
the first model call. Do not edit this consumed prep04 or replay its authorization.

Usage:1 confirmed benignHTTP; secondHTTP was reserved for the worker but not sent;
0SQLi sends,2confirmedTCP,0Gaia/Healer calls,0ConfigMap replace. Cycle correctly
stopped EXECUTOR_RESULT_UNKNOWN_OR_INVALID/NEMESIS_NOT_COMPLETED; AC01NOT_MET,
AC02NOT_RUN, no KPI/recovery/Done claim.

Cleanup independently checked in reconciliation.json: namespace owner/UID delete
and absence,2OWNED topics deleted with final empty lists and unchanged brokerUID,
shared specs/UID/restarts unchanged,resource_guardPASS.128live/snapshot source pins,
923old evidence files and unrelated dirty bytes match. No further lab calls,
build/pull/import, provider call, publication or Linear write during reconciliation.
