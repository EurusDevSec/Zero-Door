# ZER-21 runtime-05 — NOT_MET, cleanup CLEAN

One approved attempt consumed proposal b4fd1de3c372 /manifest5a82e96aef72.
Elapsed 238.797s. Both owned trees closed/reaped; no replay.

Dependency gate PASS: restoring PYTHONPATH allowed exact remote.py imports before
the model. Source CPUgate PASS and both TCP isolation probes denied. Nemesis v2
again chose disclose-restricted/NONE, guardaccepted;1gpt-6-luna call370+31tokens,
estimateUSD0.0000525. The Kafka executor then exited1 RESULT_TOPIC_UNAVAILABLE
while waiting for results-topic metadata, before producer construction/send.

Both topics were created successfully(raw0046/0049); worker group was Stable
with1member(raw0062). These facts do not establish metadata access by a new
Python client. The snapshot proves a configuration defect: zer21-kafka-egress
selects app=zer46-source-a, while both real source pods have app=zer46-source;
the policy selects zero source pods. Default egress restrictions are present.
The intended Source-A-only Kafka rule therefore grants neither source access.
No packet/drop trace was captured, so this is not proof of a unique cause.
Do not invent conntrack timing as an explanation for worker-group readiness.

Usage:1confirmed benignHTTP,2reserved;0SQLi sends/0Kafka publishes/0Gaia-Healer
calls/0ConfigMapreplace. WorkNOT_MET,AC01NOT_MET/AC02NOT_RUN. No recovery/KPI/Done.

Cleanup independently reconciled: namespace owner/UID deletion+absence,2OWNED
topics deleted/final empty lists, same brokerUID/shared specs+UID/restarts,
resourceguardPASS.128live/snapshot pins and1245old evidence files match;
unrelated dirty preserved. No extra lab/model traffic during reconciliation.

Next offline fix: unique owner-scoped label on SourceA only, use that in Kafka
policy selector; verify against the actual rendered pod labels that exactlyA
matches andB/foreign owner do not. Preserve existing DNS/private-proxy policies,
TCP9092 destination/guards and historical05. No runtime06 is authorized here.
