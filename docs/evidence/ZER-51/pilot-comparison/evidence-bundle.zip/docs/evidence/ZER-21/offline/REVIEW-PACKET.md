# ZER-21 — gói review offline sau runtime-03 (Claude, 30/10/2026)

Gửi Codex review. Branch `zer-21-linked-agent-cycle`, HEAD `a593885e15dc474b83590c4dcf1b214395492fcf`, index rỗng, chưa commit. Tất cả là thay đổi source và test offline. **Không chạy runtime, model, HTTP hay SQLi; không lấy key; không tạo hay tiêu authorization.** AC01 vẫn NOT_MET, AC02 NOT_RUN.

Đề nghị review ba gói thay đổi (A, B, C) và các điểm mở trước runtime (mục 3). Gói C sửa vấn đề đã làm runtime-03 dừng.

## 1. Các gói thay đổi

### A. Cleanup: resource check độc lập với lỗi snapshot (P2 của Codex)

- **Lỗi:** khi namespace đã xóa nhưng snapshot lỗi, runner bỏ qua `resources()` mà vẫn dọn topic.
- **Sửa** (`runtime-prep-02/lab.py`):
  - `cleanup_namespace` chạy resource check trong `try` riêng và ghi `resource_guard`;
  - `cleanup_owned` chỉ dọn topic khi `resource_guard == "PASS"`, ngược lại trả `PENDING_RESOURCE_GUARD`.
- **Test** (`runtime-prep-02/test_runner.py`):
  - `test_snapshot_failure_still_runs_resource_guard_and_blocks_topics_on_fail`;
  - `test_snapshot_failure_attempts_owned_topics_only_after_resource_pass`.
- **Kết quả:** before fail, after pass. Log: `cleanup-resource-gate-{before,after,full}.log`.
- `runtime-prep-03/lab.py` kế thừa bản này: bản prep-03 trước khi sửa CPU có cùng hash `c53d951e` với prep-02.

### B. Selector v2: nêu rõ nhiệm vụ cho Nemesis, STOP phải có lý do hợp lệ

- **Vấn đề runtime-02:** model chọn STOP hợp lệ theo v1, vì v1 cho model tự đánh giá round là "unnecessary" dựa trên health baseline. Owner đã duyệt một trial, nhưng ý định này không có trong input.
- **Sửa:**
  - `agent-orchestrator/nemesis/session.py`:
    - `PROMPT_VERSION zer19-registry-selector/2`, receipt `nemesis-functional/2`;
    - input có `task {purpose, required_rounds, completed_rounds}`;
    - `Plan.stop_reason` ∈ {NONE, ROUNDS_COMPLETE, NO_SUITABLE_TEMPLATE, UNSPECIFIED}, có validator chéo `PLAN_STOP_REASON`;
    - `SessionLimits.required_rounds` (0 ≤ x ≤ max_rounds).
  - `session_cli.py`: nhận thêm `required_rounds`, là trường tùy chọn.
  - prep-02/03 dùng `required_rounds=1`.
- **Không thay đổi:**
  - STOP vẫn là quyết định hợp lệ; harness không ép model chạy;
  - `test_model_stop_is_not_met_without_later_stages_or_replay` giữ đúng hành vi STOP → NOT_MET, không replay.
- **Log:** `selector-v2.diff`, `selector-v2-{before,after,full}.log`. Codex checkpoint `selector-v2-codex-*.json` ghi `READY_SOURCE_OFFLINE_SELECTOR_V2`, findings rỗng.
- **Giới hạn:** runtime-03 dừng trước model (0 model call), nên **selector v2 chưa từng được chạy với model thật**.

### C. Source CPU: giới hạn 500m, snapshot khi timeout, warm-up gate

**Nguyên nhân đã xác nhận:**
- Container Source B bị tính khoảng 1,27 s CPU, trong khi một exec bình thường khoảng 80 ms.
- Ở limit `50m`, kernel bắt container trả nợ khoảng 20 s (161/161 chu kỳ bị throttle, usage đứng yên), lâu hơn timeout 15 s.
- 285 exec chẩn đoán ở `50m` đều không tái hiện được, nên tỷ lệ dưới khoảng 1,05% (95%).
- Gốc của khoản CPU tăng thêm vẫn **UNKNOWN**.
- Bằng chứng: `../runtime-03-investigation/exec-cpu-diagnostic/README.md` (24 file, `SHA256SUMS`).

**Ba thay đổi (chỉ trong `runtime-prep-03/`):**

1. **`render.py`:** chỉ container `source` của `zer46-source-a/b` lên `limits.cpu=500m`. Request giữ nguyên, không đổi pod nào khác.
   - Ở 500m, khoản nợ 1,27 s trả xong trong khoảng 2,5 s; exec bình thường mất khoảng 0,3 s.
2. **`lab.py`: snapshot khi timeout.**
   - Khi exec vào source pod bị `COMMAND_TIMEOUT`, runner lưu `<pod>-<container>-timeout-cpu.json` (`cpu.max` cộng hai lần đọc `cpu.stat` cách nhau 2 s).
   - Sau đó runner raise lại đúng timeout cũ. Nếu snapshot lỗi thì lỗi được ghi lại, không thay cho timeout.
3. **`lab.py`: warm-up gate.** `isolation()` gọi `source_cpu_gate()` trước TCP probe, tức trước mọi HTTP và model call.
   - Mỗi source container chạy một `print('warm')` (không có socket) và đọc `cpu.stat` trước/sau.
   - Gate dừng với `ValueError:SOURCE_CPU_DEBT` nếu CPU > 300 ms, wall > 5 s hoặc output sai.
   - Ngưỡng 300 ms bằng 3× mức lớn nhất trong 285 exec đo được.
   - cgroup không đọc được hoặc exec timeout cũng là dừng, không bao giờ PASS.
   - Kết quả ghi vào `source-cpu-gate.json`. Cleanup vẫn chạy qua process `--cleanup` riêng của `run.py`.
   - Dùng `ValueError` vì `main()` của ZER-50 chỉ giữ message của `ValueError` trong receipt.
   - Đọc cgroup bằng `docker --context desktop-linux exec <node> sh -c 'cat …'`, chỉ đọc. Runner hiện có đã dùng kiểu hành động này (`ZER-46/runtime-prep/run_component.py:293`, `preflight.py:96`).

**Kiểm tra:**

| Gói | Before | After |
| --- | --- | --- |
| Limit + snapshot (`source-cpu-fix*`) | 4 test mới: 1 failure + 3 errors trên render `e8c046ce` / lab `c53d951e` | pass; runner và cycle OK |
| Gate (`source-cpu-gate*`) | 4 failures + 2 errors trên lab `0cda5244` | 3/3 pass |

Lý do fail ở bản before đều đúng dự kiến: thiếu `source-cpu-gate.json`, không có `SOURCE_CPU_DEBT`, thiếu hằng số, đi thẳng vào isolation.

## 2. Trạng thái hiện tại (chạy lại toàn bộ khi viết gói)

`review-packet-tests.log`:

| Suite | Kết quả |
| --- | --- |
| `tests/test_nemesis_session.py` | 19 OK |
| `tests/test_nemesis_session_io.py` | 12 OK |
| `runtime-prep-02/test_runner.py` | 21 OK |
| `runtime-prep-02/test_cycle.py` | 15 OK |
| `runtime-prep-03/test_runner.py` | 28 OK |
| `runtime-prep-03/test_cycle.py` | 15 OK |

Tổng 110 test, không có lỗi.

**Bảo toàn:**
- `source-manifest.json` của prep-03 không có drift.
- Ledger lịch sử khớp toàn bộ: `runtime-02/artifact-sha256.json` 312/312, `runtime-03/artifact-sha256.json` 272/272, `runtime-03-investigation/artifact-sha256.json` 20/20.
- `runtime-prep-03/authorization.json` giữ nguyên (`5f32e958…`, đã tiêu).
- Không sửa artifact ZER-41/42/46/50.

## 3. Điểm mở trước bất kỳ runtime nào

**Chặn runtime (cần Codex/Hoàng quyết định, Claude chưa làm):**

1. **Prep-03 vẫn gắn với runtime-03 đã tiêu.** `run.py:15` có `OUT = …/runtime-03`, `run.py:58` yêu cầu `attempt == "runtime-03"`, và thư mục `runtime-03/` đã tồn tại. Lượt tiếp theo cần attempt mới (ví dụ prep-04/runtime-04), có ID, topic và thư mục riêng.
2. **`proposal.md` chưa mô tả thay đổi C.** Nó vẫn ghi giới hạn "2TCP isolation" và không nhắc limit 500m của source container, 2 exec warm-up, các lần đọc cgroup trên node hay snapshot khi timeout. Proposal mới phải ghi đúng các giới hạn này để Hoàng duyệt, kèm authorization mới cho đúng proposal và manifest SHA.

**Không chặn nhưng còn mở:**

3. Preflight chỉ kiểm memory (`ZER-46/runtime-prep/preflight.py:87–108`). Gate chỉ kiểm CPU của hai source container lúc bắt đầu. Nếu khoản CPU bất thường xảy ra ở exec sau, limit 500m hấp thụ nó và snapshot ghi lại.
4. `kubectl` client v1.33.5 lệch 2 minor so với server v1.31.5 và chưa được pin. Chưa có bằng chứng điều này gây timeout.
5. Entrypoint k3d lặp lỗi `uncordon` tới localhost:8080. Đây là lỗi nền, chưa nối được với sự cố.
6. Gốc của khoản CPU khoảng 1,27 s vẫn UNKNOWN.

## 4. Câu hỏi cho reviewer

- Ngưỡng gate 300 ms / 5 s có phù hợp không? Có nên thêm điều kiện theo `nr_throttled` không?
- Đặt gate trong `isolation()` (trước TCP probe) có đúng điểm không, hay nên đặt ở bước sớm hơn sau khi pod Ready?
- Chỉ nâng `limits.cpu` của container `source` (request 5m giữ nguyên) có đủ không?

## 5. Hash

| File | SHA-256 |
| --- | --- |
| `agent-orchestrator/nemesis/session.py` | `dfad697f9a5c1bd39222a761784c63a0b54f8de75f19f19b04a5e87c0d2c20fb` |
| `agent-orchestrator/nemesis/session_cli.py` | `53496a0965646c879ff86d565afa64e3f8582932ebe51d0a79283049098d38b3` |
| `tests/test_nemesis_session.py` | `b6136498a143a7962a1fcd2cc69d47b23d9cfed78df7bd9067a2bf35c87ddd0f` |
| `tests/test_nemesis_session_io.py` | `33fe5cd57d345608b1c296a90d85c3de9dcc28948d12f7fb8d966c1d9b2f0ddf` |
| `runtime-prep-02/lab.py` | `c53d951ee5ca8939d77b95784f48fb9f726dd662506f2333838d41ff4d3a9348` |
| `runtime-prep-02/test_runner.py` | `1da915e4c99fa4b743387d2a61ef9fcd08f6c5c1e7a91b93260e8ae01b86ab02` |
| `runtime-prep-02/test_cycle.py` | `64dc5ef6fe15d39808fa14ffc6486c5cf864ab26d6cfb42c9cd6cb8562963624` |
| `runtime-prep-03/render.py` | `25a1eb5a9bdc9e3df38689dc7495eae7197c058cf5cbcf87649446a2132ee884` |
| `runtime-prep-03/lab.py` | `76afd82a6fc1d7b3237da9a3bec644ec43ca55f5942deb6495961527df0d9f88` |
| `runtime-prep-03/test_runner.py` | `f88bb644d5a9cf53cc2e4582bcdb5366c8201c75af9d7dad579f2fa031294de5` |
| `runtime-prep-03/test_cycle.py` | `64dc5ef6fe15d39808fa14ffc6486c5cf864ab26d6cfb42c9cd6cb8562963624` |
| `runtime-prep-03/source-manifest.json` | `d9a811fb5889cebdb1bca5780e433883ad5f21b1a94e371182f280421802f464` |
| `runtime-prep-03/proposal.md` (chưa đổi) | `5f1dc0dd7b557176c7d4cf8daed6821326a2d231fa03cd4bf8108e235c88a716` |
| `runtime-prep-03/authorization.json` (chưa đổi) | `5f32e9580934e46004b1fefe17a31acfe7d80605b75471082d0f4fd4b00d367e` |
| `exec-cpu-diagnostic/README.md` | `5e08f3e10d3491b48a87bc6e8aaf6c1c10d22150fd2265760a29064ff280b4d0` |
| `exec-cpu-diagnostic/SHA256SUMS` | `771e0533ffd4cdfaef239426bbb47cfe1ebf207260e8faa1eac54d7733b7179a` |

Log offline (16 hex đầu):

| Log | SHA-256 |
| --- | --- |
| `cleanup-resource-gate-before.log` / `-after.log` / `-full.log` | `92d63c174299a0b6` / `91202f49064ef179` / `de08da61cb2d82d4` |
| `selector-v2.diff` | `0068d65a5c8a90e1` |
| `selector-v2-before.log` / `-after.log` / `-full.log` | `39d66f05bc3038e0` / `6f78631a28efd992` / `adb1d206494b7ef3` |
| `source-cpu-fix.diff` | `b2d6cf5cbcce51a8` |
| `source-cpu-fix-before.log` / `-after.log` | `fe5618c9898a6957` / `5157918207336892` |
| `source-cpu-fix-runner.log` / `-cycle.log` | `7f3971a7685fee7d` / `131fe936dcb3a778` |
| `source-cpu-gate.diff` | `f64022d60cf32f6b` |
| `source-cpu-gate-before.log` / `-after.log` | `e46426a30afdb839` / `0bcfb5ac34c02625` |
| `source-cpu-gate-runner.log` / `-cycle.log` | `44ec56c46b58fdf7` / `5d6e89fb9a5eefc5` |
| `review-packet-tests.log` | `43852e400fb4c232` |

Đường dẫn trong bảng tương đối với `docs/evidence/ZER-21/` (riêng mã nguồn Nemesis và tests là từ gốc repo).
