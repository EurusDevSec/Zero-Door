# ZER-21 runtime-03 — NOT_MET, cleanup CLEAN

Owner approved one attempt on proposal `5f1dc0dd…` and manifest `9fec1be9…`.
The attempt consumed that permission. No replay or runtime-04 was authorized.

Preflight passed 25 resource samples. Setup created private fixture/workers and
two fresh topics. Source-A TCP isolation returned denied=true (`raw/0084.json`).
Source-B kubectl exec was cancelled after 15.069 seconds at its existing command
deadline (`raw/0085.json`): no stdout/stderr and no TCP result. Work correctly
stopped NOT_MET before the benign baseline, model or SQLi dispatch.

Observed: 0 model calls, 0 HTTP, 0 SQLi send, 0 Gaia/Healer calls or Healer replace;
2 TCP checks reserved/started, only 1 with a confirmed response. The second
check's remote outcome is UNKNOWN. No selector-v2 live behavior was tested.
Low sampled memory PSI and passing guard do not prove the cause of exec delay.
No evidence here identifies a new source defect or justifies increasing timeout,
weakening isolation, changing provider/model or replaying the run.

Cleanup: owned namespace UID precondition deletion + absence receipt, two OWNED
topic deletions + final empty lists, broker UID unchanged; shared spec/UID/restarts
preserved, resource_guard PASS. Work and cleanup process trees closed/reaped.
Total elapsed 253.344s. Raw cleanup CLEAN, no resume or extra lab query required.

Codex independently recomputed raw joins, shared comparisons, ownership, source
pins and hashes in `reconciliation.json`. 128 live/snapshot source pins and all
312 entries in runtime-02's historical ledger still match. Existing unrelated
dirty bytes preserved. No source/prompt/test edits during/after this runtime.

AC01 NOT_MET; AC02/child ZER-51 NOT_RUN. No recovery/KPI/G3/G4/benchmark or Done
claim, Git publication, Linear writes, or additional model/lab attempt.
Selector-v2 source/offline review remains accepted: 67 targeted tests passed;
the copied prep03 passed 21 native fake tests and default PLAN_ONLY admission.

Next technical blocker: establish why the source-B native exec produced no
completion receipt. Existing receipts do not isolate kubelet/container runtime,
API stream, or remote program scheduling. Do not create a new experiment just
to replace this failure. A future diagnostic/runtime needs its concrete scope
and authority; pilot B0/B1/B2+C0 and publication/owner acceptance remain open.
