# ZER-21 — runtime-04, một vòng functional với selector v2

NOT_APPROVED / NOT_RUN. Gói này phục vụ AC01, không phải pilot AC02/child ZER-51.
Checkout C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door; branch
zer-21-linked-agent-cycle; HEAD a593885e15dc474b83590c4dcf1b214395492fcf.
Source/dirty được khóa riêng; không gộp dirty của issue khác vào publication.

## Outcome và thay đổi so với lượt trước

Một trace thật Nemesis → signed Kafka/Go worker → trusted native access reader →
Gaia → Hephaestus → containment/probe. Một Adapter/backend/model gpt-6-luna,
chung budget và context. Reader tạo DETECTED bằng RULES; Gaia diagnosis và
Hephaestus action là hai quyết định LLM riêng. Không coi diagnosis là quyền dispatch.

runtime-01 dừng ở kube kwargs, runtime-02 có model STOP hợp lệ trước dispatch.
Ba quyền cũ đã dùng hết; raw/source/authorization gốc giữ nguyên. Selector v2
truyền task purpose/required_rounds=1/completed_rounds và ghi stop_reason enum;
prompt zer19-registry-selector/2, receipt nemesis-functional/2. STOP vẫn hợp lệ,
không tự retry/ép template hay nâng thành success. Lý do STOP cũ vẫn UNKNOWN;
lý do mới chỉ là tự báo của model. Cleanup giữ fact ba trạng thái và chỉ dọn
topic sau resource_guard PASS, kể cả namespace/shared snapshot lỗi.

## Blocker runtime-03 và biện pháp thử khắc phục

runtime-03 đã tiêu quyền, NOT_MET trước model/HTTP/SQLi: exec TCP-isolation SourceB
timeout15s. Cleanup CLEAN; giữ nguyên toàn bộ raw/source/authorization cũ. Đây là
attempt mới runtime-04, không replay/resume03. Evidence nối đúng UID/container cho
thấy CPU tăng1.272s và throttling kéo dài ở50m. Nguồn CPU spike vẫn UNKNOWN;
negative-runtime/CPU-debt là suy luận, không phải kernel trace đã xác nhận.
285 benign exec tại50m không tái hiện;15 benign exec500m hoàn tất0.30–0.39s.
500m là mitigation chờ kiểm chứng, không bảo đảm sửa được sự cố hiếm.

Trước TCP isolation, HTTP hoặc model: một warm-up exec print('warm') cho mỗi
source, tổng đúng2 exec không socket. Đọc cgroup trước/sau mỗi warm-up, tổng4
normal node reads: mỗi read gồm1 GET Pod lấyUID/containerID và1 docker exec
desktop-linux vào agent-0, chỉ cat cpu.max/cpu.stat của container đó. Không node
write, không privileged helper/container, không sửa CPU của node/shared workloads.
UID/CID phải đúng định dạng; cgroup không đọc được thì dừng. Gate cần output warm,
CPU delta≤300000usec và wall≤5s cho cả hai nguồn; lỗi/timeout/thừa ngưỡng dừng
trước TCP/HTTP/model, không chuyển missing thànhPASS. Mỗi warm-up vẫn có trần
command15s; ngưỡng5s được kiểm sau khi command trả về. Normal cgroup command≤6s.

Snapshot khi source exec COMMAND_TIMEOUT: tối đa1 native snapshot attempt trong
toàn work process, reserve trước read, lỗi cũng tiêu budget; không retry snapshot.
Snapshot gồm1 GET Pod và1 read-only docker exec trên node, đọc cpu.max và2 cpu.stat
cách nhau2s; node command≤8s, GET/command≤15s, mọi bước cùng global work deadline.
Snapshot không đổi timeout gốc, không tạo HTTP/TCP/model/SQLi; các timeout sau
không thêm native CPU reads. Gate và snapshot bổ sung tối đa5 node exec reads cùng
5 GET Pod ngoài các admission/guard GET có sẵn. Không lấy host kernel log hay
thêm stress-repro trong lượt này. Không tăng15s exec timeout hoặc bỏ isolation.

Client hiện tại1.33.5/server1.31.5 và k3d uncordon loop được ghi residual; chưa có
bằng chứng nối chúng với timeout, không cài/upgrade/sửa cluster trong gói này.

## Admission và key

Default/import PLAN_ONLY. --execute --authorization cần approved=true, đúng
ZER-21/runtime-04, proposal SHA và source-manifest SHA, expiry còn hạn ≤24h.
Template approved=false; không có authorization mới trong gói chuẩn bị.
Chỉ lấy OPENAI_API_KEY qua Doppler zero-door/dev, --only-secrets OPENAI_API_KEY
và --no-fallback, theo đúng đường đã xác minh trước đây; không ghi key
vào file, stdout, Pod, command arguments hoặc receipt. Cleanup không nhận key.

Một attempt, exclusive runtime-04 directory + work-claimed marker, IDs/topics mới.
Không replay/resume/retry work sau lỗi/timeout/refusal/STOP. Child chờ stdin GO
sau khi vào Windows Job kill-on-close; POSIX process group. Parent đóng/reap
work tree trước cleanup process mới. Mọi failure/UNKNOWN giữ nguyên.

## Target, tác động và thời lượng

Chỉ Docker desktop-linux, kube k3d-zero-door, static local API
https://127.0.0.1:7356; không dynamic exec auth/DOCKER_HOST/proxy API.
Giữ hai node, 9 Boutique deployment một replica healthy, zero-door deployment0,
3PVC Bound, resource/restart/spec guards ZER-50. Preflight25 mẫu/5s.
Cached images phải đúng host/node IDs; 0 build/pull/import/shared workload change.

Tạo riêng namespace zd-sqli-lab khi absent, fresh owner zer46-<12hex>, owner+UID
guard. Bốn private workloads tái sử dụng fixture/proxy deployment và2 sourcePod
trên agent-0. SourceA có Go/Python sidecars chung IP: Go250m/192Mi, Python150m/128Mi,
requests tổng75m/64Mi. Chỉ limits.cpu của container source trên SourceA/B đổi từ50m lên500m;
requests giữ5m/16Mi, memory limit48Mi. Các container fixture/proxy/sidecar khác giữ nguyên. SourceA token chỉ phục vụ
Go in-cluster constructor, không thêm RBAC grant. Hai Secret fault/operator mới,
không lưu nội dung. Private endpoint duy nhất:
http://zer41-private-ingress.zd-sqli-lab.svc.cluster.local:8000/fixture/catalog/search
Không public route/Internet egress; SourceA chỉ thêm KafkaTCP9092 trong zero-door,
giữ DNS/private proxy policy có sẵn.

Tạo đúng2 topic zer19-<freshRun12>.commands/results, partition1/replica1/retention1h;
pin brokerPodUID. UNKNOWN trước create, chỉ create return0 thành OWNED; không xóa
UNKNOWN/foreign. Fresh group owner.worker, không thay broker/shared consumer.

Nemesis tối đa1 round, allowed_templates chỉ disclose-restricted hoặc STOP.
Giữ registry/payload hiện có, duration1s/concurrency1/RPS1/maxSends1/maxCommandSec1.
Tổng tối đa8 HTTP reserved/dispatched (1benign baseline +1worker +6verification),
2TCP isolation, 1ConfigMap replace attempt với UID/RV guard. TTL180s, probe120s.
Không thêm HTTP diagnostic/retry. Tối đa3 model calls, attempts1/call,
timeout20s/deadline25s/output256; tổng30000 reserved tokens, estimatedUSD0.015
(estimate không là cam kết hóa đơn tuyệt đối). Missing usage/429/timeout/refusal/
STOP giữ NOT_MET, không thử thêm để đạt AC.

Work tối đa900s (internal880s) + cleanup300s (child285s/native265s).
Kafka operation10s, sau delete tối đa3 read polls/1s, cùng global cleanup deadline.
Không có quyền sửa shared workloads, PVC, HPA, Ingress, build/cache, cloud hay
cài dependency để vượt preflight. Guard fail thì dừng và cleanup đúng gói.

## Evidence, provenance và cleanup

Cached worker zer42-worker:e80bc554b7ef giữ build receipt ZER-42/runtime-01,
manifest-list host250be486…/node config b2c14377… và cache-pins ZER-19.
Receipt lịch sử pin3 fileGo, không attestation toàn bộ Go build context;
manifest mới pin toàn bộ Go source hiện tại để chống drift, không hồi tố build proof.
Python image chỉ transport/dependencies, signed executor/guard mount source mới.

Reader bắt buộc join đúng command/result/send/responseId/requestId và native
fixture access, fresh fixture/sourceUID, source/proxyIP, timezone/timestamp,
delivered200/row/restricted counts. Thiếu/trùng/lệch dừng trước Gaia/Healer.
Command schema giữ context3 trường, root trace/context6 trường. Cross-host clock
sync UNKNOWN; archive LOCAL_ONLY_NOT_AUTHENTICATED; không tính KPI.

API_ACCEPTED, ACTION_COMPLETED, containment probe và business recovery là các
fact riêng. Raw lỗi/cancellation/action-may-remain phải đối soát; không đoán
remote cancellation. Runtime output chỉ pending native reconciliation/review,
không tự issue_done/recovery_verified/benchmark_eligible.

Sau work tree closed: namespace owner+UID precondition delete, xác minh absent;
resource_guard phải PASS trước topic effects; chỉ xóa đúng2 OWNED topic khi
brokerUID khớp trong cleanup deadline. Kiểm shared specs/UID/restarts/resources.
Cleanup error/unchecked giữ INCOMPLETE, không replay work. Namespace deletion
bao gồm private workloads/rules/orders/Secrets/ledgers; không xóa sharedPVC.

Gói này chưa chứng minh AC01; cần raw reconciliation độc lập sau execution và
Hoàng acceptance. AC02/child51 chưa chạy. Không Boutique recovery/KPI/G3/G4,
không claim AI tốt hơn, không Git publication/Linear mutation hoặc thông báo.
