# ZER-21 runtime-03 — điều tra timeout native exec

Ngày 30/10/2026; mọi thời gian bên dưới là UTC (Việt Nam +7 giờ).

**Kết luận:** nguyên nhân trực tiếp khiến runner dừng là tiến trình `kubectl exec zer46-source-b` chưa hoàn tất sau 15 giây. Bằng chứng mới xác nhận **CPU throttling kéo dài trong chính container Source B**, đồng thời có thêm một tiến trình tồn tại qua mốc client timeout. Đây là hướng nguyên nhân mạnh nhất cho việc exec không hoàn tất đúng hạn; chưa đủ bằng chứng khẳng định CPU là nguyên nhân duy nhất, hoặc xác định tiến trình bị kẹt ở Python, runc hay kernel. Root cause sâu hơn vẫn UNKNOWN. Không thể gọi tăng CPU hoặc tăng timeout là bản sửa đã được chứng minh.

## Phạm vi và cách kiểm

Hoàng yêu cầu “hãy điều tra nguyên nhân cụ thể”. HEAD `a593885e15dc474b83590c4dcf1b214395492fcf`, branch `zer-21-linked-agent-cycle`; index rỗng. Đọc source/snapshot/raw, Docker logs/state, sao chép log containerd và entrypoint hiện có ra host, GET lịch sử Prometheus qua Kubernetes service proxy, kiểm client/server version. Không tạo process exec trong pod/node, không gọi fixture/SQLi/model/Doppler, không tạo workload hoặc replay runtime. Chỉ thêm thư mục investigation này, append issue note và cập nhật checkpoint NOW. Scope và Git dirty state ở `scope.json`; các receipt ghi thời điểm thu thập sau runtime, không được nhầm thành trace thu ngay lúc lỗi.

GitNexus context/query/context đã dùng để định hướng, nhưng index còn `incremental-in-progress`, trước đó refresh thất bại do alias collision. Không chạy lại rebuild cho điều tra này; call chain xác minh bằng source đã pin và raw thực tế, không dựa vào tính đầy đủ của graph.

## Các fact đã xác nhận

| Thời điểm | Bằng chứng |
| --- | --- |
| 03:58:03 | Source B Ready, UID `d9d88007-929b-4353-b37a-b439b60ff532`, container `9b1728d88265…`, node `k3d-zero-door-agent-0`, restart=0. |
| 03:58:26.190–27.705 | Source A hoàn tất cùng script isolation, `denied=true`, 1,515 giây (`runtime-03/raw/0084.json`). |
| 03:58:27.708 | Source B bắt đầu lệnh isolation (`raw/0085.json`). Container có request CPU `5m`, limit `50m`, memory limit `48Mi`; PID chính chỉ sleep. |
| 03:58:35.919 | Prometheus ghi 2 process trong Source B, CPU tổng 1,313263s (trước đó 0,040875s lúc 03:58:22.631), 72 throttled periods / 80 periods. |
| 03:58:38.298–38.506 | `kubectl get deploy,pod,pvc -A` vẫn hoàn tất trong 0,208s (`raw/0089.json`). Không có bằng chứng API server ngừng đáp ứng toàn bộ. |
| 03:58:42.777 | Runner chấm dứt client sau 15,069s; stdout/stderr rỗng, `COMMAND_TIMEOUT`. |
| 03:58:52.009 | Source B vẫn có 2 process. Counter CFS tăng lên 233 throttled / 241 total: **161/161 chu kỳ mới bị throttle trong 16,090s**. CPU usage được báo vẫn 1,313263s. |
| 03:58:56.049 | Containerd ghi lỗi pipe stdout/EOF cho exec ID `2ba1fd47…`. Log không có mapping exec ID → container nên chỉ là bằng chứng hỗ trợ, chưa nối chắc với Source B. |
| 03:59:03.042 | Source B về 1 process; CPU tổng 1,316739s. Container sau đó bị dọn theo cleanup đã duyệt; không còn để lấy stack của sự cố. |

Metric được nối bằng **cả pod UID và container ID** trong label `id`, không chỉ tên pod tái sử dụng. Raw Prometheus ở `source-resource-history.json`, `source-thread-history.json`. Các phép tính được kiểm lại tại `analysis.json`.

`161/161` là tỷ lệ chu kỳ có throttling, **không phải** 100% thời gian bị treo, không phải số giây bị throttle. Query `container_cpu_cfs_throttled_seconds_total` trả mảng rỗng (`cpu-throttled.json`), vì vậy chưa có tổng thời lượng throttle. CPU counter phẳng cùng CFS counter tăng không đủ xác định syscall/stack hay lỗi kernel. Xem định nghĩa metric của [cAdvisor](https://github.com/google/cadvisor/blob/master/docs/storage/prometheus.md).

CPU limit được Linux thực thi bằng throttling; `50m` tương đương 0,05 CPU. Cơ chế này được mô tả trong [Kubernetes resource management](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/). Throttling cùng tiến trình tồn tại kéo dài phù hợp với chậm thực thi trong container, nhưng đây vẫn là suy luận nhân quả từ tương quan, chưa phải phép thử can thiệp.

## Đối chứng có sẵn và loại trừ

Runtime-02 Source B: cùng script (chỉ khác IP fixture), cùng image/limit `50m`, hoàn tất 1,523s, `denied=true` (`runtime-02/raw/0082.json`). CPU tăng khoảng 0,075825s trong cửa sổ có probe; counters CFS tăng 13/16 chu kỳ, rồi đứng yên, số process được scrape là 1. Runtime-03 Source A cũng hoàn tất, CPU tăng khoảng 0,076931s. Source B runtime-03 tăng 1,272388s trong cửa sổ chứa probe, khoảng 16,8 lần đối chứng; không có profile để giải thích phần CPU tăng này. Các cửa sổ scrape khác nhau và không phải phép đo CPU riêng của một PID. Không suy `50m` luôn thất bại hoặc phép nâng CPU chắc chắn chữa được.

Memory guard không fail; Source B memory failcnt=0, working set cao nhất trong các mẫu khoảng 11,18MiB/48MiB. Snapshot Ready/restart=0 và log containerd chỉ dừng container khi cleanup, không cho thấy OOM/crash tại thời điểm timeout. Không có bằng chứng memory là tác nhân dừng.

Script isolation đặt socket timeout 2s, nhưng toàn lệnh còn có spawn/exec/startup/import/stream. Timeout socket không bảo đảm toàn lệnh hoàn tất trong 2s. Không nhận được output nên kết quả TCP Source B vẫn UNKNOWN; việc không trả lời không được tính là isolation PASS.

Call chain thực tế: `runtime-prep-03/lab.py:154–157` → inherited `ZER-46/runtime-prep/run_component.py:119–164` (`command`, timeout và terminate) và `:402–410` (`isolation`). Không chạy shell cho argv này; Python code được truyền như một argument. Raw Source A/B có cùng chương trình ngoài target IP ở hai lượt. Lỗi không đi qua Nemesis/selector: model calls=0, chưa tới SQLi/HTTP/Gaia/Hephaestus.

## Các vấn đề phụ đã tìm thấy

1. **Resource PASS chỉ kiểm memory.** `ZER-46/runtime-prep/preflight.py:87–108` kiểm host/WSL memory và memory PSI; không đo CPU/CFS của Source B. Do vậy preflight PASS không chứng minh native exec có đủ CPU để hoàn tất. Đây là giới hạn coverage đã xác nhận, không phải finding cleanup P2 cũ tái phát.
2. **Client/server lệch ngoài phạm vi hỗ trợ.** Client hiện tại từ Google Cloud SDK là `v1.33.5-dispatcher`, server `v1.31.5+k3s1`; chính CLI cảnh báo chênh 2 minor. [Kubernetes hỗ trợ ±1 minor](https://kubernetes.io/releases/version-skew-policy/). Runtime03 không pin hash executable `kubectl`, nên current identity không chứng minh tuyệt đối binary lịch sử; chưa có bằng chứng version skew gây timeout này. Nên pin client tương thích ở gói sửa sau, không tự nâng cả cluster.
3. **k3d entrypoint đang lặp lỗi localhost:8080.** Bản file lấy trực tiếp từ node có `until kubectl uncordon "$HOSTNAME"; do sleep 3; done` dòng23; agent logs ghi lỗi refused đều đặn trước/trong/sau probe. Khớp lỗi [k3d #1420](https://github.com/k3d-io/k3d/issues/1420), nhưng chưa kiểm env của tiến trình này nên chưa chốt nguyên nhân cấu hình tại máy. Đây là lỗi nền riêng; node vẫn chạy pod. Không có chứng cứ nối trực tiếp với exec Source B, không tự sửa/kết thúc entrypoint.
4. Server log `conn.go:339 use of closed network connection` cũng xuất hiện ngay khi các exec thành công đóng stream, gồm Source A. Không dùng riêng dòng này để kết luận mạng hỏng. [Báo cáo upstream](https://github.com/kubernetes/kubernetes/issues/140102) cũng mô tả kiểu log đó ở đóng kết nối bình thường. API-proxy logs trong cửa sổ không có dòng nào; sự vắng log không chứng minh proxy vô can.

## Hướng xử lý tối thiểu tiếp theo

Ưu tiên một diagnostic riêng cho **exec startup và CPU/CFS**, trước lần gọi model tiếp theo: cùng image, script lành chỉ đánh dấu thời điểm trước/sau import với output unbuffered, thu PID/state/CPU counters khi vượt ngưỡng, đối chiếu `50m` với một CPU budget đã định lượng. Giữ timeout ngoài, không bỏ isolation hoặc sửa UNKNOWN thành PASS. Cần xác định process bị giữ ở lớp nào; kết quả không được thay thế failure runtime03. Chỉ đổi profile source pod trong renderer ZER21 sau khi có căn cứ; không sửa artifact ZER41/46/50 lịch sử, không tăng tài nguyên toàn lab. Diagnostic tạo pod/exec và thử profile mới chưa được thực hiện trong lượt điều tra này; không ngầm dùng lại quyền runtime03 đã consumed.

Khi sửa runner cho gói sau, ghi executable/version client và marker trước/sau exec để lần lỗi kế tiếp có thể định vị; giữ secret redaction. Không cần sửa selector/model dựa trên sự cố này. AC01 vẫn NOT_MET, AC02 NOT_RUN; cleanup runtime03 CLEAN giữ nguyên.

## Bảo toàn và giới hạn

Thư mục này là phần điều tra bổ sung, không sửa `runtime-03/reconciliation.json` hoặc ledger lịch sử. `verification.json` ghi kiểm lại ledger runtime02/runtime03, 128 source pins và dirty files trước/sau append; `artifact-sha256.json` giữ hash toàn bộ gói điều tra. Không chạy product test vì không đổi source; phép kiểm ở đây là đọc dữ liệu, nối UID, tính counter delta và kiểm hash. Node/containerd logs chỉ giữ cửa sổ thời gian liên quan; bản đầy đủ đọc ra scratch không đưa vào repo.
