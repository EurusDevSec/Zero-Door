"""ZER23 cleanup-only continuation; no work/case/provider retries. Original evidence immutable."""
import os,sys,json,time,hashlib,pathlib,shutil
ROOT=pathlib.Path(r'C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door')
PREP=ROOT/'docs/evidence/ZER-23/runtime-prep-02'
OLD=ROOT/'docs/evidence/ZER-23/runtime-02/CANCEL'
OUT=ROOT/'docs/evidence/ZER-23/cleanup-resume-01'
sys.path.insert(0,str(PREP));os.environ['ZD23_CASE']='CANCEL';os.environ.pop('OPENAI_API_KEY',None)
import run as supervisor
supervisor.OUT=OUT
import lab
EXPECTED=['zer19-d1fcc6c6d3d7.'+s for s in ('commands','results','observations')]
def child():
 if sys.stdin.buffer.readline(4)!=b'GO\n':raise ValueError('SUPERVISOR_GATE_REQUIRED')
 supervisor.verify_sources();lab.pilot.kube_config_pin()
 state=json.loads((OUT/'state.json').read_bytes())
 if state['owner']!='zer46-3fe76cf530dd' or state['broker_uid']!='73f060b2-7a66-48ac-a8a9-b1bb5ec628f9' or state['topics']!=EXPECTED or state['topic_state']!={k:'OWNED' for k in EXPECTED}:raise ValueError('OWNERSHIP_SCOPE')
 actor=lab.make_lab();actor.seq=20000
 # Resource check before any effect; cleanup repeats the original independent resource gate.
 actor.resources()
 result=actor.cleanup_owned()
 print(json.dumps(result));return 0 if result['verdict']=='CLEAN' else 1
def main():
 if '--child' in sys.argv:return child()
 OUT.mkdir()
 for n in ('state.json','before.json','before-hpa.json'):shutil.copyfile(OLD/n,OUT/n)
 supervisor.save(OUT/'scope.json',{'issue':'ZER-23','outcome':'Finish owned cleanup only after MEMORY_STOP','authority':'Prior broad scoped project grant; user tiếp tục continuation. No new model/lab case/restart.','topics':EXPECTED,'owner':'zer46-3fe76cf530dd','broker_uid':'73f060b2-7a66-48ac-a8a9-b1bb5ec628f9','deadline_seconds':285,'original_cleanup_sha256':hashlib.sha256((OLD/'cleanup.json').read_bytes()).hexdigest(),'original_state_sha256':hashlib.sha256((OLD/'state.json').read_bytes()).hexdigest(),'source_manifest_sha256':supervisor.sha(PREP/'source-manifest.json'),'provider_calls':0,'http':0,'tcp':0,'shared_mutations':0})
 env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',MSYS_NO_PATHCONV='1')
 result=supervisor.run_child([sys.executable,'-B',__file__,'--child'],env,OUT/'worker.log',timeout=285)
 supervisor.save(OUT/'process.json',result);print(json.dumps(result));return 0 if result.get('exit_code')==0 and result.get('owned_tree_closed') and result.get('process_reaped') else 1
if __name__=='__main__':raise SystemExit(main())
