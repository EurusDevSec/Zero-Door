"""Pure exact two-field cartservice patch builder; no API or effects on import."""
UID = "8cd9e24f-05b8-45bb-a842-f66ae2420d0f"
def build_patch(doc):
    m=doc.get("metadata",{});s=doc.get("spec",{});containers=s.get("template",{}).get("spec",{}).get("containers",[])
    if (m.get("name")!="cartservice" or m.get("namespace")!="target-app" or m.get("uid")!=UID
            or not m.get("resourceVersion") or s.get("replicas")!=1 or len(containers)!=1
            or containers[0].get("name")!="server"
            or any(containers[0].get(p,{}).get("timeoutSeconds")!=1 for p in ("livenessProbe","readinessProbe"))):
        raise ValueError("CART_BASELINE_IDENTITY_OR_PROFILE")
    ops=[{"op":"test","path":"/metadata/uid","value":UID},
         {"op":"test","path":"/metadata/resourceVersion","value":m["resourceVersion"]},
         {"op":"test","path":"/spec/template/spec/containers/0/name","value":"server"}]
    for probe in ("livenessProbe","readinessProbe"):
        path="/spec/template/spec/containers/0/"+probe+"/timeoutSeconds"
        ops.extend([{"op":"test","path":path,"value":1},{"op":"replace","path":path,"value":3}])
    return ops
