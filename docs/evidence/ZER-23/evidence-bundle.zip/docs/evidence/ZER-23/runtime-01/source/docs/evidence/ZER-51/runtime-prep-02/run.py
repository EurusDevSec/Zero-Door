"""One authorized six-cell pilot batch. Default/import are PLAN_ONLY."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

PREP=Path(__file__).resolve().parent
ROOT=PREP.parents[3]
HEAD='a593885e15dc474b83590c4dcf1b214395492fcf'
sys.path.insert(0,str(ROOT/'agent-orchestrator'))
BATCH=PREP.parent/'runtime-02'
raw_index=os.environ.get('ZD51_INDEX')
if raw_index is not None and raw_index not in tuple(str(i) for i in range(6)):raise ValueError('PILOT_INDEX')
INDEX=int(raw_index) if raw_index is not None else None
OUT=BATCH if INDEX is None else BATCH/('trial-%02d'%(INDEX+1))
spec=importlib.util.spec_from_file_location('zer51_owned_supervisor',ROOT/'docs/evidence/ZER-21/runtime-prep-07/run.py')
owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
sha,save,native_python,run_child=owned.sha,owned.save,owned.native_python,owned.run_child


def verify_sources(root=ROOT,prep=PREP):return owned.verify_sources(root,prep)


def admit(path):
    auth=json.loads(Path(path).read_bytes())
    if (auth.get('approved') is not True or auth.get('issue')!='ZER-51' or auth.get('attempt')!='pilot-02'
            or auth.get('proposal_sha256')!=sha(PREP/'proposal.md')
            or auth.get('source_manifest_sha256')!=sha(PREP/'source-manifest.json')
            or type(auth.get('expires_epoch')) not in (int,float)
            or not time.time()<auth['expires_epoch']<=time.time()+86400
            or INDEX is not None and auth.get('trial_index')!=INDEX):
        raise ValueError('FRESH_PILOT_APPROVAL_REQUIRED')
    verify_sources();return auth


def child_env(index,environ=None,*,cleanup=False):
    from pilot import SCHEDULE
    env=dict(os.environ if environ is None else environ)
    env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',MSYS_NO_PATHCONV='1',ZD51_INDEX=str(index),
        PYTHONPATH=os.pathsep.join((str(ROOT/'agent-orchestrator'),str(Path(sys.prefix)/
            ('Lib/site-packages' if os.name=='nt' else 'lib/python%d.%d/site-packages'%sys.version_info[:2])))))
    if cleanup or SCHEDULE[index][0]!='B2':env.pop('OPENAI_API_KEY',None)
    return env


def execute(authorization):
    from pilot import SCHEDULE
    if INDEX is not None:raise ValueError('BATCH_PARENT_REQUIRED')
    auth=admit(authorization);BATCH.mkdir()
    save(BATCH/'authorization.json',auth)
    save(BATCH/'started.json',{'at':time.time(),'head':HEAD,'batch_seconds':3600,'restart_allowed':False})
    lock=verify_sources()
    for relative in lock['sha256']:
        p=BATCH/'source'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/relative).read_bytes())
    save(BATCH/'source-manifest.json',lock);(BATCH/'proposal.md').write_bytes((PREP/'proposal.md').read_bytes())
    rows=[];started=time.monotonic();deadline=started+3600
    for index,(group,case) in enumerate(SCHEDULE):
        if deadline-time.monotonic()<890:
            rows.append({'index':index,'group':group,'case':case,'status':'NOT_RUN_BATCH_DEADLINE'});break
        out=BATCH/('trial-%02d'%(index+1));out.mkdir()
        trial_auth=dict(auth,trial_index=index);save(out/'authorization.json',trial_auth)
        save(out/'started.json',{'at':time.time(),'head':HEAD,'trial_index':index,'group':group,'case':case,
            'work_seconds':600,'cleanup_seconds':300,'restart_allowed':False})
        worker=cleanup={};error=None
        try:worker=run_child([sys.executable,'-B',str(PREP/'lab.py'),'--work'],child_env(index),out/'worker.log',timeout=600)
        except BaseException as failure:error=type(failure).__name__
        finally:
            try:cleanup=run_child([sys.executable,'-B',str(PREP/'lab.py'),'--cleanup'],child_env(index,cleanup=True),out/'cleanup.log',timeout=285)
            except BaseException as failure:error=error or 'CLEANUP_'+type(failure).__name__
        work=json.loads((out/'work-result.json').read_bytes()) if (out/'work-result.json').exists() else {}
        clean=json.loads((out/'cleanup.json').read_bytes()) if (out/'cleanup.json').exists() else {}
        complete=(not error and worker.get('exit_code')==cleanup.get('exit_code')==0
            and not worker.get('timed_out') and not cleanup.get('timed_out')
            and work.get('status')=='OBSERVED_PENDING_REVIEW' and clean.get('verdict')=='CLEAN')
        row={'index':index,'group':group,'case':case,'status':'RECONCILE_REQUIRED' if complete else 'NOT_MET_OR_UNKNOWN',
             'failure':error,'worker':worker,'cleanup_process':cleanup,'work':work,'cleanup':clean.get('verdict','UNKNOWN')}
        save(out/'acceptance.json',row);rows.append(row)
        save(BATCH/'progress.json',{'rows':rows,'restart_allowed':False})
        if not complete:break  # No retry, skip or continue through an unknown/safety failure.
    result={'status':'RECONCILE_REQUIRED' if len(rows)==6 and all(x['status']=='RECONCILE_REQUIRED' for x in rows) else 'INCOMPLETE',
            'rows':rows,'elapsed_seconds':time.monotonic()-started,'provider_calls':sum(x.get('work',{}).get('provider_calls',0) for x in rows),
            'planned_cells':6,'completed_cells':sum(x['status']=='RECONCILE_REQUIRED' for x in rows),
            'restart_allowed':False,'issue_done':False,'benchmark_eligible':False}
    save(BATCH/'acceptance.json',result);print(json.dumps(result));return 0 if result['status']=='RECONCILE_REQUIRED' else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true');parser.add_argument('--authorization');args=parser.parse_args()
    if not args.execute:print(json.dumps({'status':'PLAN_ONLY','provider_calls':0,'lab_operations':0}));return 0
    if not args.authorization:parser.error('fresh bounded pilot authorization required')
    return execute(args.authorization)

if __name__=='__main__':raise SystemExit(main())
