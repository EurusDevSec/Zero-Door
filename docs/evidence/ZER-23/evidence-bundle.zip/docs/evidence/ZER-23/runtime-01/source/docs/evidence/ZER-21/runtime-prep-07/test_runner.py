"""Offline native boundaries; all provider/Kafka/Kubernetes operations are fake."""
import asyncio
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import run
import lab
import render


def inputs():
    ctx={'run_id':lab.new_id('run'),'trial_id':lab.new_id('trl'),'incident_id':lab.new_id('inc'),
        'group':'B2','method_version':'zer21-functional/1','config_ref':'sha256:'+'4'*64}
    command={'commandId':'55555555-5555-4555-8555-555555555555','context':{k:ctx[k] for k in ('run_id','trial_id','group')}}
    stamp=lambda n:datetime.fromtimestamp(n,timezone.utc).isoformat()
    send={'seq':1,'startedAt':stamp(100),'observedAt':stamp(102),'requestId':command['commandId']+'/1',
        'responseId':'a'*32,'status':200,'rows':2,'restrictedRows':1}
    result={'commandId':command['commandId'],'status':'SUCCESS','details':{'sqli':{'sends':[send]}}}
    receipt={'records':[{'event':'DISPATCH_INTENT','command':command},{'event':'EXECUTOR_RESULT','raw':result}]}
    raw={'request_id':'a'*32,'correlation_id':send['requestId'],'ts':101,'method':'GET',
        'path':'/fixture/catalog/search','status':200,'rows':2,'restricted_rows':1,
        'client_ip':'10.42.0.11','tcp_peer':'10.42.0.12','source_method':'XFF_AFTER_TRUSTED','source_confidence':'PROXY_CHAIN'}
    kw={'fixture_uid':'fixture-uid','pod_uid':'fixture-uid','source_ip':raw['client_ip'],
        'proxy_ip':raw['tcp_peer'],'begin':99,'end':103,'at':104,'ref':'worker-native-join.json'}
    return ctx,receipt,raw,kw


class Native(unittest.TestCase):
    def setUp(self):
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'))
        self.net.start();self.addCleanup(self.net.stop)
        self.native=patch.object(subprocess,'run',side_effect=AssertionError('NO_NATIVE_OPERATION'))
        self.native.start();self.addCleanup(self.native.stop)

    def test_raw_worker_join_keeps_rule_and_benign_value(self):
        ctx,receipt,raw,kw=inputs()
        got=lab.project_worker(ctx,receipt,raw,**kw)
        self.assertEqual(1,got['detection']['payload']['value'])
        self.assertEqual(got['detection']['event_id'],got['access']['detection_event_id'])
        self.assertNotIn('expected',json.dumps(got))
        raw['restricted_rows']=0;receipt['records'][1]['raw']['details']['sqli']['sends'][0]['restrictedRows']=0
        self.assertEqual(0,lab.project_worker(ctx,receipt,raw,**kw)['detection']['payload']['value'])

    def test_raw_join_rejects_id_uid_context_source_time_count_and_failed_delivery(self):
        for field,value in [('request_id','f'*32),('correlation_id','foreign'),('client_ip','10.42.0.99'),
                ('tcp_peer','10.42.0.99'),('source_confidence','UNKNOWN'),('source_method','DIRECT'),
                ('ts',98),('status',403),('rows',3),('restricted_rows',0),('delivered',False)]:
            ctx,receipt,raw,kw=inputs();raw[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)
        for key,value in [('pod_uid','foreign'),('at',170)]:
            ctx,receipt,raw,kw=inputs();kw[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)
        ctx,receipt,raw,kw=inputs();receipt['records'][0]['command']['context']=dict(ctx,group='B1')
        with self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)

    def test_cardinality_and_worker_failure_and_timezone_are_not_success(self):
        for mutate in [lambda r:r['records'].append(deepcopy(r['records'][0])),
                lambda r:r['records'][1]['raw'].update(status='FAILED'),
                lambda r:r['records'][1]['raw']['details']['sqli']['sends'][0].update(startedAt='1970-01-01T00:01:40'),
                lambda r:r['records'][1]['raw']['details']['sqli']['sends'][0].update(rows=True)]:
            ctx,receipt,raw,kw=inputs();mutate(receipt)
            with self.assertRaises(ValueError):lab.project_worker(ctx,receipt,raw,**kw)

    def test_actual_kube_forwards_bounded_topic_commands_and_claims(self):
     native=lab.make_lab(); native.broker_uid='broker-owned'; calls=[]
     def command(args,timeout=15,allowed=(0,)):
      calls.append((args,timeout,allowed))
      self.assertEqual(['kubectl','--context','k3d-zero-door','--request-timeout=12s'],args[:4])
      if args[4:]==['-n','zero-door','get','pod','kafka-controller-0','-o','json']:
       return subprocess.CompletedProcess(args,0,b'{"metadata":{"uid":"broker-owned"}}')
      self.assertEqual(10,timeout);self.assertIn('/opt/bitnami/kafka/bin/kafka-topics.sh',args)
      self.assertIn('KAFKA_HEAP_OPTS=-Xms16m -Xmx128m',args)
      if '--create' in args:
       self.assertEqual((0,1),allowed)
       self.assertEqual('UNKNOWN',native.topic_state[native.topics[0]])
      return subprocess.CompletedProcess(args,0,(native.topics[0]+'\n').encode() if '--list' in args else b'')
     with patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY')),patch.object(subprocess,'Popen',side_effect=AssertionError('NO_NATIVE_OPERATION')),patch.object(native,'command',side_effect=command),patch.object(native,'checkpoint'):
      native.topic('create',native.topics[0]);self.assertEqual('OWNED',native.topic_state[native.topics[0]])
      self.assertEqual([native.topics[0]],native.topic('list',native.topics[0]))
      native.topic('delete',native.topics[0])
      with self.assertRaisesRegex(ValueError,'TOPIC_ALREADY_ATTEMPTED'):native.topic('create',native.topics[0])
     topic_calls=[c for c in calls if '/opt/bitnami/kafka/bin/kafka-topics.sh' in c[0]]
     self.assertEqual(3,len(topic_calls))

    def test_actual_provenance_and_manifest_are_pinned(self):
        provenance=lab.worker_build_provenance()
        self.assertEqual(3,len(provenance['source_paths']))
        self.assertIs(False,provenance['full_build_context_attested'])
        self.assertGreater(len(run.verify_sources()['sha256']),50)
        with patch.object(lab.supervisor,'sha',return_value='0'*64):
            with self.assertRaisesRegex(ValueError,'CACHED_WORKER_SOURCE_DRIFT'):lab.worker_build_provenance()

    def test_renderer_stays_private_and_limits_one_send(self):
        ctx,_,_,_=inputs()
        docs=render.render('zer46-123456abcdef',ctx['run_id'],ctx['trial_id'],'10.42.0.12')
        self.assertEqual(4,len([d for d in docs if d['kind'] in {'Deployment','Pod'}]))
        self.assertNotIn('Ingress',{d['kind'] for d in docs})
        alias=next(d for d in docs if d['kind']=='Service' and d['metadata']['name']=='zer41-private-ingress')
        self.assertEqual('ClusterIP',alias['spec'].get('type','ClusterIP'))
        extra,containers,volumes,policy=render.worker_documents(ctx,'zer46-123456abcdef','10.43.0.11')
        self.assertTrue(policy['enabled']);self.assertEqual({k:ctx[k] for k in ('run_id','trial_id','group')},policy['context'])
        for k in ['maxDurationSec','maxConcurrency','rps']:self.assertEqual(1,policy[k])
        self.assertEqual(1,policy['sqli']['maxSends']);self.assertEqual(1,policy['sqli']['maxCommandSec'])
        self.assertTrue(all(c['imagePullPolicy']=='Never' for c in containers))
        self.assertNotIn('OPENAI_API_KEY',[e['name'] for c in containers for e in c['env']])
        from event_pipeline.llm import Adapter, RunBudget, Limits
        adapter=Adapter(object(),RunBudget(ctx['run_id'],max_calls=3,max_reserved_tokens=30000,max_estimated_usd=.015,duration_s=300),limits=Limits(attempts=1,max_output_tokens=256))
        session=lab.Session(purpose=lab.PURPOSE,guard=lab.CommandGuard(policy),adapter=adapter,observe=None,execute=None,context=ctx,limits=lab.SessionLimits(max_rounds=1,command_s=1,allowed_templates=('disclose-restricted',)))
        self.assertEqual(ctx,session.context)
        network=next(d for d in extra if d['kind']=='NetworkPolicy')
        self.assertEqual([{'protocol':'TCP','port':9092}],network['spec']['egress'][0]['ports'])
        for address in ['8.8.8.8','127.0.0.1','0.0.0.0','169.254.1.1','240.0.0.1','224.0.0.1','::1']:
            with self.subTest(address=address),self.assertRaises(ValueError):render.worker_documents(ctx,'zer46-123456abcdef',address)

    def test_default_and_unapproved_attempt_never_start_child(self):
        with patch.object(sys,'argv',['run.py']),patch.object(run,'execute',side_effect=AssertionError('NO_WORK')):
            self.assertEqual(0,run.main())
        with patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
            with self.assertRaisesRegex(ValueError,'FRESH_EXACT_OWNER_APPROVAL_REQUIRED'):
                run.execute(run.PREP/'approval-template.json')

    def test_wrong_expiry_and_manifest_or_proposal_pin_stop_before_child(self):
        import time
        auth=json.loads((run.PREP/'approval-template.json').read_bytes());auth.update(approved=True,expires_epoch=time.time()+60)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'auth.json'
            for change in [{'expires_epoch':time.time()-1},{'proposal_sha256':'0'*64},
                    {'source_manifest_sha256':'0'*64},{'issue':'ZER-50'},{'attempt':'runtime-03'},{'attempt':'runtime-04'},{'attempt':'runtime-05'},{'attempt':'runtime-06'}]:
                path.write_text(json.dumps(dict(auth,**change)))
                with patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
                    with self.assertRaises(ValueError):run.execute(path)

    def test_consumed_attempt_and_direct_child_cannot_replay(self):
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)
            with patch.object(run,'OUT',out),patch.object(run,'admit',return_value={}),patch.object(run,'run_child',side_effect=AssertionError('NO_CHILD')):
                with self.assertRaises(FileExistsError):run.execute('fake')
            with patch.object(lab.fixture,'OUT',out):
                with self.assertRaises(FileNotFoundError):lab.claim_work()
                (out/'started.json').write_text(json.dumps({'head':run.HEAD}))
                with patch.object(run,'admit',return_value={}):
                    lab.claim_work()
                    with self.assertRaises(FileExistsError):lab.claim_work()

    def test_source_uid_and_http_bound_stop_before_dispatch(self):
        native=lab.make_lab();native.fixture_http=8
        with patch.object(native,'command',side_effect=AssertionError('NO_LAB')):
            with self.assertRaisesRegex(ValueError,'ZER21_HTTP_BUDGET'):native.http('a')
        native.source_uids={'a':'owned'}
        with patch.object(native,'pod',return_value={'metadata':{'uid':'foreign'}}):
            with self.assertRaisesRegex(ValueError,'SOURCE_POD_UID_DRIFT'):native.check_sources()

    def test_api_single_attempt_and_topic_unknown_ownership(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        class API:
            writes=0;api_client=None
            def replace_namespaced_config_map(self,*a,**kw):self.writes+=1;return {'accepted':True}
        api=API()
        with patch.object(base,'native_api',return_value=(api,None)),patch.object(native,'check_sources'),patch.object(native,'pod'):
            single,_=native.native_api();single.replace_namespaced_config_map()
            with self.assertRaisesRegex(ValueError,'SINGLE_API_WRITE_BOUND'):single.replace_namespaced_config_map()
        native.topic_state={'owned.commands':'UNKNOWN'};calls=[]
        def topic(operation,name):
            calls.append(operation);return [name]
        clean={'namespace_absent':True,'failed_step':None,'resource_guard':'PASS','verdict':'CLEAN'}
        with patch.object(native,'cleanup_namespace',return_value=dict(clean)),patch.object(native,'topic',side_effect=topic),patch.object(native,'save'):
            result=native.cleanup_owned()
        self.assertEqual('INCOMPLETE',result['verdict']);self.assertEqual(['list'],calls)
        native.topic_state={'owned.commands':'OWNED'};calls=[]
        def owned_topic(operation,name):
            calls.append(operation);return [name] if calls==['list'] else []
        with patch.object(native,'cleanup_namespace',return_value=dict(clean)),patch.object(native,'topic',side_effect=owned_topic),patch.object(native,'save'):
            self.assertEqual('CLEAN',native.cleanup_owned()['verdict'])
        self.assertEqual(['list','delete','list'],calls)

    def test_identity_drift_at_action_boundary_stops_api_write(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        class API:
            writes=0;api_client=None
            def replace_namespaced_config_map(self,*a,**kw):raise AssertionError('NO_NATIVE_WRITE')
        for method in ('check_sources','pod'):
            with self.subTest(method=method),patch.object(base,'native_api',return_value=(API(),None)),patch.object(native,'check_sources'),patch.object(native,'pod'):
                with patch.object(native,method,side_effect=ValueError('IDENTITY_DRIFT')):
                    api,_=native.native_api()
                    with self.assertRaisesRegex(ValueError,'IDENTITY_DRIFT'):api.replace_namespaced_config_map()
                    self.assertEqual(0,api.writes)

    def test_foreign_namespace_or_broker_never_deletes_topics(self):
        native=lab.make_lab()
        native.topic_state={native.topics[0]:'OWNED'}
        with patch.object(native,'cleanup_namespace',return_value={'namespace_absent':False,'failed_step':None,'verdict':'INCOMPLETE'}),patch.object(native,'topic',side_effect=AssertionError('NO_TOPIC_DELETE')),patch.object(native,'save'):
            self.assertEqual('INCOMPLETE',native.cleanup_owned()['verdict'])
        native.broker_uid='owned'
        with patch.object(native,'kube',return_value=subprocess.CompletedProcess([],0,b'{"metadata":{"uid":"foreign"}}')):
            with self.assertRaisesRegex(ValueError,'BROKER_UID_DRIFT'):native.topic('delete',native.topics[0])

    def cleanup_case(self,*,namespace_get=None,named=b'',resources=None,before=True,snapshot=None):
        """Run the real cleanup control flow against fake kube/snapshot/guard; no native operation."""
        native=lab.make_lab();native.topic_state={native.topics[0]:'OWNED'};calls=[];saved={}
        def guard():
            calls.append(('resources',))
            if resources:raise resources
        def topic(*args):
            calls.append(('topic',)+args);raise AssertionError('NO_TOPIC_OPERATION')
        def kube(*args,**kw):
            calls.append(args)
            if args[:2]==('get','namespace') and args[-1]=='json':
                if namespace_get:raise namespace_get
                return subprocess.CompletedProcess([],0,json.dumps({'metadata':{'uid':'ns-uid','labels':{'zero-door.io/run':'owner'}}}).encode())
            if args[:2]==('get','namespace'):return subprocess.CompletedProcess([],0,named)
            return subprocess.CompletedProcess([],0,b'')
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)
            (out/'state.json').write_text(json.dumps({'creation_attempted':True,'owner':'owner','ns_uid':'ns-uid'}))
            if before:(out/'before.json').write_text('{}')
            with patch.object(lab,'OUT',out),patch.object(lab.fixture,'OUT',out),patch.object(native,'kube',side_effect=kube),\
                    patch.object(native,'command',return_value=subprocess.CompletedProcess([],0,b'')),\
                    patch.object(native,'snapshot',return_value={},side_effect=snapshot),patch.object(native,'shared',side_effect=lambda x:x),\
                    patch.object(native,'specs',return_value='same'),patch.object(native,'restarts',return_value='same'),\
                    patch.object(native,'resources',side_effect=guard),\
                    patch.object(native,'save',side_effect=lambda name,doc:saved.__setitem__(name,deepcopy(doc))),\
                    patch.object(native,'topic',side_effect=topic):
                result=native.cleanup_owned()
        self.assertEqual(result,saved['cleanup.json'])
        return result,calls

    def assert_topics_recorded(self,result,status):
        self.assertEqual(status,result.get('topic_cleanup'));self.assertEqual(1,len(result.get('topic_state',{})))
        self.assertEqual('INCOMPLETE',result['verdict'])

    def test_late_resource_guard_keeps_known_facts_and_leaves_topics_pending(self):
        result,calls=self.cleanup_case(resources=RuntimeError('MEMORY_STOP'))
        self.assertIs(True,result['namespace_absent']);self.assertIs(True,result['rules_and_owned_orders_removed_by_namespace_deletion'])
        self.assertIs(True,result['shared_specs_preserved']);self.assertIs(True,result['shared_restarts_preserved'])
        self.assertEqual(['RuntimeError:MEMORY_STOP'],result['errors']);self.assertEqual('resources',result.get('failed_step'))
        self.assertIn(('delete','--raw','/api/v1/namespaces/'+lab.fixture.NAMESPACE),[c[:3] for c in calls])
        self.assert_topics_recorded(result,'PENDING_RESOURCE_GUARD')

    def test_unchecked_namespace_is_unknown_not_present(self):
        result,calls=self.cleanup_case(namespace_get=RuntimeError('COMMAND_TIMEOUT'))
        for key in ('namespace_absent','shared_specs_preserved','shared_restarts_preserved'):
            self.assertIsNone(result[key])
        self.assertEqual('namespace',result.get('failed_step'))
        self.assertFalse([c for c in calls if c[0]=='delete'])
        self.assert_topics_recorded(result,'NOT_ATTEMPTED_NAMESPACE_NOT_CONFIRMED_ABSENT')

    def test_present_namespace_is_known_false_and_blocks_topics(self):
        result,_=self.cleanup_case(named=('namespace/'+lab.fixture.NAMESPACE).encode())
        self.assertIs(False,result['namespace_absent']);self.assertEqual([],result['errors'])
        self.assert_topics_recorded(result,'NOT_ATTEMPTED_NAMESPACE_NOT_CONFIRMED_ABSENT')

    def test_missing_before_snapshot_is_unchecked_not_preserved(self):
        result,_=self.cleanup_case(before=False,resources=RuntimeError('MEMORY_STOP'))
        self.assertIs(True,result['namespace_absent'])
        self.assertIsNone(result['shared_specs_preserved']);self.assertIsNone(result['shared_restarts_preserved'])
        self.assert_topics_recorded(result,'PENDING_RESOURCE_GUARD')

    def test_snapshot_failure_still_runs_resource_guard_and_blocks_topics_on_fail(self):
        result,calls=self.cleanup_case(snapshot=RuntimeError('SNAPSHOT_FAILED'),resources=RuntimeError('MEMORY_STOP'))
        self.assertIs(True,result['namespace_absent']);self.assertIsNone(result['shared_specs_preserved'])
        self.assertEqual(['RuntimeError:SNAPSHOT_FAILED','RuntimeError:MEMORY_STOP'],result['errors'])
        self.assertEqual('shared',result.get('failed_step'));self.assertEqual('FAIL',result.get('resource_guard'))
        self.assertEqual(1,calls.count(('resources',)));self.assertFalse([c for c in calls if c[0]=='topic'])
        self.assert_topics_recorded(result,'PENDING_RESOURCE_GUARD')

    def test_snapshot_failure_attempts_owned_topics_only_after_resource_pass(self):
        result,calls=self.cleanup_case(snapshot=RuntimeError('SNAPSHOT_FAILED'))
        self.assertIs(True,result['namespace_absent']);self.assertIsNone(result['shared_specs_preserved'])
        self.assertEqual('shared',result.get('failed_step'));self.assertEqual('PASS',result.get('resource_guard'))
        topics=[i for i,c in enumerate(calls) if c[0]=='topic']
        self.assertTrue(topics);self.assertEqual(1,calls.count(('resources',)))
        self.assertLess(calls.index(('resources',)),topics[0])
        # The fake topic() refuses every operation, so an attempt is visible as a recorded topic error.
        self.assertEqual(['AssertionError:NO_TOPIC_OPERATION'],result.get('topic_cleanup_errors'))
        self.assert_topics_recorded(result,'ATTEMPTED')

    def test_source_cpu_limit_and_unique_kafka_label_are_scoped(self):
        ctx,_,_,_=inputs();args=('zer46-123456abcdef',ctx['run_id'],ctx['trial_id'],'10.42.0.12')
        base,docs=render.fixture.render(*args,node='k3d-zero-door-agent-0'),render.render(*args)
        for name in ('zer46-source-a','zer46-source-b'):
            pod=lambda ds:next(d for d in ds if d['kind']=='Pod' and d['metadata']['name']==name)
            before,after=pod(base),pod(docs)
            c=next(c for c in after['spec']['containers'] if c['name']=='source')
            self.assertEqual({'requests':{'cpu':'5m','memory':'16Mi'},'limits':{'cpu':'500m','memory':'48Mi'}},c['resources'])
            next(c for c in before['spec']['containers'] if c['name']=='source')['resources']['limits']['cpu']='500m'
            if name=='zer46-source-a':before['metadata']['labels']['zero-door.io/kafka-client']='zer46-123456abcdef'
            self.assertEqual(before,after)
        others=lambda ds:[d for d in ds if not (d['kind']=='Pod' and d['metadata']['name'].startswith('zer46-source-'))]
        self.assertEqual(others(base),others(docs)[:-1]);self.assertEqual('zer41-private-ingress',docs[-1]['metadata']['name'])

    def timeout_case(self,*args,pod=None,docker_out=None):
        native=lab.make_lab();native.node='k3d-zero-door-agent-0';calls,saved=[],{}
        uid,cid='d9d88007-929b-4353-b37a-b439b60ff532','9b1728d88265ea72f0890cabd82f1108f7127ccc434bde7212dcf719ccbde7c6'
        def command(argv,timeout=15,allowed=(0,)):
            calls.append(argv)
            if argv[0]=='kubectl':raise RuntimeError('COMMAND_TIMEOUT')
            return subprocess.CompletedProcess(argv,0,docker_out if docker_out is not None else
                b'50000 100000\n@@\nusage_usec 1313263\nnr_periods 80\nnr_throttled 72\n@@\nusage_usec 1313263\nnr_periods 100\nnr_throttled 92\n')
        status=lambda name:{'metadata':{'uid':uid},'status':{'containerStatuses':[{'name':'source','containerID':'containerd://'+cid},
            {'name':'zer21-transport','containerID':'containerd://'+'a'*64}]}}
        with patch.object(native,'command',side_effect=command),patch.object(native,'pod',side_effect=pod or status),\
                patch.object(native,'save',side_effect=lambda name,doc:saved.__setitem__(name,deepcopy(doc))):
            with self.assertRaisesRegex(RuntimeError,'^COMMAND_TIMEOUT$'):native.kube(*args)
        return calls,saved,uid,cid

    def test_source_exec_timeout_records_cpu_debt_then_reraises(self):
        calls,saved,uid,cid=self.timeout_case('-n','zd-sqli-lab','exec','zer46-source-b','--','/usr/bin/python3','-c','print(1)')
        doc=saved['zer46-source-b-source-timeout-cpu.json']
        self.assertEqual(('source',uid,cid,'50000 100000'),(doc['container'],doc['pod_uid'],doc['container_id'],doc['cpu_max']))
        self.assertEqual([{'usage_usec':1313263,'nr_periods':80,'nr_throttled':72},{'usage_usec':1313263,'nr_periods':100,'nr_throttled':92}],doc['cpu_stat'])
        docker=calls[1]
        self.assertEqual(['docker','--context','desktop-linux','exec','k3d-zero-door-agent-0','sh','-c'],docker[:7])
        self.assertIn('/pod'+uid+'/'+cid,docker[7]);self.assertEqual(2,len(calls))

    def test_transport_exec_timeout_snapshots_that_container(self):
        _,saved,_,_=self.timeout_case('-n','zd-sqli-lab','exec','-i','zer46-source-a','-c','zer21-transport','--','python','-B','/current/remote.py')
        self.assertEqual('a'*64,saved['zer46-source-a-zer21-transport-timeout-cpu.json']['container_id'])

    def test_no_snapshot_for_other_commands_and_snapshot_failure_keeps_timeout(self):
        for args in [('get','pod','zer46-source-b'),('-n','zero-door','exec','kafka-controller-0','--','true')]:
            with self.subTest(args=args):
                calls,saved,_,_=self.timeout_case(*args)
                self.assertEqual(({},1),(saved,len(calls)))
        def broken(name):raise RuntimeError('API_DOWN')
        calls,saved,_,_=self.timeout_case('-n','zd-sqli-lab','exec','zer46-source-b','--','true',pod=broken)
        self.assertEqual('RuntimeError:API_DOWN',saved['zer46-source-b-source-timeout-cpu.json']['error']);self.assertEqual(1,len(calls))
        _,saved,_,_=self.timeout_case('-n','zd-sqli-lab','exec','zer46-source-b','--','true',docker_out=b'')
        self.assertIn('error',saved['zer46-source-b-source-timeout-cpu.json'])

    def test_timeout_cpu_snapshot_has_one_native_attempt_and_keeps_timeout(self):
        native=lab.make_lab();calls=[]
        def cpu(*args,**kwargs):
            calls.append((args,kwargs));raise RuntimeError('READ_FAILED')
        with patch.object(native,'command',side_effect=RuntimeError('COMMAND_TIMEOUT')), \
                patch.object(native,'container_cpu',side_effect=cpu),patch.object(native,'save'):
            for name in ('zer46-source-a','zer46-source-b'):
                with self.assertRaisesRegex(RuntimeError,'^COMMAND_TIMEOUT$'):
                    native.kube('-n','zd-sqli-lab','exec',name,'--','true')
        self.assertEqual(1,len(calls));self.assertTrue(native.cpu_snapshot_attempted)

    def gate_case(self,charge=None,out=b'warm\n',docker_out=None,exec_error=None):
        """Real gate + container_cpu over fake kubectl/docker; per-pod cumulative cgroup counters."""
        native=lab.make_lab();native.node='k3d-zero-door-agent-0';base=type(native).__mro__[1]
        charge=charge or {};usage={'a':40_000,'b':40_000};calls,saved,tcp=[],{},[]
        cid=lambda who:(who*64)[:64].replace(who,'c' if who=='a' else 'd')
        def command(argv,timeout=15,allowed=(0,)):
            calls.append(argv)
            if argv[0]=='kubectl':
                if exec_error:raise RuntimeError(exec_error)
                who=next(a for a in argv if a.startswith('zer46-source-'))[-1]
                usage[who]+=charge.get(who,80_000)
                return subprocess.CompletedProcess(argv,0,out,b'')
            who='a' if cid('a') in argv[-1] else 'b'
            text=docker_out if docker_out is not None else ('50000 100000\n@@\nusage_usec %d\nuser_usec 1\nsystem_usec 1\nnr_periods 9\nnr_throttled 3\n'%usage[who]).encode()
            return subprocess.CompletedProcess(argv,0,text,b'')
        pod=lambda name:{'metadata':{'uid':'d9d88007-929b-4353-b37a-b439b60ff53'+name[-1].replace('a','0').replace('b','1')},
            'status':{'containerStatuses':[{'name':'source','containerID':'containerd://'+cid(name[-1])}]}}
        with patch.object(native,'command',side_effect=command),patch.object(native,'pod',side_effect=pod),\
                patch.object(native,'save',side_effect=lambda name,doc:saved.__setitem__(name,deepcopy(doc))),\
                patch.object(native,'transport_dependency_gate'),patch.object(native,'memory_settle_gate'),patch.object(base,'isolation',side_effect=lambda fixture:tcp.append(fixture)):
            try:native.isolation({'fixture':1});error=None
            except Exception as e:error=e
        return error,calls,saved,tcp

    def test_source_cpu_gate_passes_normal_exec_then_runs_isolation(self):
        error,calls,saved,tcp=self.gate_case()
        self.assertIsNone(error);self.assertEqual([{'fixture':1}],tcp)
        gate=saved['source-cpu-gate.json'];self.assertEqual('PASS',gate['verdict'])
        self.assertEqual({'a':80_000,'b':80_000},{w:r['delta']['usage_usec'] for w,r in gate['sources'].items()})
        execs=[c for c in calls if c[0]=='kubectl']
        self.assertEqual(2,len(execs));self.assertTrue(all('socket' not in ' '.join(c) and c[c.index('--')+1:]==['/usr/bin/python3','-c',"print('warm')"] for c in execs))

    def test_source_cpu_debt_or_bad_output_stops_before_tcp_http_or_model(self):
        for kwargs in ({'charge':{'b':1_272_000}},{'out':b''},{'charge':{'a':300_001}}):
            with self.subTest(kwargs=kwargs):
                error,_,saved,tcp=self.gate_case(**kwargs)
                self.assertIsInstance(error,ValueError)  # main() keeps only ValueError text in the receipt.
                self.assertEqual('SOURCE_CPU_DEBT',str(error));self.assertEqual([],tcp)
                self.assertEqual('FAIL',saved['source-cpu-gate.json']['verdict'])
        with patch.object(lab,'SOURCE_GATE_WALL_S',-1):
            error,_,_,tcp=self.gate_case()
        self.assertEqual(('SOURCE_CPU_DEBT',[]),(str(error),tcp))

    def test_unreadable_cgroup_or_exec_timeout_is_not_a_pass(self):
        error,_,saved,tcp=self.gate_case(docker_out=b'')
        self.assertEqual(('CPU_STAT_UNREADABLE',[]),(str(error),tcp));self.assertNotIn('source-cpu-gate.json',saved)
        error,_,saved,tcp=self.gate_case(exec_error='COMMAND_TIMEOUT')
        self.assertEqual(('COMMAND_TIMEOUT',[]),(str(error),tcp));self.assertIn('zer46-source-a-source-timeout-cpu.json',saved)

    def test_transport_keeps_cached_dependency_directory(self):
        ctx,_,_,_=inputs()
        _,containers,_,_=render.worker_documents(ctx,'zer46-123456abcdef','10.43.0.11')
        transport=next(c for c in containers if c['name']=='zer21-transport')
        env={v['name']:v['value'] for v in transport['env']}
        self.assertEqual('/current:/usr/local/lib/python3.11/site-packages',env['PYTHONPATH'])
        self.assertNotIn('OPENAI_API_KEY',env)
        self.assertEqual('Never',transport['imagePullPolicy'])

    def test_transport_import_gate_passes_before_isolation_and_fails_closed(self):
        for result in (subprocess.CompletedProcess([],0,b'transport-ready\n'),
                       subprocess.CompletedProcess([],0,b''),
                       RuntimeError('COMMAND_FAILED')):
            with self.subTest(result=type(result).__name__):
                native=lab.make_lab();base=type(native).__mro__[1];saved={};order=[]
                def kube(*args,**kwargs):
                    order.append('transport');self.assertEqual(15,kwargs['timeout'])
                    self.assertEqual(('exec','zer46-source-a','-c','zer21-transport'),args[2:6])
                    self.assertIn("run_name='zer21_dependency_check'",args[-1])
                    self.assertIn("runpy.run_path('/current/remote.py'",args[-1])
                    if isinstance(result,Exception):raise result
                    return result
                with patch.object(native,'source_cpu_gate',side_effect=lambda:order.append('cpu')), \
                        patch.object(native,'memory_settle_gate',side_effect=lambda:order.append('memory')), \
                        patch.object(native,'kube',side_effect=kube), \
                        patch.object(native,'save',side_effect=lambda n,d:saved.__setitem__(n,d)), \
                        patch.object(base,'isolation',side_effect=lambda f:order.append('tcp')):
                    if isinstance(result,Exception) or result.stdout!=b'transport-ready\n':
                        with self.assertRaisesRegex(ValueError,'TRANSPORT_DEPENDENCIES_NOT_READY'):native.isolation({})
                        self.assertEqual(['cpu','transport'],order)
                        self.assertEqual('FAIL',saved['transport-dependency-gate.json']['verdict'])
                    else:
                        native.isolation({});self.assertEqual(['cpu','transport','memory','tcp'],order)
                        self.assertEqual('PASS',saved['transport-dependency-gate.json']['verdict'])

    def test_kafka_policy_selects_exactly_rendered_source_a_and_not_b_or_foreign_owner(self):
        ctx,_,_,_=inputs();owner='zer46-123456abcdef'
        docs=render.render(owner,ctx['run_id'],ctx['trial_id'],'10.42.0.12')
        extra,_,_,_=render.worker_documents(ctx,owner,'10.43.0.11')
        policy=next(d for d in extra if d['kind']=='NetworkPolicy')
        selector=policy['spec']['podSelector']['matchLabels']
        selected=lambda pod:all(pod['metadata']['labels'].get(k)==v for k,v in selector.items())
        sources=[d for d in docs if d['kind']=='Pod' and d['metadata']['name'].startswith('zer46-source-')]
        self.assertEqual(['zer46-source-a'],[p['metadata']['name'] for p in sources if selected(p)])
        self.assertEqual({'zero-door.io/run':owner,'zero-door.io/kafka-client':owner},selector)
        foreign=deepcopy(next(p for p in sources if p['metadata']['name']=='zer46-source-a'))
        foreign['metadata']['labels']['zero-door.io/run']='foreign';self.assertFalse(selected(foreign))
        other=render.render('zer46-abcdef123456',ctx['run_id'],ctx['trial_id'],'10.42.0.12')
        self.assertFalse(any(selected(p) for p in other if p['kind']=='Pod'))
        self.assertEqual([{'to':[{'namespaceSelector':{'matchLabels':{'kubernetes.io/metadata.name':'zero-door'}},
            'podSelector':{'matchLabels':{'app.kubernetes.io/name':'kafka'}}}],
            'ports':[{'protocol':'TCP','port':9092}]}],policy['spec']['egress'])

    def test_worker_millisecond_end_allows_only_its_truncation_interval(self):
        for offset in (0,.000327,.000999):
            with self.subTest(offset=offset):
                ctx,receipt,raw,kw=inputs();send=receipt['records'][1]['raw']['details']['sqli']['sends'][0]
                send['observedAt']='1970-01-01T00:01:41.003Z';raw['ts']=101.003+offset
                got=lab.project_worker(ctx,receipt,raw,**kw)
                self.assertEqual(raw['ts'],got['access']['ts'])  # Preserve original precision.
        for offset in (.001,.001001,.1):
            with self.subTest(offset=offset):
                ctx,receipt,raw,kw=inputs();send=receipt['records'][1]['raw']['details']['sqli']['sends'][0]
                send['observedAt']='1970-01-01T00:01:41.003Z';raw['ts']=101.003+offset
                with self.assertRaisesRegex(ValueError,'NATIVE_WORKER_ACCESS_JOIN'):lab.project_worker(ctx,receipt,raw,**kw)

    def test_non_millisecond_end_does_not_get_generic_clock_tolerance(self):
        ctx,receipt,raw,kw=inputs();send=receipt['records'][1]['raw']['details']['sqli']['sends'][0]
        send['observedAt']='1970-01-01T00:01:41.003000Z';raw['ts']=101.003327
        with self.assertRaisesRegex(ValueError,'NATIVE_WORKER_ACCESS_JOIN'):lab.project_worker(ctx,receipt,raw,**kw)

    def test_source_manifest_rejects_path_escape_or_drift(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);prep=root/'prep';prep.mkdir()
            for path in ['../outside','missing']:
                (prep/'source-manifest.json').write_text(json.dumps({'sha256':{path:'0'*64}}))
                with self.assertRaises((ValueError,FileNotFoundError)):run.verify_sources(root,prep)

    def test_memory_settle_window_is_bounded_and_before_tcp(self):
        native=lab.make_lab();base=type(native).__mro__[1];waits=[];saved={};order=[]
        def resource():
            native.samples.append({'memoryPsiAvg10':0,'hostAvailable':2**31,'wslAvailableKiB':2**21})
        with patch.object(native,'wait',side_effect=waits.append),patch.object(native,'resources',side_effect=resource),                 patch.object(native,'check'),patch.object(native,'save',side_effect=lambda n,d:saved.__setitem__(n,d)),                 patch.object(lab.time,'monotonic',return_value=100):
            native.memory_settle_gate()
        self.assertEqual([100,105,110,115,120,125,130],waits)
        self.assertEqual('PASS',saved['memory-settle-gate.json']['verdict'])
        self.assertEqual(7,len(saved['memory-settle-gate.json']['samples']))
        with patch.object(native,'source_cpu_gate',side_effect=lambda:order.append('cpu')),                 patch.object(native,'transport_dependency_gate',side_effect=lambda:order.append('import')),                 patch.object(native,'memory_settle_gate',side_effect=lambda:order.append('memory')),                 patch.object(base,'isolation',side_effect=lambda f:order.append('tcp')):
            native.isolation({})
        self.assertEqual(['cpu','import','memory','tcp'],order)

    def test_memory_settle_failure_never_waits_until_success_or_sends_tcp(self):
        for mode in ('psi','guard','missing'):
            with self.subTest(mode=mode):
                native=lab.make_lab();base=type(native).__mro__[1];saved={}
                def resource():
                    if mode=='guard':raise RuntimeError('MEMORY_STOP')
                    if mode!='missing':native.samples.append({'memoryPsiAvg10':1.01})
                with patch.object(native,'source_cpu_gate'),patch.object(native,'transport_dependency_gate'),                         patch.object(native,'resources',side_effect=resource) as reads,patch.object(native,'wait'),                         patch.object(native,'save',side_effect=lambda n,d:saved.__setitem__(n,d)),                         patch.object(base,'isolation') as tcp:
                    with self.assertRaises((ValueError,RuntimeError)):native.isolation({})
                self.assertEqual(1,reads.call_count);tcp.assert_not_called()
                self.assertEqual('FAIL',saved['memory-settle-gate.json']['verdict'])
                self.assertFalse(saved['memory-settle-gate.json']['retry'])

    def test_memory_diagnostics_reuses_existing_exec_and_preserves_timeout(self):
        native=lab.make_lab();base=type(native).__mro__[1]
        args=['docker','--context','desktop-linux','exec','k3d-zero-door-server-0','cat','/proc/meminfo','/proc/pressure/memory']
        with patch.object(base,'command',return_value='fake') as call:
            self.assertEqual('fake',native.command(args,timeout=4))
            call.assert_called_once_with([*args,'/proc/vmstat'],timeout=4,allowed=(0,))
        self.assertEqual(8,len(args))
        with patch.object(base,'command',return_value='fake') as call:
            native.command(['kubectl','get','pods'],timeout=10,allowed=(0,1))
            call.assert_called_once_with(['kubectl','get','pods'],timeout=10,allowed=(0,1))


class NativeAsync(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'))
        self.net.start();self.addCleanup(self.net.stop)

    async def test_cancellation_drains_one_reserved_worker_execution_without_retry(self):
        import threading
        native=lab.make_lab();native.fixture_http=1
        entered=threading.Event();release=threading.Event();calls=[]
        def execute(*a,**kw):
            calls.append(a);entered.set();release.wait(timeout=2)
            return subprocess.CompletedProcess([],0,b'{"status":"SUCCESS"}')
        with patch.object(native,'check_sources'),patch.object(native,'save'),patch.object(native,'checkpoint'),patch.object(native,'input_command',side_effect=execute):
            task=asyncio.create_task(native.execute_worker({'commandId':'fake'}))
            await asyncio.to_thread(entered.wait,1)
            self.assertTrue(entered.is_set());task.cancel();await asyncio.sleep(.01)
            self.assertFalse(task.done());release.set()
            with self.assertRaises(asyncio.CancelledError):await task
            with self.assertRaisesRegex(ValueError,'EXECUTOR_REPLAY'):await native.execute_worker({})
        self.assertEqual(1,len(calls));self.assertEqual(2,native.fixture_http)


if __name__=='__main__':unittest.main(verbosity=2)
