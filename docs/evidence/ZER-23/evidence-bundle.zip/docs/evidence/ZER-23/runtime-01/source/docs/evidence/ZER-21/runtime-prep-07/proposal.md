# ZER-21 — runtime-07, một vòng functional với selector v2

OWNER_AUTHORIZED_SINGLE_RUNTIME07 / NOT_RUN. User30/10 cho phép điều tra PSI, khắc phục trong project và chạy runtime07; giữ trần cũ, không retry. Gói này phục vụ AC01, không phải pilot AC02/child ZER-51.
Checkout C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door; branch
zer-21-linked-agent-cycle; HEAD a593885e15dc474b83590c4dcf1b214395492fcf.
Source/dirty được khóa riêng; không gộp dirty của issue khác vào publication.

## Outcome và thay đổi so với lượt trước

Một trace thật Nemesis → signed Kafka/Go worker → trusted native access reader →
Gaia → Hephaestus → containment/probe. Một Adapter/backend/model gpt-6-luna,
chung budget và context. Reader tạo DETECTED bằng RULES; Gaia diagnosis và
Hephaestus action là hai quyết định LLM riêng. Không coi diagnosis là quyền dispatch.

runtime-01 dừng ở kube kwargs, runtime-02 có model STOP hợp lệ trước dispatch.
Sáu quyền cũ đã dùng hết; raw/source/authorization gốc giữ nguyên. Selector v2
truyền task purpose/required_rounds=1/completed_rounds và ghi stop_reason enum;
prompt zer19-registry-selector/2, receipt nemesis-functional/2. STOP vẫn hợp lệ,
không tự retry/ép template hay nâng thành success. Lý do STOP cũ vẫn UNKNOWN;
lý do mới chỉ là tự báo của model. Cleanup giữ fact ba trạng thái và chỉ dọn
topic sau resource_guard PASS, kể cả namespace/shared snapshot lỗi.

## Blocker runtime-03 và biện pháp thử khắc phục

runtime-03 đã tiêu quyền, NOT_MET trước model/HTTP/SQLi: exec TCP-isolation SourceB
timeout15s. Cleanup CLEAN; giữ nguyên toàn bộ raw/source/authorization cũ. Đây là
attempt mới runtime-07, không replay/resume03. Evidence nối đúng UID/container cho
thấy CPU tăng1.272s và throttling kéo dài ở50m. Nguồn CPU spike vẫn UNKNOWN;
negative-runtime/CPU-debt là suy luận, không phải kernel trace đã xác nhận.
285 benign exec tại50m không tái hiện;15 benign exec500m hoàn tất0.30–0.39s.
500m là mitigation chờ kiểm chứng, không bảo đảm sửa được sự cố hiếm.

Trước TCP isolation, HTTP hoặc model: một warm-up exec print('warm') cho mỗi
source, tổng đúng2 exec không socket. Đọc cgroup trước/sau mỗi warm-up, tổng4
normal node reads: mỗi read gồm1 GET Pod lấyUID/containerID và1 docker exec
desktop-linux vào agent-0, chỉ cat cpu.max/cpu.stat của container đó. Không node
write, không privileged helper/container, không sửa CPU của node/shared workloads.
UID/CID phải đúng định dạng; cgroup không đọc được thì dừng. Gate cần output warm,
CPU delta≤300000usec và wall≤5s cho cả hai nguồn; lỗi/timeout/thừa ngưỡng dừng
trước TCP/HTTP/model, không chuyển missing thànhPASS. Mỗi warm-up vẫn có trần
command15s; ngưỡng5s được kiểm sau khi command trả về. Normal cgroup command≤6s.

Snapshot khi source exec COMMAND_TIMEOUT: tối đa1 native snapshot attempt trong
toàn work process, reserve trước read, lỗi cũng tiêu budget; không retry snapshot.
Snapshot gồm1 GET Pod và1 read-only docker exec trên node, đọc cpu.max và2 cpu.stat
cách nhau2s; node command≤8s, GET/command≤15s, mọi bước cùng global work deadline.
Snapshot không đổi timeout gốc, không tạo HTTP/TCP/model/SQLi; các timeout sau
không thêm native CPU reads. Gate và snapshot bổ sung tối đa5 node exec reads cùng
5 GET Pod ngoài các admission/guard GET có sẵn. Không lấy host kernel log hay
thêm stress-repro trong lượt này. Không tăng15s exec timeout hoặc bỏ isolation.

Client hiện tại1.33.5/server1.31.5 và k3d uncordon loop được ghi residual; chưa có
bằng chứng nối chúng với timeout, không cài/upgrade/sửa cluster trong gói này.

## Sửa transport dependency sau runtime-04

runtime-04 đã tiêu quyền, cleanupCLEAN; CPUgate và2TCPisolationPASS. Nemesis v2
chọn template, nhưng transport import session_cli lỗi ModuleNotFoundError:kafka,
trước đọc/sign/gửicommand.0SQLi,0Gaia/Healer. Không sửa/replay04.
Lỗi cấu hình: PYTHONPATH=/current đã ghi đè dependency directory của image.
Chỉ khôi phục /current:/usr/local/lib/python3.11/site-packages như referenceZER19;
không build/pull/import/cài dependency hoặc thay image/cache pin.

Thêm đúng1 dependency-check exec vào zer21-transport sau CPUgate, trước2TCP,
HTTP hoặc model. Python runpy.run_path('/current/remote.py',
run_name='zer21_dependency_check') nhập chính entrypoint nhưng không gọi main:
không đọc key/sign/ledger claim, không tạo Kafka client hoặc network/model call.
Marker transport-ready và exit0 mới PASS; lỗi/missing/timeout dừng NOT_MET và
cleanup. Command≤15s, trong global work900s; không retry check. Nếu timeout thì
dùng chung max1 CPU snapshot budget đã mô tả, không tăng max5cgroupreads.
Đây là1exec bổ sung, không cộng HTTP/TCP hoặc modelcalls. Lưu
transport-dependency-gate.json. Nội dung dependency của cached image chưa được
kiểm lại bằng live import sau sửa; gate mới sẽ làm điều đó trước chi phí model.

## Sửa Kafka selector sau runtime-05

runtime-05 đã tiêu quyền, cleanupCLEAN. CPU/import/isolationPASS; model chọn
template nhưng KafkaExecutor báo RESULT_TOPIC_UNAVAILABLE trước producer/send.
Cả2topic tạoOK; snapshot xác nhận zer21-kafka-egress chọn app=zer46-source-a
trong khi actual SourceA/B có app=zer46-source, nên policy chọn0pod. Không có
packettrace để khẳng định đây là nguyên nhân duy nhất; không tăng timeout.

Thay đúng2 chỗ trong renderer mới: thêm label zero-door.io/kafka-client=<owner>
chỉ trên SourceA; Kafka policy đòi cả zero-door.io/run=<owner> và label này.
Chọn đúng1podA;B/foreignowner không được chọn. Giữ labelapp chung để các policy
DNS/privateproxy có sẵn tiếp tục khớp; đíchKafka namespacezero-door/podlabel
app.kubernetes.io/name=kafka/TCP9092 giữ nguyên. Không policyshared/cluster-wide,
không port/target mới, không mở egress choB, khôngKafka diagnostic/publish thêm.
Không thaymodel/registry/payload/guard/deadline/traffic/actionbudget. Không replay05.

## Precision fix sau runtime-06 và mitigation PSI cho runtime07

runtime-06 đã tiêu quyền,CLEAN245.110s;Kafka/worker/native1SQLi có proof.
Cycle NOT_MET trướcGaia/Healer. Có2blocker:memoryPSI7.06>5 vàtimestampjoin
raw.871327Z so vớiGoobservedAt.871Z bịtruncmilli. Purefunctionrepro trênactualdata
reject;không sửa hoặc chấp nhận lại receipt cũ,không gọi memorylàsole/firstcause.

Chỉ sửa so sánh end nếu observedAt đúngcanonicalGo .dddZ: nó đại diện khoảng
[observed,observed+1ms),raw phải nằm trong khoảng upperexclusive vàsau started.
Giữ nguyên rawts,ID/UID/source/count/window/60sage guards;timestampkhác không
được cộnggeneric tolerance. Không bù clockskew,không đổiGoimage hoặc guard.
Memorythreshold giữ nguyên5. Điều tra readonly xác nhận VM pressure thật, khôngOOM,
MemAvailable khoảng2.2GiB; không có sampled memory limit failures/oom trong window.
Nguồn chính xác của stall vẫn UNKNOWN: thiếu per-task/compaction trace lịch sử.
Current cumulative counters không chứng minh nguyên nhân incident. Không gọi
THP/WSL reclaim/Kafka là root cause đã xác nhận.

Bug cấu hình xác nhận: admin JVM kế thừa KAFKA_HEAP_OPTS=-Xmx384m -Xms384m
của broker, launcher chỉ dùng default khi biến rỗng. Giới hạn riêng env child CLI
kafka-topics.sh và kafka-consumer-groups.sh thành -Xms16m -Xmx128m cho tất cả
create/list/delete/describe đã có; không đổi broker env/spec/heap hoặc workload shared.
Không tăng command timeout, không retry khi CLI lỗi/OOM, không thêm admin invocation.
Đây là giảm chi phí khởi tạo có căn cứ, chưa chứng minh loại bỏ spike06.

Sau CPU/import gate, trướcTCP/HTTP/model: fixed30s memory settle window,7 reads
cách5s bằng resources() có sẵn; mỗi sample cần PSIavg10<=1, giữ host>=1GiB và
WSL>=1GiB, guardPSI>5 hiện hành. Lỗi/missing hoặc>1 thì FAIL ngay/cleanup,
không chờ tới khi pass/khôngretry. Watcher5s vẫn chạy; mọi thời gian trong900s.
Không refresh baselineHTTP vì gate đứng trướcbaseline. Lưu memory-settle-gate.json.

Thêm /proc/vmstat vào cùng docker exec cat memory guard hiện có (4s), không thêm
exec/client. Raw chứa allocstall/pgscan/compact/thp/oom counters để nối thời gian
nếu pressure tái diễn. Không kernel/sysctl/THP/WSL changes, drop caches hoặc giảm
shared workloads. Max5 CPU cgroup reads giữ nguyên;7memory reads bổ sung chỉ đọc
proc trên server, không phải CPU cgroup gate. Source-only tests kiểm capCLI,
ordering/fixedwindow/failclosed/sameexec telemetry trước execution.

## Admission và key

Default/import PLAN_ONLY. --execute --authorization cần approved=true, đúng
ZER-21/runtime-07, proposal SHA và source-manifest SHA, expiry còn hạn ≤24h.
Template approved=false; ghi authorization mới từ quyền runtime07 hiện hành sau khi khóa SHA/review, không cần xin lại cùng quyền.
Chỉ lấy OPENAI_API_KEY qua Doppler zero-door/dev, --only-secrets OPENAI_API_KEY
và --no-fallback, theo đúng đường đã xác minh trước đây; không ghi key
vào file, stdout, Pod, command arguments hoặc receipt. Cleanup không nhận key.

Một attempt, exclusive runtime-07 directory + work-claimed marker, IDs/topics mới.
Không replay/resume/retry work sau lỗi/timeout/refusal/STOP. Child chờ stdin GO
sau khi vào Windows Job kill-on-close; POSIX process group. Parent đóng/reap
work tree trước cleanup process mới. Mọi failure/UNKNOWN giữ nguyên.

## Target, tác động và thời lượng

Chỉ Docker desktop-linux, kube k3d-zero-door, static local API
https://127.0.0.1:7356; không dynamic exec auth/DOCKER_HOST/proxy API.
Giữ hai node, 9 Boutique deployment một replica healthy, zero-door deployment0,
3PVC Bound, resource/restart/spec guards ZER-50. Preflight25 mẫu/5s.
Cached images phải đúng host/node IDs; 0 build/pull/import/shared workload change.

Tạo riêng namespace zd-sqli-lab khi absent, fresh owner zer46-<12hex>, owner+UID
guard. Bốn private workloads tái sử dụng fixture/proxy deployment và2 sourcePod
trên agent-0. SourceA có Go/Python sidecars chung IP: Go250m/192Mi, Python150m/128Mi,
requests tổng75m/64Mi. Chỉ limits.cpu của container source trên SourceA/B đổi từ50m lên500m;
requests giữ5m/16Mi, memory limit48Mi. Các container fixture/proxy/sidecar khác giữ nguyên. SourceA token chỉ phục vụ
Go in-cluster constructor, không thêm RBAC grant. Hai Secret fault/operator mới,
không lưu nội dung. Private endpoint duy nhất:
http://zer41-private-ingress.zd-sqli-lab.svc.cluster.local:8000/fixture/catalog/search
Không public route/Internet egress; SourceA chỉ thêm KafkaTCP9092 trong zero-door,
giữ DNS/private proxy policy có sẵn.

Tạo đúng2 topic zer19-<freshRun12>.commands/results, partition1/replica1/retention1h;
pin brokerPodUID. UNKNOWN trước create, chỉ create return0 thành OWNED; không xóa
UNKNOWN/foreign. Fresh group owner.worker, không thay broker/shared consumer.

Nemesis tối đa1 round, allowed_templates chỉ disclose-restricted hoặc STOP.
Giữ registry/payload hiện có, duration1s/concurrency1/RPS1/maxSends1/maxCommandSec1.
Tổng tối đa8 HTTP reserved/dispatched (1benign baseline +1worker +6verification),
2TCP isolation, 1ConfigMap replace attempt với UID/RV guard. TTL180s, probe120s.
Không thêm HTTP diagnostic/retry. Tối đa3 model calls, attempts1/call,
timeout20s/deadline25s/output256; tổng30000 reserved tokens, estimatedUSD0.015
(estimate không là cam kết hóa đơn tuyệt đối). Missing usage/429/timeout/refusal/
STOP giữ NOT_MET, không thử thêm để đạt AC.

Work tối đa900s (internal880s) + cleanup300s (child285s/native265s).
Kafka operation10s, sau delete tối đa3 read polls/1s, cùng global cleanup deadline.
Không có quyền sửa shared workloads, PVC, HPA, Ingress, build/cache, cloud hay
cài dependency để vượt preflight. Guard fail thì dừng và cleanup đúng gói.

## Evidence, provenance và cleanup

Cached worker zer42-worker:e80bc554b7ef giữ build receipt ZER-42/runtime-01,
manifest-list host250be486…/node config b2c14377… và cache-pins ZER-19.
Receipt lịch sử pin3 fileGo, không attestation toàn bộ Go build context;
manifest mới pin toàn bộ Go source hiện tại để chống drift, không hồi tố build proof.
Python image chỉ transport/dependencies, signed executor/guard mount source mới.

Reader bắt buộc join đúng command/result/send/responseId/requestId và native
fixture access, fresh fixture/sourceUID, source/proxyIP, timezone/timestamp,
delivered200/row/restricted counts. Thiếu/trùng/lệch dừng trước Gaia/Healer.
Command schema giữ context3 trường, root trace/context6 trường. Cross-host clock
sync UNKNOWN; archive LOCAL_ONLY_NOT_AUTHENTICATED; không tính KPI.

API_ACCEPTED, ACTION_COMPLETED, containment probe và business recovery là các
fact riêng. Raw lỗi/cancellation/action-may-remain phải đối soát; không đoán
remote cancellation. Runtime output chỉ pending native reconciliation/review,
không tự issue_done/recovery_verified/benchmark_eligible.

Sau work tree closed: namespace owner+UID precondition delete, xác minh absent;
resource_guard phải PASS trước topic effects; chỉ xóa đúng2 OWNED topic khi
brokerUID khớp trong cleanup deadline. Kiểm shared specs/UID/restarts/resources.
Cleanup error/unchecked giữ INCOMPLETE, không replay work. Namespace deletion
bao gồm private workloads/rules/orders/Secrets/ledgers; không xóa sharedPVC.

Gói này chưa chứng minh AC01; cần raw reconciliation độc lập sau execution và
Hoàng acceptance. AC02/child51 chưa chạy. Không Boutique recovery/KPI/G3/G4,
không claim AI tốt hơn, không Git publication/Linear mutation hoặc thông báo.
