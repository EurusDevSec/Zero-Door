import unittest
from copy import deepcopy
from baseline_patch import build_patch,UID
class Patch(unittest.TestCase):
 def doc(self):return {"metadata":{"name":"cartservice","namespace":"target-app","uid":UID,"resourceVersion":"7"},"spec":{"replicas":1,"template":{"spec":{"containers":[{"name":"server","livenessProbe":{"timeoutSeconds":1},"readinessProbe":{"timeoutSeconds":1},"resources":{"limits":{"cpu":"200m","memory":"256Mi"}}}]}}}}
 def test_exact_two_replaces_with_cas_and_input_unchanged(self):
  doc=self.doc();before=deepcopy(doc);ops=build_patch(doc)
  self.assertEqual(before,doc);self.assertEqual(7,len(ops));self.assertEqual("7",ops[1]["value"])
  self.assertEqual(["/spec/template/spec/containers/0/livenessProbe/timeoutSeconds","/spec/template/spec/containers/0/readinessProbe/timeoutSeconds"],[o["path"] for o in ops if o["op"]=="replace"])
  self.assertEqual([3,3],[o["value"] for o in ops if o["op"]=="replace"])
 def test_foreign_or_changed_profile_rejected(self):
  for key,val in (("uid","foreign"),("namespace","foreign"),("resourceVersion","")):
   doc=self.doc();doc["metadata"][key]=val
   with self.subTest(key=key),self.assertRaises(ValueError):build_patch(doc)
  doc=self.doc();doc["spec"]["template"]["spec"]["containers"][0]["livenessProbe"]["timeoutSeconds"]=3
  with self.assertRaises(ValueError):build_patch(doc)
if __name__=="__main__":unittest.main(verbosity=2)
