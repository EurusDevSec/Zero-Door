"""Deterministic watcher lifecycle races, fake all resource/native ports."""
import sys,time,threading,unittest,socket,subprocess
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run,lab
class Watch(unittest.TestCase):
 def setUp(self):
  for obj,name in ((socket.socket,"connect"),(subprocess,"run"),(subprocess,"Popen")):
   p=patch.object(obj,name,side_effect=AssertionError("OFFLINE_ONLY"));p.start();self.addCleanup(p.stop)
 def make(self):
  with patch.object(run,"INDEX",2),patch("platform.system",return_value="Windows"):
   native=lab.make_lab()
  native.before={"items":[]};return native
 def start(self,native,resources):
  clock=iter(range(100,10000,10));self.clock=patch.object(lab.time,"monotonic",side_effect=lambda:next(clock));self.clock.start();self.addCleanup(self.clock.stop)
  self.resource=patch.object(native,"resources",side_effect=resources);self.resource.start();self.addCleanup(self.resource.stop)
  self.snap=patch.object(native,"snapshot",return_value={"items":[]});self.snap.start();self.addCleanup(self.snap.stop)
  self.priv=patch.object(native,"private_restarts");self.priv.start();self.addCleanup(self.priv.stop)
  self.capture=patch.object(native,"capture_guard_stop");self.capture.start();self.addCleanup(self.capture.stop)
  native.thread=threading.Thread(target=native.watch);native.thread.start()
 def test_old_stop_first_reproduces_false_guard_failure(self):
  native=self.make();entered=threading.Event();release=threading.Event()
  def resources():
   entered.set();assert release.wait(2);native.check()
  self.start(native,resources);self.assertTrue(entered.wait(2))
  native.stop.set();release.set();native.thread.join(2)
  self.assertEqual(["GUARD_OR_CLEANUP_RESERVE:[]"],native.failure)
 def test_normal_shutdown_drains_without_setting_guard_stop_early(self):
  native=self.make();entered=threading.Event()
  def resources():
   entered.set();assert native.watch_shutdown.wait(2)
   self.assertFalse(native.stop.is_set());native.check()
  self.start(native,resources);self.assertTrue(entered.wait(2))
  native.finish_watch();self.assertFalse(native.thread.is_alive());self.assertEqual([],native.failure);self.assertTrue(native.stop.is_set())
 def test_real_memory_failure_still_fails_during_normal_shutdown(self):
  native=self.make();entered=threading.Event()
  def resources():
   entered.set();assert native.watch_shutdown.wait(2);raise RuntimeError("MEMORY_STOP")
  self.start(native,resources);self.assertTrue(entered.wait(2));native.finish_watch()
  self.assertEqual(["MEMORY_STOP"],native.failure);self.assertTrue(native.stop.is_set())
 def test_stuck_watcher_is_not_success(self):
  native=self.make()
  class Stuck:
   def join(self,timeout):self.timeout=timeout
   def is_alive(self):return True
  native.thread=Stuck();native.finish_watch()
  self.assertEqual(20,native.thread.timeout);self.assertEqual(["WATCHER_SHUTDOWN_TIMEOUT"],native.failure)
if __name__=="__main__":unittest.main(verbosity=2)
