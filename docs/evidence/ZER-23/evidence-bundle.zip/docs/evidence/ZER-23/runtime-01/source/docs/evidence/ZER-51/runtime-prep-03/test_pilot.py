"""Pilot uses actual mode/guard/backend/state with fake ports and denied sockets."""
import asyncio
from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import run
sys.path.insert(0,str(run.ROOT/'agent-orchestrator'))
sys.path.insert(0,str(run.ROOT/'tests'))
import pilot
from event_pipeline.contract import Producer,new_id,validate
from event_pipeline.llm import RunBudget
from hephaestus.command_guard import ModeGate
from hephaestus.recovery import Healer,Journal
from nemesis.command_guard import CommandGuard,Refused
from test_hephaestus_recovery import API
from test_sqli_action_state import PINS,POD,probes


class Pure(unittest.TestCase):
    def test_schedule_is_exactly_six_unique_paired_cells(self):
        self.assertEqual({(g,c) for g in ('B0','B1','B2') for c in ('C0','SQLI')},set(pilot.SCHEDULE))
        self.assertEqual(6,len(pilot.SCHEDULE));self.assertEqual(2,sum(g=='B2' for g,c in pilot.SCHEDULE))
        self.assertEqual(3,sum(c=='SQLI' for g,c in pilot.SCHEDULE))
        self.assertEqual({'benign-electronics','disclose-restricted'},{pilot.template(c) for g,c in pilot.SCHEDULE})
        with self.assertRaises(KeyError):pilot.template('unknown')

    def test_b0_b1_and_every_cleanup_receive_no_provider_key(self):
        for index,(group,_) in enumerate(pilot.SCHEDULE):
            for cleanup in (False,True):
                env=run.child_env(index,{'OPENAI_API_KEY':'offline-marker'},cleanup=cleanup)
                self.assertEqual(group=='B2' and not cleanup,'OPENAI_API_KEY' in env)
                self.assertEqual(str(index),env['ZD51_INDEX'])
        self.assertIs(pilot.RulesController.observation,Healer.observation)
        self.assertIs(pilot.RulesController.action_guard,Healer.action_guard)

    def test_failures_stay_in_correctness_denominator_and_guard_does_not_fix_answer(self):
        row=pilot.score('B2','SQLI',{'status':'SCHEMA_INVALID','plan':None},None)
        self.assertFalse(row['first_action_correct']);self.assertEqual('NOT_CONTAINED',row['recovery'])
        row=pilot.score('B2','C0',{'status':'GUARD_REJECTED','plan':{'action':'BLOCK_IP'}},None)
        self.assertTrue(row['false_action']);self.assertFalse(row['first_action_correct']);self.assertTrue(row['guard_rejected'])
        self.assertFalse(pilot.score('B2','C0',{'plan':{'action':'ABSTAIN'}},None)['first_action_correct'])
        self.assertIsNone(pilot.score('B0','SQLI',{'plan':None},None)['first_action_correct'])

    def test_b0_never_uses_healer_journal_or_mode_dispatch(self):
        ctx={'run_id':new_id('run'),'trial_id':new_id('trl'),'group':'B0','method_version':pilot.VERSION,
             'config_ref':'sha256:'+'1'*64,'incident_id':new_id('inc')}
        with tempfile.TemporaryDirectory() as d:
            j=pilot.BaselineJournal(d,ctx);j({'kind':'BASELINE_OBSERVATION','automatic_heal':False});j.close()
            self.assertIn('BASELINE_OBSERVATION',(j.directory/'events.jsonl').read_text())
        with self.assertRaisesRegex(Refused,'MODE_B0'):
            ModeGate.dispatch({k:ctx[k] for k in ('run_id','trial_id','group')},{},'decision_rules','AUTO',executor=lambda p:self.fail('B0 effect'))

    def test_explicit_common_evidence_compares_facts_and_keeps_raw_identities(self):
        obs={'detection':{'payload':dict(rule_id='SUSPICIOUS_LOG',rule_version='1',signature='SQLI/fixture',metric='log_pattern_match',value=1,threshold=0,severity='WARNING',description='native access')},
            'access':dict(method='GET',path='/fixture/catalog/search',status=200,rows=3,restricted_rows=3,delivered=True,source_method='XFF_AFTER_TRUSTED',source_confidence='PROXY_CHAIN',request_id='a'*32,ts=1,client_ip='10.42.0.11')}
        other=deepcopy(obs);other['access'].update(request_id='b'*32,ts=2,client_ip='10.42.0.99')
        self.assertEqual(pilot.evidence_hash(obs),pilot.evidence_hash(other));self.assertNotEqual(obs,other)
        self.assertEqual('a'*32,obs['access']['request_id'])
        other['access']['restricted_rows']=2
        self.assertNotEqual(pilot.evidence_hash(obs),pilot.evidence_hash(other))

    def test_fixed_worker_plan_and_renderer_do_not_depend_on_model_answers(self):
        import render
        shapes={}
        for group,case in pilot.SCHEDULE:
            ctx={'run_id':new_id('run'),'trial_id':new_id('trl'),'group':group}
            _,containers,_,policy=render.worker_documents(ctx,'zer46-123456abcdef','10.43.0.11')
            command=CommandGuard(policy).sqli_command({'attackType':'SQLI','template':pilot.template(case),'durationSec':1},'55555555-5555-4555-8555-555555555555')
            self.assertEqual(ctx,command['context']);self.assertEqual(1,policy['sqli']['maxSends'])
            shape={k:command[k] for k in ('attackType','target','parameters','safetyLimits')}
            if case in shapes:self.assertEqual(shapes[case],shape)
            shapes[case]=shape
            self.assertTrue(all(c['imagePullPolicy']=='Never' for c in containers))
            self.assertNotIn('OPENAI_API_KEY',json.dumps(containers))


class Rules(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'));self.net.start();self.addCleanup(self.net.stop)
        self.native=patch.object(subprocess,'Popen',side_effect=AssertionError('NO_NATIVE_OPERATION'));self.native.start();self.addCleanup(self.native.stop)
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.pins=dict(PINS,run_id=new_id('run'),trial_id=new_id('trl'))
        self.ctx={k:self.pins[k] for k in ('run_id','trial_id')};self.ctx.update(group='B1',method_version=pilot.VERSION,config_ref='sha256:'+'1'*64,incident_id=new_id('inc'))
        self.detected=Producer('detector','test',pilot.CLOCK).event(self.ctx,'DETECTED',dict(rule_id='SUSPICIOUS_LOG',rule_version='1',signature='SQLI/fixture',metric='log_pattern_match',value=1,threshold=0,severity='WARNING',description='Native access'),'o.alert',target={'namespace':'zd-sqli-lab','service':'sqli-fixture','flow':None},alert_id=new_id('alt'))
        self.access=dict(ref='native/join',request_id='4'*32,ts=1000,client_ip=PINS['attacker_ip'],tcp_peer='10.42.0.12',source_method='XFF_AFTER_TRUSTED',source_confidence='PROXY_CHAIN',method='GET',path='/fixture/catalog/search',status=200,rows=3,restricted_rows=1,delivered=True,run_id=self.ctx['run_id'],trial_id=self.ctx['trial_id'],fixture_uid=POD,detection_event_id=self.detected['event_id'])
        self.wall=1001;self.api=API(self.pins);self.probe_calls=0
        self.journal=Journal(self.tmp.name,self.ctx);self.addCleanup(self.journal.close)
        self.budget=RunBudget(self.ctx['run_id'],max_calls=2,max_reserved_tokens=15000,max_estimated_usd=.01,duration_s=300)
        self.controller=pilot.RulesController(self.ctx,api=self.api,pins=self.pins,fixture_uid=POD,journal=self.journal,probe=self.probe,budget=self.budget,wall_clock=lambda:self.wall)

    async def probe(self,result):
        self.probe_calls+=1;rows=probes();rows[0]['access']['action_ids']=[result['rule']['action_id']];self.wall=1010
        return {'attacker':rows[0],'benign':rows[1:],'fixture':{'uid':POD,'ready':True}}

    async def test_rules_positive_runs_same_guard_backend_and_postcondition_without_model(self):
        receipt=await self.controller.run(self.detected,self.access)
        self.assertEqual('ACTION_COMPLETED',receipt['status']);self.assertEqual('RULES',receipt['decision_source'])
        self.assertFalse(receipt['fallback']);self.assertEqual([],receipt['model_events']);self.assertEqual(0,self.budget.summary()['attempts_dispatched'])
        self.assertEqual(1,self.api.writes);self.assertEqual(1,self.probe_calls);self.assertFalse(validate(receipt['decision']))
        self.assertIsNone(receipt['decision']['payload']['prompt_version']);self.assertEqual('decision_rules',receipt['decision']['source_component'])
        with self.assertRaisesRegex(ValueError,'RULES_ALREADY_STARTED'):await self.controller.run(self.detected,self.access)

    async def test_benign_rule_does_not_read_or_write_api_or_probe(self):
        self.access.update(rows=1,restricted_rows=0);self.detected['payload']['value']=0
        r=await self.controller.run(self.detected,self.access)
        self.assertEqual('NO_ACTION',r['status']);self.assertEqual(0,self.api.reads);self.assertEqual(0,self.api.writes);self.assertEqual(0,self.probe_calls)

    async def test_stale_foreign_uid_or_untrusted_source_fails_before_effect(self):
        for key,value in [('ts',900),('fixture_uid','foreign'),('source_confidence','UNKNOWN'),('tcp_peer','10.42.0.99')]:
            old=deepcopy(self.access);self.access[key]=value
            # observation validation itself is shared with actual Healer, no alternate B1 guard.
            with self.subTest(key=key),self.assertRaises(ValueError):self.controller.observation(self.detected,self.access)
            self.access=old
        self.assertEqual(0,self.api.writes)

    async def test_wrong_detection_rule_is_not_an_accepted_block(self):
        self.detected['payload']['rule_id']='OTHER_RULE'
        r=await self.controller.run(self.detected,self.access)
        self.assertEqual('GUARD_REJECTED',r['status']);self.assertEqual('BLOCK_IP',r['plan']['action'])
        self.assertEqual(0,self.api.writes);self.assertEqual(0,self.probe_calls)

    async def test_api_timeout_remains_unknown_and_never_redispatches(self):
        self.api.timeout=True;r=await self.controller.run(self.detected,self.access)
        self.assertEqual('ACTION_OUTCOME_UNKNOWN',r['status']);self.assertEqual(1,self.api.writes);self.assertEqual(0,self.probe_calls)

    async def test_rules_cannot_impersonate_b2_or_b0(self):
        for group in ('B0','B2'):
            with self.subTest(group=group),self.assertRaisesRegex(ValueError,'RULES_CONTEXT'):
                pilot.RulesController(dict(self.ctx,group=group),api=self.api,pins=self.pins,fixture_uid=POD,journal=self.journal,probe=self.probe,budget=self.budget)


class Admission(unittest.TestCase):
    def test_wrong_or_expired_or_unapproved_packets_cannot_start(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'auth.json'
            valid=dict(issue='ZER-51',attempt='pilot-03',approved=True,expires_epoch=time.time()+60,
                proposal_sha256='proposal',source_manifest_sha256='manifest')
            for field,value in [('issue','ZER-21'),('attempt','pilot-01'),('approved',False),('expires_epoch',0),('proposal_sha256','wrong'),('source_manifest_sha256','wrong')]:
                p.write_text(json.dumps(dict(valid,**{field:value})))
                with patch.object(run,'sha',side_effect=lambda x:'proposal' if x.name=='proposal.md' else 'manifest'),patch.object(run,'verify_sources'),self.subTest(field=field):
                    with self.assertRaisesRegex(ValueError,'FRESH_PILOT_APPROVAL_REQUIRED'):run.admit(p)

    def test_batch_attempt_is_exclusive_and_failed_cleanup_stops_later_cells(self):
        with tempfile.TemporaryDirectory() as d:
            batch=Path(d)/'runtime';auth=Path(d)/'auth.json';auth.write_text('{}');calls=[]
            def child(command,env,log,timeout):
                calls.append((command[-1],env['ZD51_INDEX']));out=log.parent
                if command[-1]=='--work':run.save(out/'work-result.json',{'status':'OBSERVED_PENDING_REVIEW','provider_calls':0})
                else:run.save(out/'cleanup.json',{'verdict':'INCOMPLETE'})
                return {'exit_code':0,'timed_out':False,'process_reaped':True,'owned_tree_closed':True}
            proposal=Path(d)/'prep';proposal.mkdir();(proposal/'proposal.md').write_text('proposal')
            with patch.object(run,'BATCH',batch),patch.object(run,'PREP',proposal),patch.object(run,'INDEX',None),patch.object(run,'admit',return_value={}),patch.object(run,'verify_sources',return_value={'sha256':{}}),patch.object(run,'run_child',side_effect=child):
                self.assertEqual(1,run.execute(auth));self.assertEqual([('--work','2'),('--cleanup','2')],calls)
                with self.assertRaises(FileExistsError):run.execute(auth)
                self.assertEqual(1,len(json.loads((batch/'acceptance.json').read_text())['rows']))



class NativeSeams(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.platform=patch("platform.system",return_value="Windows");self.platform.start();self.addCleanup(self.platform.stop)
        self.net=patch.object(socket.socket,'connect',side_effect=AssertionError('OFFLINE_ONLY'));self.net.start();self.addCleanup(self.net.stop)
        self.proc=patch.object(subprocess,'run',side_effect=AssertionError('NO_NATIVE_OPERATION'));self.proc.start();self.addCleanup(self.proc.stop)

    async def test_actual_b0_execute_reaches_watcher_with_fake_ports(self):
        import lab
        with patch.object(run,'INDEX',0):native=lab.make_lab()
        items=[]
        for name in ('cartservice','checkoutservice','currencyservice','emailservice','frontend','paymentservice','productcatalogservice','redis-cart','shippingservice'):
            items.append({'kind':'Deployment','metadata':{'namespace':'target-app','name':name,'uid':name},'spec':{'replicas':1},'status':{'availableReplicas':1}})
        for i in range(3):items.append({'kind':'PersistentVolumeClaim','metadata':{'namespace':'monitoring','name':str(i),'uid':str(i)},'spec':{},'status':{'phase':'Bound'}})
        next(x for x in items if x['kind']=='Deployment' and x['metadata']['name']=='cartservice')['spec']['template']={'spec':{'containers':[{'name':'server','livenessProbe':{'timeoutSeconds':3},'readinessProbe':{'timeoutSeconds':3}}]}}
        snapshot={'items':items};count=[]
        def command(args,**kw):
            return subprocess.CompletedProcess(args,0,(run.HEAD if args[0]=='git' else 'desktop-linux').encode())
        def kube(*args,**kw):
            if args[:2]==('get','nodes'):
                value={'items':[{'metadata':{'name':n},'status':{'conditions':[{'type':'Ready','status':'True'}]}} for n in ('k3d-zero-door-server-0','k3d-zero-door-agent-0')]}
                return subprocess.CompletedProcess([],0,json.dumps(value).encode())
            if args[:2]==('get','namespace'):return subprocess.CompletedProcess([],0,b'')
            raise AssertionError(args)
        with patch.object(run,'verify_sources'),patch.object(lab,'kube_config_pin'),patch.object(native,'command',side_effect=command),patch.object(native,'kube',side_effect=kube),patch.object(native,'snapshot',return_value=snapshot),patch.object(native,'wait'),patch.object(native,'resources',side_effect=lambda:count.append(1)),patch.object(native,'ensure_cache'),patch.object(native,'save'),patch.object(native,'watch') as watch,patch.dict(os.environ,{},clear=True):
            native.execute();native.thread.join(timeout=1)
            self.assertEqual(25,len(count));watch.assert_called_once()

    async def test_actual_b0_cases_has_no_api_model_or_decision_producer(self):
        import lab
        with patch.object(run,'INDEX',0):native=lab.make_lab()
        native.fixture_http=1;native.fixture_uid=POD;native.addresses={'a':'10.42.0.11','b':'10.42.0.13','proxy':'10.42.0.12'}
        native.before={'items':[]};native.tcp_checks=2
        import render
        _,_,_,policy=render.worker_documents(native.context,native.owner,'10.43.0.11');native.command_policy=policy
        detected=Producer('detector','test',pilot.CLOCK).event(native.context,'DETECTED',dict(rule_id='SUSPICIOUS_LOG',rule_version='1',signature='SQLI/fixture',metric='log_pattern_match',value=0,threshold=0,severity='WARNING',description='Native access'),'o.alert',target={'namespace':'zd-sqli-lab','service':'sqli-fixture','flow':None},alert_id=new_id('alt'))
        access=dict(method='GET',path='/fixture/catalog/search',status=200,rows=1,restricted_rows=0,delivered=True,source_method='XFF_AFTER_TRUSTED',source_confidence='PROXY_CHAIN')
        observed={'detection':detected,'access':access,'evidence':{}}
        saved={}
        async def execute(command):native.fixture_http=2;return {'status':'SUCCESS'}
        async def observe(r):return observed
        async def probe(result=None):
            native.fixture_http=8;native.last_probe={'attacker':{'http':{'response':{'status':200}},'access':{'blocked':False}},'benign':[{'http':{'response':{'status':x}}} for x in [200,201,200,200,404]]}
            return native.last_probe
        with tempfile.TemporaryDirectory() as d:
            out=Path(d);(out/'before-hpa.json').write_text('{}')
            with patch.object(lab,'OUT',out),patch.object(native,'execute_worker',side_effect=execute),patch.object(native,'observe_worker',side_effect=observe),patch.object(native,'cm',return_value={}),patch.object(native,'probe',side_effect=probe),patch.object(native,'native_api',side_effect=AssertionError('B0_NO_API')),patch.object(lab,'Adapter',side_effect=AssertionError('B0_NO_MODEL')),patch.object(native,'save',side_effect=lambda n,v:saved.__setitem__(n,v)),patch.dict(os.environ,{},clear=True):
                await native.cases()
            row=saved['pilot-cell.json'];self.assertEqual('BASELINE_NO_DECIDER',row['decision']['status'])
            self.assertEqual(0,row['api_replace_attempts']);self.assertEqual(0,row['model_budget']['attempts_dispatched'])
            self.assertTrue(row['metrics']['business_cycle_verified'])

    async def test_unverified_action_cannot_be_scored_verified_containment(self):
        proof={'attacker':{'http':{'response':{'status':403}},'access':{'blocked':True,'action_ids':['act_test']}},'benign':[]}
        partial={'status':'NOT_VERIFIED','plan':{'action':'BLOCK_IP'},'action_id':'act_test',
            'action_state':{'phase':'PARTIAL','action_id':'act_test','terminal':{'status':'PARTIAL','postcondition':{'name':'SQLI_SOURCE_CONTAINMENT','checked':True,'satisfied':False}}}}
        row=pilot.score('B2','SQLI',partial,proof)
        self.assertFalse(row['source_containment_verified']);self.assertEqual('NOT_CONTAINED',row['recovery'])
        partial.update(status='ACTION_COMPLETED');partial['action_state']['phase']='ACTION_COMPLETED'
        partial['action_state']['terminal'].update(status='SUCCESS',postcondition={'name':'SQLI_SOURCE_CONTAINMENT','checked':True,'satisfied':True})
        self.assertTrue(pilot.score('B2','SQLI',partial,proof)['source_containment_verified'])
        proof['attacker']['access']['action_ids']=['foreign']
        self.assertFalse(pilot.score('B2','SQLI',partial,proof)['source_containment_verified'])

if __name__=='__main__':unittest.main(verbosity=2)
