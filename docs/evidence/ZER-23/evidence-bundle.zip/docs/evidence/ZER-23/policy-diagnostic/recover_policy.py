import pathlib,subprocess,json,time,re,sys,os,importlib.util
from datetime import datetime
if sys.stdin.buffer.readline(4)!=b'GO\n':raise ValueError('OWNED_SUPERVISOR_GATE_REQUIRED')
root=pathlib.Path(r'C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door');out=root/'docs/evidence/ZER-23/policy-recovery';out.mkdir()
env=dict(os.environ);env.pop('OPENAI_API_KEY',None)
def save(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
def cmd(args,timeout=15):
 remaining=hard_deadline-time.monotonic()
 if remaining<=0:raise TimeoutError('RECOVERY_DEADLINE')
 p=subprocess.run(args,env=env,capture_output=True,timeout=min(timeout,remaining),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 save('%03d.json'%len(list(out.glob('*.json'))),{'args':args,'returncode':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
 if p.returncode:raise RuntimeError('RECOVERY_COMMAND_FAILED')
 return p.stdout
kube=lambda *a:cmd(['kubectl','--context','k3d-zero-door','--request-timeout=12s',*a])
def snapshot():return json.loads(kube('get','deploy,pod,pvc','-A','-o','json'))
start=time.monotonic();hard_deadline=start+300;result={'status':'NOT_MET','restart_attempts':0,'provider_calls':0,'fixture_http':0}
try:
 previous=json.loads((root/'docs/evidence/ZER-23/runtime-01/acceptance.json').read_bytes())
 assert previous['rows'][0]['cleanup']['verdict']=='CLEAN'
 assert all(previous['rows'][0][k]['owned_tree_closed'] and previous['rows'][0][k]['process_reaped'] for k in ('worker','cleanup_process'))
 assert not kube('get','namespace','zd-sqli-lab','--ignore-not-found','-o','name').strip()
 assert cmd(['docker','context','show']).decode().strip()=='desktop-linux'
 meta=json.loads(cmd(['docker','--context','desktop-linux','inspect','--format','{{json .Id}}','k3d-zero-door-agent-0']))
 assert re.fullmatch('[0-9a-f]{64}',meta)
 ip=cmd(['docker','--context','desktop-linux','inspect','--format','{{with index .NetworkSettings.Networks "k3d-zero-door"}}{{.IPAddress}}{{end}}',meta]).decode().strip()
 node=json.loads(kube('get','node','k3d-zero-door-agent-0','-o','json'))
 assert ip in [a['address'] for a in node['status']['addresses'] if a['type']=='InternalIP']
 before=snapshot();save('before.json',before)
 pvcs={x['metadata']['namespace']+'/'+x['metadata']['name']:x['metadata']['uid'] for x in before['items'] if x['kind']=='PersistentVolumeClaim'}
 specs={x['metadata']['namespace']+'/'+x['metadata']['name']:(x['metadata']['uid'],x['spec']) for x in before['items'] if x['kind']=='Deployment'}
 save('intent.json',{'container_id':meta,'node_uid':node['metadata']['uid'],'ip':ip,'at':time.time(),'restart_attempts':1})
 assert len(pvcs)==3 and all(x['spec']['replicas']==0 for x in before['items'] if x['kind']=='Deployment' and x['metadata']['namespace']=='zero-door')
 assert hard_deadline-time.monotonic()>=180,'INSUFFICIENT_RECOVERY_BUDGET'
 result['restart_attempts']=1;restart_wall=time.time()
 cmd(['docker','--context','desktop-linux','restart','--time','30',meta],timeout=45)
 deadline=start+300;ready=False
 while time.monotonic()<deadline:
  current=json.loads(kube('get','node','k3d-zero-door-agent-0','-o','json'))
  assert current['metadata']['uid']==node['metadata']['uid']
  assert ip in [a['address'] for a in current['status']['addresses'] if a['type']=='InternalIP']
  after=snapshot()
  target=[x for x in after['items'] if x['kind']=='Deployment' and x['metadata']['namespace']=='target-app']
  ready=(len(target)==9 and all(x['spec']['replicas']==1 and x.get('status',{}).get('availableReplicas')==1 for x in target)
    and time.time()-restart_wall>=15
    and any(c['type']=='Ready' and c['status']=='True' and datetime.fromisoformat(c['lastHeartbeatTime'].replace('Z','+00:00')).timestamp()>restart_wall for c in current['status']['conditions'])
    and all(x['status'].get('phase')=='Bound' for x in after['items'] if x['kind']=='PersistentVolumeClaim'))
  if ready:break
  time.sleep(min(5,max(0,hard_deadline-time.monotonic())))
 assert ready,'BASELINE_NOT_READY'
 assert pvcs=={x['metadata']['namespace']+'/'+x['metadata']['name']:x['metadata']['uid'] for x in after['items'] if x['kind']=='PersistentVolumeClaim'}
 assert specs=={x['metadata']['namespace']+'/'+x['metadata']['name']:(x['metadata']['uid'],x['spec']) for x in after['items'] if x['kind']=='Deployment'}
 assert len(pvcs)==3 and all(x['spec']['replicas']==0 for x in after['items'] if x['kind']=='Deployment' and x['metadata']['namespace']=='zero-door')
 save('after.json',after)
 raw=cmd(['docker','--context','desktop-linux','exec',meta,'iptables-save','-t','filter']).decode()
 (out/'after-filter.txt').write_text(raw,encoding='utf8')
 spec=importlib.util.spec_from_file_location('recover_hook',root/'docs/evidence/ZER-46/runtime-prep/run_agent_fixture.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 candidates=[p for p in after['items'] if p['kind']=='Pod' and p['spec'].get('nodeName')=='k3d-zero-door-agent-0' and not p['spec'].get('hostNetwork') and not p['metadata'].get('deletionTimestamp') and p['status'].get('phase')=='Running' and p['status'].get('podIP') and p['status'].get('hostIP')==ip]
 hooked=[p for p in candidates if module.hooked_policy(raw,p)]
 assert hooked,'NO_ACTUAL_POD_POLICY_HOOK'
 assert time.monotonic()<hard_deadline,'RECOVERY_DEADLINE'
 result.update(status='BASELINE_READY',container_id=meta,node_uid=node['metadata']['uid'],ip=ip,pod_fw_chains=sum(l.startswith(':KUBE-POD-FW-') for l in raw.splitlines()),hooked_pods=[p['metadata']['namespace']+'/'+p['metadata']['name'] for p in hooked],deployment_specs_preserved=True,pvc_uids_preserved=True,expected_restart_baseline_changed=True)
except BaseException as error:
 result.update(error=type(error).__name__+':'+str(error))
finally:
 result['elapsed_seconds']=time.monotonic()-start;save('result.json',result);print(json.dumps(result))
sys.exit(0 if result['status']=='BASELINE_READY' else 1)
