"""One owned baseline recovery process; no key/model/fixture test."""
import importlib.util,json,os,pathlib,sys
root=pathlib.Path(r'C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door')
spec=importlib.util.spec_from_file_location('recovery_owned',root/'docs/evidence/ZER-21/runtime-prep-07/run.py')
owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',MSYS_NO_PATHCONV='1',
 PYTHONPATH=os.pathsep.join((str(root/'agent-orchestrator'),str(pathlib.Path(sys.prefix)/'Lib/site-packages'))))
env.pop('OPENAI_API_KEY',None)
result=owned.run_child([sys.executable,'-B',str(root/'docs/evidence/ZER-23/policy-diagnostic/recover_policy.py')],
 env,root/'docs/evidence/ZER-23/policy-recovery-worker.log',timeout=300)
(root/'docs/evidence/ZER-23/policy-recovery-process.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result));raise SystemExit(result['exit_code'] or (1 if result['timed_out'] else 0))
