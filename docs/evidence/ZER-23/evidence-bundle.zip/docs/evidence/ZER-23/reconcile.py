"""Read-only raw reconciliation for the completed ZER-23 runtime02; no lab/provider I/O."""
import pathlib,json,hashlib,sys
ROOT=pathlib.Path(r'C:/Users/ACER/.codex/worktrees/zer-46-publication/zero_door')
BASE=ROOT/'docs/evidence/ZER-23';RUN=BASE/'runtime-02'
sys.path.insert(0,str(ROOT/'agent-orchestrator'))
from event_pipeline.contract import canonical
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,condition,detail=None):
 checks.append({'check':name,'passed':bool(condition),'detail':detail})
 if not condition:raise AssertionError(name)
summary={'issue':'ZER-23','status':'NOT_VERIFIED','checks':checks,'limits':{'model_calls':5,'estimated_usd':.03,'http':17,'tcp':6,'api_replace':1},'benchmark_eligible':False}
try:
 final=read(RUN/'acceptance.json')
 check('batch_failure_retained',final['status']=='NOT_MET' and [r['case'] for r in final['rows']]==['SQLI','C0','CANCEL'] and final['rows'][2]['status']=='NOT_MET')
 manifest=read(RUN/'source-manifest.json')['sha256']
 for name,digest in manifest.items():check('source_snapshot:'+name,sha(RUN/'source'/name)==digest)
 summary['source_pins']=len(manifest)
 total={'model_calls':0,'input_tokens':0,'output_tokens':0,'cost_estimate_usd':0.,'http':0,'tcp':0,'api_replace':0}
 fixture_uids=[];cases=[]
 for case in ('SQLI','C0'):
  d=RUN/case;row=read(d/'acceptance.json');work=row['work'];clean=row['cleanup']
  check(case+':whole_case',row['status']=='OBSERVED_PENDING_REVIEW' and work['status']=='OBSERVED_PENDING_REVIEW')
  check(case+':owned_tree_closed',all(row[k]['exit_code']==0 and row[k]['process_reaped'] and row[k]['owned_tree_closed'] and not row[k]['timed_out'] for k in ('worker','cleanup_process')))
  check(case+':cleanup',clean['verdict']=='CLEAN' and clean['resource_guard']=='PASS' and all(clean[k] is True for k in ('namespace_absent','shared_specs_preserved','shared_restarts_preserved')) and not clean.get('errors') and not clean.get('topic_cleanup_errors'))
  budget=read(d/'model-budget.json')
  check(case+':usage_complete',budget['cost_estimate_complete'] and not budget['unknown_usage_attempts'] and not budget['blocked'])
  total['model_calls']+=budget['attempts_dispatched'];total['input_tokens']+=budget['known_input_tokens'];total['output_tokens']+=budget['known_output_tokens'];total['cost_estimate_usd']+=budget['known_cost_estimate_usd']
  total['http']+=work['fixture_http'];total['tcp']+=work['tcp_checks']
  fixture=read(d/'fixture-initial.json');fixture_uids.append(fixture['metadata']['uid'])
  state=read(d/'state.json')
  for topic,ownership in clean['topic_state'].items():
   check(case+':topic_owned:'+topic,ownership=='OWNED')
   matches=[]
   for raw in sorted((d/'raw').glob('*.json')):
    obj=read(raw);args=obj.get('args',[])
    if '--list' in args and '--topic' in args and args[args.index('--topic')+1]=='^'+__import__('re').escape(topic)+'$':matches.append(obj)
   check(case+':topic_absent:'+topic,bool(matches) and matches[-1]['returncode']==0 and topic not in matches[-1]['stdout'].splitlines())
  check(case+':three_topics',len(clean['topic_state'])==3)
  result={'case':case,'provider_calls':budget['attempts_dispatched'],'http':work['fixture_http'],'tcp':work['tcp_checks'],'cleanup':'CLEAN','fixture_uid':fixture['metadata']['uid']}
  if case=='CANCEL':
   cancel=read(d/'cancel-receipt.json');check('cancel_before_model_and_worker',cancel['stop_reason'].startswith('CANCELLED') and budget['attempts_dispatched']==0 and work['fixture_http']==1 and not (d/'worker-result.json').exists() and not (d/'handoff-send-intent.json').exists())
   result['stop_reason']=cancel['stop_reason'];cases.append(result);continue
  observed=read(d/'gaia-native-observation.json');joined=read(d/'worker-native-join.json');access=observed['access'];context={k:observed['detection'][k] for k in ('run_id','trial_id','incident_id','group','method_version','config_ref')}
  check(case+':native_fixture_identity',access['fixture_uid']==fixture['metadata']['uid']==joined['pod_uid'] and access['request_id']==joined['raw_access']['request_id'])
  check(case+':native_counts_source',all(access[k]==joined['raw_access'][k] for k in ('rows','restricted_rows','client_ip','tcp_peer','request_id','ts','source_method','source_confidence')))
  if case=='SQLI':
   nemesis=read(d/'nemesis-receipt.json');check('nemesis_real_round',nemesis['completed_rounds']==1 and nemesis['stop_reason']=='MAX_ROUNDS' and nemesis['budget']['attempts_dispatched']==1)
   records=nemesis['records']
  else:records=read(d/'locked-benign-receipt.json')['records']
  commands=[r['command'] for r in records if r['event']=='DISPATCH_INTENT'];executions=[r['raw'] for r in records if r['event']=='EXECUTOR_RESULT']
  check(case+':single_worker_effect',len(commands)==len(executions)==1 and executions[0]['status']=='SUCCESS' and executions[0]['commandId']==commands[0]['commandId'])
  send=executions[0]['details']['sqli']['sends'];check(case+':worker_native_join',len(send)==1 and send[0]['responseId']==access['request_id'] and send[0]['requestId']==commands[0]['commandId']+'/1'==joined['raw_access']['correlation_id'] and send[0]['restrictedRows']==access['restricted_rows'])
  flow=read(d/'pipeline-receipt.json');healer=flow.get('healer');probe=read(d/'postcondition-probe.json')
  result.update(gaia=flow['diagnosis']['status'],healer=healer['status'] if healer else 'NOT_RUN',restricted_rows=access['restricted_rows'])
  if flow['status']=='COMPLETED':
   packet=read(d/'handoff-send-intent.json');native=read(d/'handoff-native-receipt.json');claim=read(d/'handoff-claim.json')
   check(case+':transport_exact_bytes',canonical(packet)==canonical(native['packet']) and flow['packet_sha256']==hashlib.sha256(canonical(packet)).hexdigest())
   check(case+':transport_observation',canonical(packet['payload']['observation'])==canonical(observed))
   meta=native['transport'];topic='zer19-'+context['run_id'][4:16]+'.observations'
   check(case+':native_kafka_record',meta=={'kind':'KAFKA','topic':topic,'partition':0,'offset':0,'consumed_topic':topic,'consumed_partition':0,'consumed_offset':0,'received_count':1})
   check(case+':durable_receiver_claim',claim['id']==packet['payload']['id'] and claim['sha256']==hashlib.sha256(canonical(packet['payload'])).hexdigest())
   command_raw=read(d/'worker-transport-command.json');handoff_raw=read(d/'handoff-transport-command.json')
   check(case+':separate_native_receipts',command_raw['returncode']==handoff_raw['returncode']==0 and '/current/remote.py' in command_raw['args'] and '/current/handoff.py' in handoff_raw['args'])
   journal=d/'pipeline'/context['run_id']/'events.jsonl';events=[json.loads(line) for line in journal.read_text(encoding='utf8').splitlines()]
   received=next(i for i,r in enumerate(events) if r['kind']=='HANDOFF_RECEIVED')
   observed_index=next(i for i,r in enumerate(events) if r['kind']=='OBSERVATION')
   check(case+':receiver_before_healer',received<observed_index)
  else:check(case+':abstention_retained',case=='C0' and flow['status']=='NOT_RUN_GAIA' and flow['diagnosis']['status']=='ABSTAIN' and not (d/'handoff-send-intent.json').exists())
  check(case+':business_statuses',[r['http']['response']['status'] for r in probe['benign']]==[200,201,200,200,404])
  observed_fact=read(d/'functional-observed.json');total['api_replace']+=observed_fact['api_replace_attempts']
  if case=='SQLI':
   check('sql_effect_disclosed',access['restricted_rows']>0)
   check('sql_native_containment',flow['status']=='COMPLETED' and healer['status']=='ACTION_COMPLETED' and not healer['fallback'] and healer['action_state']['terminal']['status']=='SUCCESS' and healer['action_state']['terminal']['postcondition']['satisfied'] is True and probe['attacker']['http']['response']['status']==403 and probe['attacker']['access']['action_ids']==[healer['action_id']])
   check('sql_one_policy_write',observed_fact['api_replace_attempts']==1)
   result['action_id']=healer['action_id']
  else:
   check('benign_native_control',access['restricted_rows']==0 and observed_fact['api_replace_attempts']==0 and read(d/'benign-probe-verdict.json')['status']=='PASS')
  cases.append(result)
 check('fresh_fixture_per_effect_case',len(set(fixture_uids))==2)
 d=RUN/'CANCEL';row=read(d/'acceptance.json');work=row['work'];clean=row['cleanup']
 check('cancel_case_guard_stop_retained',row['status']=='NOT_MET' and work['guard_failures']==['MEMORY_STOP'] and work['provider_calls']==work['fixture_http']==work['tcp_checks']==0 and not (d/'cancel-receipt.json').exists())
 check('cancel_no_dispatch_or_fixture',not (d/'fixture-initial.json').exists() and not (d/'worker-transport-command.json').exists() and not (d/'handoff-send-intent.json').exists())
 check('cancel_owned_processes_closed',all(row[k]['process_reaped'] and row[k]['owned_tree_closed'] and not row[k]['timed_out'] for k in ('worker','cleanup_process')))
 sample=read(d/'resource-samples.json')[-1]
 check('host_memory_cause',sample['hostAvailable']<1073741824 and sample['wslAvailableKiB']>=1048576 and sample['memoryPsiAvg10']<=5,sample)
 check('guard_blocks_topic_effects',clean['verdict']=='INCOMPLETE' and clean['resource_guard']=='FAIL' and clean['topic_cleanup']=='PENDING_RESOURCE_GUARD' and clean['namespace_absent'] is True)
 resume=BASE/'cleanup-resume-02';res=read(resume/'cleanup.json');process=read(resume/'process.json');scope=read(resume/'scope.json')
 check('cleanup_resume_exact_state',scope['original_state_sha256']==sha(d/'state.json') and scope['original_cleanup_sha256']==sha(d/'cleanup.json') and res['topic_state']==clean['topic_state'])
 check('cleanup_resume_clean',res['verdict']=='CLEAN' and res['resource_guard']=='PASS' and not res['errors'] and not res['topic_cleanup_errors'] and all(res[k] is True for k in ('namespace_absent','shared_specs_preserved','shared_restarts_preserved')) and process['exit_code']==0 and process['owned_tree_closed'] and process['process_reaped'] and not process['timed_out'])
 for topic in res['topic_state']:
  matches=[]
  for raw in sorted((resume/'raw').glob('*.json')):
   obj=read(raw);args=obj.get('args',[])
   if '--list' in args and '--topic' in args and args[args.index('--topic')+1]=='^'+__import__('re').escape(topic)+'$':matches.append(obj)
  check('resume_topic_absent:'+topic,bool(matches) and matches[-1]['returncode']==0 and topic not in matches[-1]['stdout'].splitlines())
 cases.append({'case':'CANCEL','status':'NOT_MET_MEMORY_STOP_BEFORE_CANCEL','model_calls':0,'http':0,'tcp':0,'original_cleanup':'INCOMPLETE','cleanup_resume':'CLEAN','live_cancellation_executed':False})
 offline=read(BASE/'offline-verification.json');clean_ci=read(BASE/'clean-ci-verification.json')
 summary['offline_verification']=offline;summary['clean_ci_verification']=clean_ci
 check('offline_cancel_scenarios_pass',all((BASE/p).exists() for p in ('test_sqli_pipeline.log','test_runtime.log')) and 'OK' in (BASE/'test_sqli_pipeline.log').read_text() and 'OK' in (BASE/'test_runtime.log').read_text())
 check('budget_totals',total['model_calls']<=5 and total['cost_estimate_usd']<=.03 and total['http']==16 and total['tcp']==4 and total['api_replace']==1,total)
 summary.update(status='AC_EVIDENCE_READY_WITH_DISCLOSED_FAILURES',batch_status=final['status'],issue_done=False,totals=total,cases=cases,limitations=['Host-composed Gaia/privateKafka/Healer, not deployed autonomous main consumers','Fixture containment/business only; no Boutique incident recovery or KPI/RQ2 claim','Cached worker full source build-context unavailable; exact artifacts/3sourcepins retained','Clock synchronization independently UNKNOWN','Live CANCEL not reached because host memory guard stopped work; cancellation behavior verified offline with real Session and in-flight transport tests','C0 Gaia ABSTAIN preserved; no Healer call or classification accuracy claim','HMAC key not retained; posthoc MAC recomputation unavailable'])
except Exception as error:
 summary['error']=type(error).__name__+':'+str(error)
finally:
 (BASE/'final-audit.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
 print(json.dumps({k:v for k,v in summary.items() if k!='checks'}))
raise SystemExit(0 if summary['status']=='AC_EVIDENCE_READY_WITH_DISCLOSED_FAILURES' else 1)
